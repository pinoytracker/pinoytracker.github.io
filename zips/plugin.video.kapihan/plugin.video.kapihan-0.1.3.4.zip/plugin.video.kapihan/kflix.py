import xbmc ,xbmcgui ,xbmcplugin ,xbmcaddon #line:2
import re ,os ,urllib ,sys ,inspect ,requests #line:3
import resolveurl #line:7
import urllib .parse #line:10
headers ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}#line:13
addon_handle =int (sys .argv [1 ])#line:14
player =xbmc .Player ()#line:15
dialog =xbmcgui .Dialog ()#line:16
addon =xbmcaddon .Addon ('plugin.video.kapihan')#line:18
icon =addon .getAddonInfo ('icon')#line:19
addon_name =addon .getAddonInfo ('name')#line:20
Fanart =addon .getAddonInfo ('fanart')#line:22
addon_path =addon .getAddonInfo ('path')#line:24
Icons2 =addon_path +"/resources/icons/"#line:25
mainurl ='https://www1.dramacool.movie/most-popular-drama'#line:28
preurl ='https://www1.dramacool.movie/'#line:30
search =''#line:32
preurl2 ='https://www1.dramacool.movie/recently-added'#line:34
preurl3 ='https://www1.dramacool.movie'#line:35
xbmcplugin .setContent (int (sys .argv [1 ]),'tvshows')#line:37
from lib .pyairtable .api .table import Table #line:43
from lib .kepweng import popular as popular #line:44
from lib .kepweng import helpers as helpers #line:45
from lib .kepweng import pinoyflix as pinoyflix #line:46
from lib .kepweng import pinoyhdflix as pinoyhdflix #line:47
from lib .kepweng import pinoymoviepedia as pinoymoviepedia #line:48
from threading import Thread #line:50
def add_dir (dir_type ='',mode ='',url ='',title ='',iconimage ='',fanart ='',description =''):#line:58
	OO00O000OOO00O0O0 =sys .argv [0 ]+"?mode="+str (mode )+"&iconimage="+urllib .parse .quote_plus (iconimage )+"&description="+urllib .parse .quote_plus (description )#line:59
	OOOOO00OOO0O0O00O =2 ;O0OO000OO00OO0000 =inspect .getfullargspec (add_dir );OOO0O00O0000OOOOO =len (O0OO000OO00OO0000 [0 ])#line:60
	while OOO0O00O0000OOOOO -2 >0 :#line:61
		OO00O000OOO00O0O0 +="&"+O0OO000OO00OO0000 [0 ][OOOOO00OOO0O0O00O ]+"="+urllib .parse .quote_plus (locals ()[O0OO000OO00OO0000 [0 ][OOOOO00OOO0O0O00O ]])#line:62
		OOOOO00OOO0O0O00O +=1 ;OOO0O00O0000OOOOO -=1 #line:63
	OO000OO0OOO0OO0OO =xbmcgui .ListItem (title )#line:65
	OO000OO0OOO0OO0OO .setArt ({'poster':iconimage ,'thumb':iconimage })#line:68
	OO000OO0OOO0OO0OO .setInfo (type ="Video",infoLabels ={"Title":title ,"Plot":description })#line:69
	OO000OO0OOO0OO0OO .setProperty ("Fanart_Image",fanart )#line:71
	if dir_type !='':O0O0O000OOO0OOO00 =True #line:72
	else :O0O0O000OOO0OOO00 =False ;OO000OO0OOO0OO0OO .setProperty ("IsPlayable","true")#line:73
	O0O0OO0OOOOOOOOO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO00O000OOO00O0O0 ,listitem =OO000OO0OOO0OO0OO ,isFolder =O0O0O000OOO0OOO00 )#line:74
	return O0O0OO0OOOOOOOOO0 #line:75
def Get_Params ():#line:81
	O0O00O00OOOO0O0O0 =sys .argv [2 ]#line:82
	if len (O0O00O00OOOO0O0O0 )<=2 :return #line:83
	O000OO00O00OO0000 =re .split ('[?]',O0O00O00OOOO0O0O0 ,1 )#line:84
	O0OO0OO0O0O0O0O00 ={}#line:85
	OOO0000OO00O0OOO0 =urllib .parse .parse_qs (O000OO00O00OO0000 [1 ])#line:86
	for O000OO00000OO00O0 in OOO0000OO00O0OOO0 :#line:87
		O00O0OO0O00000O00 =''.join (OOO0000OO00O0OOO0 [O000OO00000OO00O0 ])#line:88
		O0OO0OO0O0O0O0O00 .update ({O000OO00000OO00O0 :O00O0OO0O00000O00 })#line:89
	return O0OO0OO0O0O0O0O00 #line:90
def login ():#line:92
	OOOO0OOOOO0000O00 ='patXWUzMfnS0V0w2v.da9b13b0c70937395e767e850cbb24a3f060645185e5ca98f2127829d4dec549'#line:94
	OO0000O0OO0O0OO0O =Table (OOOO0OOOOO0000O00 ,'app4obSw6zHHqkJmS','My Own Links')#line:95
	OO0O0O00OOOOOO0O0 =OO0000O0OO0O0OO0O .all ()#line:96
	OO00OOOO0000O00O0 =r"'name': 'A1', 'urlsource': '(.+?)'"#line:98
	O00O00000000O0OOO =r"'name': 'A2', 'urlsource': '(.+?)'"#line:99
	OOOO0O0O0000O0000 =re .compile (OO00OOOO0000O00O0 ,re .DOTALL ).findall (str (OO0O0O00OOOOOO0O0 ))[0 ]#line:101
	OO0OOOO00OOO0O0O0 =re .compile (O00O00000000O0OOO ,re .DOTALL ).findall (str (OO0O0O00OOOOOO0O0 ))[0 ]#line:103
	O00OOO0OOO0O0OOO0 =addon .getSetting ('Email User')#line:105
	OOOO0OO00OOO0000O =addon .getSetting ('Password')#line:106
	if O00OOO0OOO0O0OOO0 ==OOOO0O0O0000O0000 and OOOO0OO00OOO0000O ==OO0OOOO00OOO0O0O0 :#line:110
		MainMenu ()#line:112
	else :#line:114
		dialog .ok ('SORRY WRONG PASSWORD , PLEASE TRY AGAIN,THIS IS NOT FOR SALE','CONTACT THE ADMIN,CLICK OK TO CONTINUE CHANGE THE USERNAME PASSWORD IN THE SETTINGS')#line:115
		O0O0O00O00OO0O000 =None #line:116
		xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:118
		xbmc .executebuiltin ('Activatewindow(home)')#line:119
		addon .openSettings ('plugin.video.kflix')#line:120
headers ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}#line:122
read_pb =requests .get ('https://pastebin.com/raw/nuMVTUtA',verify =False ,headers =headers )#line:123
html_pb =read_pb .text #line:124
pb_regex =r'<ph_weekend>\("(.+?)","(.+?)","(.+?)"\)</ph_weekend>'#line:126
regex_pb_details =re .compile (pb_regex ,re .DOTALL ).findall (html_pb )#line:127
pb_regex2 =r'<ph_babad>\("(.+?)","(.+?)","(.+?)"\)</ph_babad>'#line:129
regex_pb_details2 =re .compile (pb_regex2 ,re .DOTALL ).findall (html_pb )#line:130
pb_regex3 =r'<k_babad>(.+?)</k_babad>'#line:132
KDRAMA_LINK =re .compile (pb_regex3 ,re .DOTALL ).findall (html_pb )[0 ]#line:133
def MainMenu ():#line:135
	add_dir ('','','','[B][COLOR yellow]-= TAGALOG  MENU =-[/COLOR][/B]','',Fanart )#line:141
	add_dir ('f','scrape_latest_pages','pflix/','[B][COLOR white]LATEST TAGALOG DRAMA [COLOR orange](PINOYFLIX)[/COLOR][/B]','',Fanart )#line:143
	add_dir ('f','scrape_latest_pages','phdflix/','[B][COLOR white]LATEST TAGALOG DRAMA [COLOR orange](PINOY HD)[/COLOR][/B]','',Fanart )#line:144
	add_dir ('f','search_tagalog','','[B][COLOR white] SEARCH TAGALOG MOVIES HERE [COLOR orange](=^_^=)[/COLOR][/B]','',Fanart )#line:145
	add_dir ('f','scrape_latest_pages','ppedia/','[B][COLOR white]TAGALOG MOVIES[/COLOR][/B]','',Fanart )#line:146
	add_dir ('','','','[B][COLOR yellow]-= KDRAMA  MENU =-[/COLOR][/B]','',Fanart )#line:151
	add_dir ('f','searchme','','[B][COLOR lightcoral] SEARCH HERE ( )[/COLOR][/B]','',Fanart )#line:153
	add_dir ('f','scrape_kdrama_most_popular','popularkdrama/','[B][COLOR lightcoral]POPULAR KDRAMAS[/COLOR][/B]','',Fanart )#line:154
	add_dir ('f','scrape_klatest_pages','recentlyaddedmovie/','[B][COLOR lightcoral]RECENTLY ADDED MOVIES[/COLOR][/B]','',Fanart )#line:155
	add_dir ('f','scrape_klatest_pages','recentlydramaaddep/','[B][COLOR lightcoral]RECENTLY ADDED DRAMA EPISODES[/COLOR][/B]','',Fanart )#line:156
	add_dir ('f','scrape_klatest_pages','recentlyaddedkshow/','[B][COLOR lightcoral]RECENTLY ADDED KSHOWS[/COLOR][/B]','',Fanart )#line:157
	add_dir ('','','','[B][COLOR yellow]-= NEW TELESERYES BELOW =-[/COLOR][/B]','',Fanart )#line:161
	add_dir ('','','','[B][COLOR red]-= UNDER MAINTENANCE =-[/COLOR][/B]','',Fanart )#line:162
def scrape_pinoyflix_pages (O0O00O00OOO000OO0 ):#line:192
	OO000O0OOO0OO0OO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}#line:193
	OOO00OOOO000O0OO0 =requests .get (O0O00O00OOO000OO0 ,headers =OO000O0OOO0OO0OO0 )#line:194
	O0O0OO00O00O0O0O0 =(OOO00OOOO000O0OO0 .text .encode ('ascii','ignore').decode ('ascii'))#line:196
	O00O0O0OO00O0O00O =re .compile ('<h2>Seasons and episodes</h2>(.+?)<h2>You May Also Like</h2>',re .DOTALL ).findall (O0O0OO00O00O0O0O0 )#line:197
	xbmc .log ('VOLTES V ##################################################################'+str (O00O0O0OO00O0O00O ),2 )#line:199
def scrape_latest_pages (O00O0O0OO0000OO00 ):#line:206
	if "pflix/"in O00O0O0OO0000OO00 :#line:209
		OOOOOO000OOOOO00O ='https://pinoysflix.su/'#line:212
		O000OO000OO0O0O00 =pinoyflix .scrape_main (OOOOOO000OOOOO00O )#line:213
	if "nextpagepflix/"in O00O0O0OO0000OO00 :#line:214
		OOOOOO000OOOOO00O =O00O0O0OO0000OO00 .replace ('nextpagepflix/','')#line:217
		O000OO000OO0O0O00 =pinoyflix .scrape_main (OOOOOO000OOOOO00O )#line:218
	if "[urduha]"in O00O0O0OO0000OO00 :#line:220
		O00O0O0OO0000OO00 =O00O0O0OO0000OO00 .replace ('[urduha]','')#line:221
		O000OO000OO0O0O00 =pinoyflix .scrape_main (O00O0O0OO0000OO00 )#line:223
	if "[BQ]"in O00O0O0OO0000OO00 :#line:224
		O00O0O0OO0000OO00 =O00O0O0OO0000OO00 .replace ('[BQ]','')#line:225
		O000OO000OO0O0O00 =pinoyflix .scrape_main (O00O0O0OO0000OO00 )#line:227
	if "[DL]"in O00O0O0OO0000OO00 :#line:228
		O00O0O0OO0000OO00 =O00O0O0OO0000OO00 .replace ('[DL]','')#line:229
		O000OO000OO0O0O00 =pinoyflix .scrape_main (O00O0O0OO0000OO00 )#line:231
	if "[TIH]"in O00O0O0OO0000OO00 :#line:232
		O00O0O0OO0000OO00 =O00O0O0OO0000OO00 .replace ('[TIH]','')#line:233
		O000OO000OO0O0O00 =pinoyflix .scrape_main (O00O0O0OO0000OO00 )#line:235
	if "[MCI]"in O00O0O0OO0000OO00 :#line:236
		O00O0O0OO0000OO00 =O00O0O0OO0000OO00 .replace ('[MCI]','')#line:237
		O000OO000OO0O0O00 =pinoyflix .scrape_main (O00O0O0OO0000OO00 )#line:239
	if "[AKP]"in O00O0O0OO0000OO00 :#line:240
		O00O0O0OO0000OO00 =O00O0O0OO0000OO00 .replace ('[AKP]','')#line:241
		O000OO000OO0O0O00 =pinoyflix .scrape_main (O00O0O0OO0000OO00 )#line:243
	if "[UA]"in O00O0O0OO0000OO00 :#line:244
		O00O0O0OO0000OO00 =O00O0O0OO0000OO00 .replace ('[UA]','')#line:245
		O000OO000OO0O0O00 =pinoyflix .scrape_main (O00O0O0OO0000OO00 )#line:247
	if "[CHA]"in O00O0O0OO0000OO00 :#line:248
		O00O0O0OO0000OO00 =O00O0O0OO0000OO00 .replace ('[CHA]','')#line:249
		O000OO000OO0O0O00 =pinoyflix .scrape_main (O00O0O0OO0000OO00 )#line:251
	if "[UH]"in O00O0O0OO0000OO00 :#line:252
		O00O0O0OO0000OO00 =O00O0O0OO0000OO00 .replace ('[UH]','')#line:253
		O000OO000OO0O0O00 =pinoyflix .scrape_main (O00O0O0OO0000OO00 )#line:255
	if "[PBB]"in O00O0O0OO0000OO00 :#line:256
		O00O0O0OO0000OO00 =O00O0O0OO0000OO00 .replace ('[PBB]','')#line:257
		O000OO000OO0O0O00 =pinoyflix .scrape_main (O00O0O0OO0000OO00 )#line:259
	if "phdflix/"in O00O0O0OO0000OO00 :#line:260
		OOOOOO000OOOOO00O ='https://pinoyhdflix.su/'#line:261
		O000OO000OO0O0O00 =pinoyhdflix .scrape_main (OOOOOO000OOOOO00O )#line:262
	if "nextpagephdflix/"in O00O0O0OO0000OO00 :#line:263
		O00O0O0OO0000OO00 =O00O0O0OO0000OO00 .replace ('nextpagephdflix/','')#line:264
		OOOOOO000OOOOO00O =O00O0O0OO0000OO00 #line:265
		O000OO000OO0O0O00 =pinoyhdflix .scrape_main (OOOOOO000OOOOO00O )#line:266
	if "ppedia/"in O00O0O0OO0000OO00 :#line:267
		O00O0O0OO0000OO00 ='https://pinoymoviepedia.ru/movies/'#line:268
		O000OO000OO0O0O00 =pinoymoviepedia .scrape_main (O00O0O0OO0000OO00 )#line:269
	if "nextpagedia/"in O00O0O0OO0000OO00 :#line:270
		OOOOOO000OOOOO00O =O00O0O0OO0000OO00 .replace ('nextpagedia/','')#line:273
		O000OO000OO0O0O00 =pinoymoviepedia .scrape_main (OOOOOO000OOOOO00O )#line:276
	if "restored/"in O00O0O0OO0000OO00 :#line:277
		OOOOOO000OOOOO00O ='https://pinoymoviepedia.ru/genre/digitally-restored/'#line:280
		O000OO000OO0O0O00 =pinoymoviepedia .scrape_main (OOOOOO000OOOOO00O )#line:281
	else :#line:282
		pass #line:283
	try :#line:287
		O00O0OOOO0O000OOO =r'<name>(.+?)</name><icon>(.+?)</icon><url>(.+?)<url>'#line:291
		O0OO0OO0OOO0O0000 =re .compile (O00O0OOOO0O000OOO ,re .DOTALL ).findall (str (O000OO000OO0O0O00 ))#line:292
		for O0OO00O0OO0OO0000 ,O00OO00OOOO0OO00O ,O00O0O0OO0000OO00 in O0OO0OO0OOO0O0000 :#line:293
			O0OO00O0OO0OO0000 =O0OO00O0OO0OO0000 .replace ('&#8217;','\'').replace ('&#8211;','-').replace ('&#39;','\'').replace ('&amp;#038;','&').replace ('\\\\xe2\\\\x80\\\\x99','\'')#line:295
			add_dir ('f','get_links',O00O0O0OO0000OO00 ,'[B][COLOR white]'+O0OO00O0OO0OO0000 +'[/COLOR][/B]',O00OO00OOOO0OO00O ,O00OO00OOOO0OO00O ,O0OO00O0OO0OO0000 )#line:296
		OOO00OO00OO00OO00 =r'<nextpage>(.+?)</nextpage>'#line:298
		O0O0OO0OOO0OOOOOO =re .compile (OOO00OO00OO00OO00 ,re .DOTALL ).findall (str (O000OO000OO0O0O00 ))#line:299
		for O00O0O0OO0000OO00 in O0O0OO0OOO0OOOOOO :#line:300
			add_dir ('f','scrape_latest_pages',O00O0O0OO0000OO00 ,'[B][COLOR red]NEXT PAGE[/COLOR][/B]')#line:301
		xbmc .executebuiltin ('Container.SetViewMode(512)')#line:303
	except :#line:304
		pass #line:305
def get_links (OOO00OOOO0O00OO0O ):#line:310
	if 'pinoystvflix.su'in OOO00OOOO0O00OO0O :#line:313
		O00000O00OOO00OOO =pinoyflix .scrape_links (OOO00OOOO0O00OO0O )#line:314
	if 'pinoyhqteleserye.su'in OOO00OOOO0O00OO0O :#line:315
		O00000O00OOO00OOO =pinoyhdflix .scrape_links (OOO00OOOO0O00OO0O )#line:316
	if 'pinoymoviepedia.ru'in OOO00OOOO0O00OO0O :#line:318
		O00000O00OOO00OOO =pinoymoviepedia .scrape_links (OOO00OOOO0O00OO0O )#line:319
	O0O000O0OOO0OOO0O =r'<url>(.+?)</url>'#line:321
	OOOOOO00OOOOO00O0 =re .compile (O0O000O0OOO0OOO0O ,re .DOTALL ).findall (str (O00000O00OOO00OOO ))#line:322
	OOO0OO000O0000000 =0 #line:325
	for OOO00OOOO0O00OO0O in OOOOOO00OOOOO00O0 :#line:327
		if 'http'not in OOO00OOOO0O00OO0O :#line:328
			OOO00OOOO0O00OO0O ='http:'+OOO00OOOO0O00OO0O #line:329
		try :#line:332
			if 'COMING SOON'in OOOOOO00OOOOO00O0 :#line:333
				OOO0OO000O0000000 =OOO0OO000O0000000 +1 #line:334
				add_dir ('','','','[B][COLOR yellow]COMING SOON CHECK BACK LATER[/COLOR][/B]','','','')#line:335
			else :#line:337
				if resolveurl .HostedMediaFile (OOO00OOOO0O00OO0O ).valid_url ():#line:338
					OOO0OO000O0000000 =OOO0OO000O0000000 +1 #line:339
					try :#line:340
						OO0O0O00OOOO0000O =OOO00OOOO0O00OO0O .split ('//')[1 ].replace ('www.','')#line:341
						OO0O0O00OOOO0000O =OO0O0O00OOOO0000O .split ('/')[0 ].split ('.')[0 ].title ()#line:342
					except :pass #line:343
					add_dir ('','dramacoolresolve',OOO00OOOO0O00OO0O ,'[B][COLOR yellow]'+OO0O0O00OOOO0000O +'[/COLOR][/B]',thumb ,'','')#line:344
		except :#line:351
			pass #line:352
	if OOO0OO000O0000000 >0 :#line:356
		pass #line:357
	else :#line:358
		add_dir ('','','','[B][COLOR red]SORRY NO PLAYABLE LINK FOUND, PLS TRY OTHER SOURCES[/COLOR][/B]','','','')#line:359
def Display_Tagalog_Page (O0OO00000000O000O ):#line:361
	OOO0OO0O0OOOOOO00 =pinoymoviepedia .scrape_search_page (O0OO00000000O000O )#line:363
	O00000000O000O0O0 =r'<name>(.+?)</name><icon>(.+?)</icon><url>(.+?)<url><sum>(.+?)</summ>'#line:366
	O000000OOO00O00OO =re .compile (O00000000O000O0O0 ,re .DOTALL ).findall (str (OOO0OO0O0OOOOOO00 ))#line:367
	for OO00OOO000O00OOOO ,O00O0OOOOO00OOO0O ,O0OO00000000O000O ,O0OO0OO000OO0000O in O000000OOO00O00OO :#line:368
		OO00OOO000O00OOOO =OO00OOO000O00OOOO .replace ('&#8217;','\'').replace ('&#8211;','-').replace ('&#39;','\'').replace ('&amp;#038;','&').replace ('\\\\xe2\\\\x80\\\\x99','\'')#line:370
		add_dir ('f','get_links',O0OO00000000O000O ,'[B][COLOR white]'+OO00OOO000O00OOOO +'[/COLOR][/B]',O00O0OOOOO00OOO0O ,O00O0OOOOO00OOO0O ,O0OO0OO000OO0000O )#line:371
	O0O000O0O00OOO0O0 =r'<nextpage>(.+?)</nextpage>'#line:373
	OOOO0O0000OO0O00O =re .compile (O0O000O0O00OOO0O0 ,re .DOTALL ).findall (str (OOO0OO0O0OOOOOO00 ))#line:374
	for O0OO00000000O000O in OOOO0O0000OO0O00O :#line:376
		if "nextsearchpage/"in O0OO00000000O000O :#line:377
			O0OO00000000O000O =O0OO00000000O000O .replace ('nextsearchpage/','')#line:378
		add_dir ('f','Display_Tagalog_Page',O0OO00000000O000O ,'[B][COLOR red]NEXT PAGE[/COLOR][/B]')#line:382
def scrape_kdrama_most_popular (O00OOOO0O0O0O0000 ):#line:391
	if "popularkdrama/"in O00OOOO0O0O0O0000 :#line:394
		O000O0OO000OO00O0 ='https://www1.dramacool.movie/most-popular-drama'#line:396
		O00O00000OO0000OO =popular .scrape_most_popular (O000O0OO000OO00O0 )#line:397
	elif "nextpageppkd/"in O00OOOO0O0O0O0000 :#line:399
		O000O0OO000OO00O0 =O00OOOO0O0O0O0000 .replace ('nextpageppkd/','https://www1.dramacool.movie/most-popular-drama')#line:402
		O00O00000OO0000OO =popular .scrape_most_popular (O000O0OO000OO00O0 )#line:403
	else :#line:404
		pass #line:405
	try :#line:410
		OOOO0OO000O00O0O0 =r'<url>(.+?)</url><name>(.+?)</name><icon>(.+?)</icon><summary>(.+?)</summary><status>(.+?)</status>'#line:414
		O0O0O00O0OO0O00O0 =re .compile (OOOO0OO000O00O0O0 ,re .DOTALL ).findall (str (O00O00000OO0000OO ))#line:415
		for O00OOOO0O0O0O0000 ,OOO00OOO00O00O00O ,O00O0O000OOO00000 ,OOO0OOO00OOO0O000 ,O000OOO000OOO0OO0 in O0O0O00O0OO0O00O0 :#line:416
			OOO00OOO00O00O00O =OOO00OOO00O00O00O .replace ('&#8217;','\'').replace ('&#8211;','-').replace ('&#39;','\'').replace ('&amp;#038;','&').replace ('\\\\xe2\\\\x80\\\\x99','\'')#line:418
			if "nostat/"in O000OOO000OOO0OO0 :#line:419
				OOOO00O0O0OOO0000 =OOO00OOO00O00O00O #line:420
			else :#line:421
				OOOO00O0O0OOO0000 =OOO00OOO00O00O00O +' ([COLOR yellow] STATUS: [/COLOR]'+'[COLOR red]'+O000OOO000OOO0OO0 +'[/COLOR])'#line:422
			add_dir ('f','get_k_episodes',O00OOOO0O0O0O0000 ,'[B][COLOR white]'+OOOO00O0O0OOO0000 +'[/COLOR][/B]',O00O0O000OOO00000 ,O00O0O000OOO00000 ,OOO0OOO00OOO0O000 )#line:423
		O0000000OO0O0OO00 =r'<nextpage>(.+?)</nextpage>'#line:425
		OOO00O00O00OO0000 =re .compile (O0000000OO0O0OO00 ,re .DOTALL ).findall (str (O00O00000OO0000OO ))#line:426
		for O00OOOO0O0O0O0000 in OOO00O00O00OO0000 :#line:427
			add_dir ('f','scrape_kdrama_most_popular',O00OOOO0O0O0O0000 ,'[B][COLOR red]NEXT PAGE[/COLOR][/B]')#line:428
		xbmc .executebuiltin ('Container.SetViewMode(512)')#line:430
	except :#line:431
		pass #line:432
def get_recently_episodes (OOOO0O00000OOOOOO ):#line:441
	O000O0OOO0OOO0OOO ='https://www1.dramacool.cr'+OOOO0O00000OOOOOO #line:445
	OOOO00O0O000OO0OO =popular .scrape_play_links (O000O0OOO0OOO0OOO )#line:446
	O00O000O0O0O0OO0O =r'<playlink_pass>(.+?)</playlink_pass>'#line:448
	O0OOO00OO00000OO0 =re .compile (O00O000O0O0O0OO0O ,re .DOTALL ).findall (str (OOOO00O0O000OO0OO ))[0 ]#line:449
	OO0O0000000OOO000 =popular .scrape_kdrama_details (O0OOO00OO00000OO0 )#line:452
	O0O0OOO0OO0O0000O =r'<title>(.+?)</title><icon>(.+?)</icon><status>(.+?)</status><description>(.+?)</description>'#line:454
	O0OO00OO0OO00OOO0 =re .compile (O0O0OOO0OO0O0000O ,re .DOTALL ).findall (str (OO0O0000000OOO000 ))#line:455
	for OOO0OO0O0OO00OO00 ,OOOOOO0OOOOO0OO00 ,O0000OO0O0O00O0OO ,O00000O000OO0O00O in O0OO00OO0OO00OOO0 :#line:460
		OO00OOO00O00OO0O0 =OOOOOO0OOOOO0OO00 #line:461
		OOOO0000OOOO00000 =O0000OO0O0O00O0OO #line:462
		OO00O0000OO00OOO0 =O00000O000OO0O00O #line:463
		add_dir ('','','','[B][COLOR yellow]'+OOOO0000OOOO00000 +'[/COLOR]'+' '+'[COLOR white]'+OOO0OO0O0OO00OO00 +'[/COLOR][/B]',OO00OOO00O00OO0O0 ,OO00OOO00O00OO0O0 ,OO00O0000OO00OOO0 )#line:464
	add_dir ('f','displaycast',O0OOO00OO00000OO0 ,'[B][COLOR yellow]= DISPLAY CAST SHOWS =[/COLOR][/B]',OO00OOO00O00OO0O0 ,OO00OOO00O00OO0O0 ,OO00O0000OO00OOO0 )#line:466
	add_dir ('','','','[B][COLOR white]= CHOOSE EPISODES BELOW =[/COLOR][/B]',OO00OOO00O00OO0O0 ,OO00OOO00O00OO0O0 ,OO00O0000OO00OOO0 )#line:468
	O00OOO0OO0OO00000 =popular .display_kdrama_episodes (O000O0OOO0OOO0OOO )#line:470
	OOOO000OO0O0O0OO0 =r'<episodes_url>(.+?)</episodes_url><episodes_sub>(.+?)</episodes_sub><episodes_num>(.+?)</episodes_num>'#line:471
	OO0OOO0O0OO00000O =re .compile (OOOO000OO0O0O0OO0 ,re .DOTALL ).findall (str (O00OOO0OO0OO00000 ))#line:472
	for OOOO0O00000OOOOOO ,OOO0OO00O0OOO0O00 ,OOOOO0O000O00OO00 in OO0OOO0O0OO00000O :#line:473
		O000O0OOO0OOO0OOO ='https://www1.dramacool.movie'+OOOO0O00000OOOOOO #line:474
		O000O0OO00OOO00O0 ='[B][COLOR yellow]'+OOO0OO00O0OOO0O00 +'[/COLOR]'+' '+'[COLOR white]'+OOOOO0O000O00OO00 +'[/COLOR][/B]'#line:477
		add_dir ('f','get_klinks',O000O0OOO0OOO0OOO ,O000O0OO00OOO00O0 ,OO00OOO00O00OO0O0 ,OO00OOO00O00OO0O0 ,OO00O0000OO00OOO0 )#line:478
	xbmc .executebuiltin ('Container.SetViewMode(512)')#line:480
def get_k_episodes (O0OO00OOO000O0O0O ):#line:493
	O0000O0O0OO0O0OOO ='https://www1.dramacool.movie'+O0OO00OOO000O0O0O #line:496
	O00OOOO0O0O0O0O0O =popular .display_kdrama_episodes (O0000O0O0OO0O0OOO )#line:498
	O000OO00OOO00OO00 =popular .scrape_kdrama_details (O0000O0O0OO0O0OOO )#line:500
	O0O00O0O0OO0O000O =r'<status>(.+?)</status>'#line:503
	OOOO0OOO0O00OO0OO =re .compile (O0O00O0O0OO0O000O ,re .DOTALL ).findall (str (O000OO00OOO00OO00 ))#line:504
	if "Upcoming"in OOOO0OOO0O00OO0OO :#line:506
		add_dir ('','','','[B][COLOR yellow]COMING SOON[/COLOR][/B]')#line:507
	else :#line:508
		try :#line:509
			O0O0O0O0O00O0OO0O =r'<title>(.+?)</title><icon>(.+?)</icon><status>(.+?)</status><description>(.+?)</description>'#line:510
			OOO00000000OO000O =re .compile (O0O0O0O0O00O0OO0O ,re .DOTALL ).findall (str (O000OO00OOO00OO00 ))#line:511
			for OOO0O0O00OO0OOO00 ,OO0OOOO0OO00000OO ,OOO00000OO00OOOOO ,O0OO0OO00O0000O00 in OOO00000000OO000O :#line:512
				OOO0OO0O00OO0O000 =OO0OOOO0OO00000OO #line:513
				O0OOOOO00OO0OO00O =OOO00000OO00OOOOO #line:514
				O0O0OO0OOO0000O00 =O0OO0OO00O0000O00 #line:515
				add_dir ('','','','[B][COLOR yellow]'+O0OOOOO00OO0OO00O +'[/COLOR]'+' '+'[COLOR white]'+OOO0O0O00OO0OOO00 +'[/COLOR][/B]',OOO0OO0O00OO0O000 ,OOO0OO0O00OO0O000 ,O0O0OO0OOO0000O00 )#line:516
			add_dir ('f','displaycast',O0000O0O0OO0O0OOO ,'[B][COLOR yellow]= DISPLAY CAST SHOWS =[/COLOR][/B]',OOO0OO0O00OO0O000 ,OOO0OO0O00OO0O000 ,O0O0OO0OOO0000O00 )#line:518
			add_dir ('','','','[B][COLOR white]= CHOOSE EPISODES BELOW =[/COLOR][/B]',OOO0OO0O00OO0O000 ,OOO0OO0O00OO0O000 ,O0O0OO0OOO0000O00 )#line:520
			OO000O0OOOOOO0O0O =r'<episodes_url>(.+?)</episodes_url><episodes_sub>(.+?)</episodes_sub><episodes_num>(.+?)</episodes_num>'#line:523
			OO00O000O0OOOOOOO =re .compile (OO000O0OOOOOO0O0O ,re .DOTALL ).findall (str (O00OOOO0O0O0O0O0O ))#line:524
			for O0OO00OOO000O0O0O ,O0O0OOO0O0000OO0O ,OO00O00OO00000O00 in OO00O000O0OOOOOOO :#line:526
				O0000O0O0OO0O0OOO ='https://www1.dramacool.movie'+O0OO00OOO000O0O0O #line:527
				OO0OOOOO0O0000OO0 ='[B][COLOR yellow]'+O0O0OOO0O0000OO0O +'[/COLOR]'+' '+'[COLOR white]'+OO00O00OO00000O00 +'[/COLOR][/B]'#line:530
				add_dir ('f','get_klinks',O0000O0O0OO0O0OOO ,OO0OOOOO0O0000OO0 ,OOO0OO0O00OO0O000 ,OOO0OO0O00OO0O000 ,O0O0OO0OOO0000O00 )#line:531
			xbmc .executebuiltin ('Container.SetViewMode(512)')#line:532
		except :#line:533
			pass #line:534
def get_klinks (O0OOO00OO0O0O0O0O ):#line:542
	OOO00O0O0O0O00OO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}#line:544
	OOO00O0OOO0O0000O =requests .get (O0OOO00OO0O0O0O0O ,headers =OOO00O0O0O0O00OO0 )#line:545
	OO00000OO0OOO00O0 =OOO00O0OOO0O0000O .text #line:546
	OOO0OO0O0OO000OOO =re .compile (">We moved to <a style=.+?title=.+?href='(.+?)'>",re .DOTALL ).findall (str (OO00000OO0OOO00O0 ))[0 ]#line:548
	O00000OO0O0OOO00O =r'<option  selected  value=.+?>(.+?)</option>'#line:551
	O0OO0000O0OOO0O00 =re .compile (O00000OO0O0OOO00O ,re .DOTALL ).findall (OO00000OO0OOO00O0 )[0 ]#line:552
	O00O0O0O000O000O0 =popular .scrape_play_links (O0OOO00OO0O0O0O0O )#line:557
	OO0O0O0000OO0OO00 =r'<playlink_pass>(.+?)</playlink_pass>'#line:559
	O000OOO000OOO00OO =re .compile (OO0O0O0000OO0OO00 ,re .DOTALL ).findall (str (O00O0O0O000O000O0 ))[0 ]#line:560
	OO0000000OO0OOO0O =popular .scrape_kdrama_details (O000OOO000OOO00OO )#line:562
	OO0OO000OO00O00OO =r'<title>(.+?)</title><icon>(.+?)</icon><status>(.+?)</status><description>(.+?)</description>'#line:565
	O00O0OO0OO0OOO000 =re .compile (OO0OO000OO00O00OO ,re .DOTALL ).findall (str (OO0000000OO0OOO0O ))#line:566
	for OOOOOO0O0OO0OO00O ,OO000OO00O000000O ,OOO00O00O0OO00000 ,OO000O0OO00OO0OO0 in O00O0OO0OO0OOO000 :#line:567
		O000O00OOOO0O000O =OO000OO00O000000O #line:568
		OOO0O0OOO00O0OOOO =OOO00O00O0OO00000 #line:569
		O0O00OOOO0000000O =OO000O0OO00OO0OO0 #line:570
		add_dir ('','','','[B][COLOR yellow]'+OOO0O0OOO00O0OOOO +'[/COLOR]'+' '+'[COLOR white]'+OOOOOO0O0OO0OO00O +'[/COLOR][/B]',O000O00OOOO0O000O ,O000O00OOOO0O000O ,O0O00OOOO0000000O )#line:571
	add_dir ('','','','[B][COLOR white]PLAYING = [COLOR yellow] '+O0OO0000O0OOO0O00 +' [/COLOR][/B]',O000O00OOOO0O000O ,O000O00OOOO0O000O ,O0O00OOOO0000000O )#line:574
	add_dir ('','','','[B][COLOR white]= CHOOSE PLAY LINKS BELOW =[/COLOR][/B]',O000O00OOOO0O000O ,O000O00OOOO0O000O ,O0O00OOOO0000000O )#line:575
	OOO00O0O00O0OOOO0 =r'<url>(.+?)</url>'#line:585
	OOO00000O0O0O0O0O =re .compile (OOO00O0O00O0OOOO0 ,re .DOTALL ).findall (str (O00O0O0O000O000O0 ))#line:586
	O00O00O00OOOO0O00 =0 #line:599
	for O0O0OOOOOOO0O0OOO in OOO00000O0O0O0O0O :#line:605
		if 'http'not in O0O0OOOOOOO0O0OOO :#line:606
			O0O0OOOOOOO0O0OOO ='http:'+O0O0OOOOOOO0O0OOO #line:608
		try :#line:611
			if 'COMING SOON'in OOO00000O0O0O0O0O :#line:612
				O00O00O00OOOO0O00 =O00O00O00OOOO0O00 +1 #line:613
				add_dir ('','','','[B][COLOR yellow]COMING SOON CHECK BACK LATER[/COLOR][/B]','','','')#line:614
			else :#line:616
				if resolveurl .HostedMediaFile (O0O0OOOOOOO0O0OOO ).valid_url ():#line:617
					O00O00O00OOOO0O00 =O00O00O00OOOO0O00 +1 #line:618
					try :#line:619
						OOO0OO0O0OOOOOOO0 =O0O0OOOOOOO0O0OOO .split ('//')[1 ].replace ('www.','')#line:620
						OOO0OO0O0OOOOOOO0 =OOO0OO0O0OOOOOOO0 .split ('/')[0 ].split ('.')[0 ].title ()#line:621
					except :pass #line:622
					add_dir ('','dramacoolresolve',O0O0OOOOOOO0O0OOO ,'[B][COLOR yellow]'+OOO0OO0O0OOOOOOO0 +'[/COLOR][/B]',O000O00OOOO0O000O ,O000O00OOOO0O000O ,O0O00OOOO0000000O )#line:623
		except :#line:630
			pass #line:631
	if O00O00O00OOOO0O00 >0 :#line:635
		pass #line:636
	else :#line:637
		add_dir ('','','','[B][COLOR red]SORRY NO PLAYABLE LINK FOUND, PLS TRY OTHER SOURCES[/COLOR][/B]','','','')#line:638
	add_dir ('','','','[B][COLOR red]CHOOSE EPISODES BELOW[/COLOR][/B]','','','')#line:639
	O0OOO00O000O0000O =popular .display_kdrama_episodes (O0OOO00OO0O0O0O0O )#line:641
	O00O0OOO0OO000OO0 =r'<episodes_url>(.+?)</episodes_url><episodes_sub>(.+?)</episodes_sub><episodes_num>(.+?)</episodes_num>'#line:643
	O00O00000O0OOO0OO =re .compile (O00O0OOO0OO000OO0 ,re .DOTALL ).findall (str (O0OOO00O000O0000O ))#line:644
	for O0OOO00OO0O0O0O0O ,O0OOO0O0OOO0O00O0 ,O00000OO0O0OOO00O in O00O00000O0OOO0OO :#line:646
		OOO000OOO000O0OOO ='https://www1.dramacool.movie'+O0OOO00OO0O0O0O0O #line:647
		OOO0O0O0OOOOOO0OO ='[B][COLOR yellow]'+O0OOO0O0OOO0O00O0 +'[/COLOR]'+' '+'[COLOR white]'+O00000OO0O0OOO00O +'[/COLOR][/B]'#line:650
		add_dir ('f','get_klinks',OOO000OOO000O0OOO ,OOO0O0O0OOOOOO0OO ,O000O00OOOO0O000O ,O000O00OOOO0O000O ,O0O00OOOO0000000O )#line:651
def scrape_klatest_pages (OOO000OO0OO00O000 ):#line:661
	if "recentlyaddedmovie/"in OOO000OO0OO00O000 :#line:664
		OO0O0000O0OOOO0O0 ='https://www1.dramacool.cr/recently-added-movie'#line:667
		O00OO0O0O000OOOOO =popular .scrape_movie_details (OO0O0000O0OOOO0O0 )#line:668
	if "nextpagekmovie/"in OOO000OO0OO00O000 :#line:670
		OOO000OO0OO00O000 =OOO000OO0OO00O000 .replace ('nextpagekmovie/','')#line:671
		OO0O0000O0OOOO0O0 ='https://www1.dramacool.cr/recently-added-movie'+OOO000OO0OO00O000 #line:672
		O00OO0O0O000OOOOO =popular .scrape_movie_details (OO0O0000O0OOOO0O0 )#line:673
	if "recentlydramaaddep/"in OOO000OO0OO00O000 :#line:674
		OO0O0000O0OOOO0O0 ='https://www1.dramacool.cr/recently-added'#line:677
		O00OO0O0O000OOOOO =popular .scrape_movie_details (OO0O0000O0OOOO0O0 )#line:679
	if "nextrecentlypagekdrama/"in OOO000OO0OO00O000 :#line:680
		OOO000OO0OO00O000 =OOO000OO0OO00O000 .replace ('nextrecentlypagekdrama/','')#line:681
		OO0O0000O0OOOO0O0 ='https://www1.dramacool.cr/recently-added'+OOO000OO0OO00O000 #line:683
		O00OO0O0O000OOOOO =popular .scrape_movie_details (OO0O0000O0OOOO0O0 )#line:684
	if "recentlyaddedkshow/"in OOO000OO0OO00O000 :#line:685
		OO0O0000O0OOOO0O0 ='https://www1.dramacool.cr/recently-added-kshow'#line:688
		O00OO0O0O000OOOOO =popular .scrape_movie_details (OO0O0000O0OOOO0O0 )#line:689
	if "nextrecentlykshow/"in OOO000OO0OO00O000 :#line:690
		OOO000OO0OO00O000 =OOO000OO0OO00O000 .replace ('nextrecentlykshow/','')#line:691
		OO0O0000O0OOOO0O0 ='https://www1.dramacool.cr/recently-added-kshow'+OOO000OO0OO00O000 #line:693
		O00OO0O0O000OOOOO =popular .scrape_movie_details (OO0O0000O0OOOO0O0 )#line:695
	else :#line:696
		pass #line:697
	try :#line:700
		OO0O00OO0000OOO0O =r'<url>(.+?)</url><name>(.+?)</name><icon>(.+?)</icon><summary>(.+?)</summary><status>(.+?)</status><epnum>(.+?)</epnum>'#line:705
		OO0OO00O0O00OOO0O =re .compile (OO0O00OO0000OOO0O ,re .DOTALL ).findall (str (O00OO0O0O000OOOOO ))#line:706
		for OOO000OO0OO00O000 ,O00OOO0OOO000OO0O ,O00O000000OOO0OO0 ,O000O00O000OOO00O ,OOO000O00OOO0OO0O ,O0O00O000O0OO000O in OO0OO00O0O00OOO0O :#line:708
			O00OOO0OOO000OO0O =O00OOO0OOO000OO0O .replace ('&#8217;','\'').replace ('&#8211;','-').replace ('&#39;','\'').replace ('&amp;#038;','&').replace ('\\\\xe2\\\\x80\\\\x99','\'')#line:710
			if "RAW"in OOO000O00OOO0OO0O :#line:712
				OOO000O00OOO0OO0O ='[B][COLOR red]'+OOO000O00OOO0OO0O +'[/COLOR]'#line:713
			else :#line:714
				OOO000O00OOO0OO0O ='[B][COLOR yellow]'+OOO000O00OOO0OO0O +'[/COLOR]'#line:715
			if "nostat/"in OOO000O00OOO0OO0O :#line:716
				OO000000O000OO000 =O00OOO0OOO000OO0O #line:717
			else :#line:718
				OO000000O000OO000 =OOO000O00OOO0OO0O +' '+'[COLOR blue]'+O0O00O000O0OO000O +'[/COLOR]'+' '+O00OOO0OOO000OO0O #line:720
			if "RAW"in OOO000O00OOO0OO0O :#line:722
				continue #line:723
			else :#line:724
				add_dir ('f','get_recently_episodes',OOO000OO0OO00O000 ,'[B][COLOR white]'+OO000000O000OO000 +'[/COLOR][/B]',O00O000000OOO0OO0 ,O00O000000OOO0OO0 ,O000O00O000OOO00O )#line:725
		O0O00O0OOOO000OO0 =r'<nextpage>(.+?)</nextpage>'#line:727
		O0OOOOOOOO0OOO000 =re .compile (O0O00O0OOOO000OO0 ,re .DOTALL ).findall (str (O00OO0O0O000OOOOO ))#line:728
		for OOO000OO0OO00O000 in O0OOOOOOOO0OOO000 :#line:729
			add_dir ('f','scrape_klatest_pages',OOO000OO0OO00O000 ,'[B][COLOR red]NEXT PAGE[/COLOR][/B]')#line:730
		xbmc .executebuiltin ('Container.SetViewMode(512)')#line:732
	except :#line:733
		pass #line:734
def replace_unicode (OO0000OOOO00OO0OO ):#line:790
	OO0000OOOO00OO0OO =OO0000OOOO00OO0OO .replace ('&#7424;','A').replace ('&#665;','B').replace ('&#7428;','C').replace ('&#7429;','D').replace ('&#7431;','E').replace ('&#1171;','F').replace ('&#610;','G').replace ('&#668;','H').replace ('&#618;','I').replace ('&#7434;','J').replace ('&#7435;','K').replace ('&#671;','L').replace ('&#7437;','M').replace ('&#628;','N').replace ('&#7439;','O').replace ('&#7448;','P').replace ('&#42927;','Q').replace ('&#640;','R').replace ('&#42801;','S').replace ('&#7451;','T').replace ('&#7452;','U').replace ('&#7456;','V').replace ('&#7457;','W').replace ('&#120;','X').replace ('&#655;','Y').replace ('&#7458;','Z').replace ('&#8217;','\'')#line:792
	return OO0000OOOO00OO0OO #line:793
def Play (OO0000O0OO000OOO0 ):#line:926
	try :#line:927
		OOO0O000000OOO0OO =str (OO0000O0OO000OOO0 )+'|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0'#line:929
		OO0000O0OO000OOO0 ='https://rr4---sn-uxax3vh50nugp5-8pxy.googlevideo.com/videoplayback?expire=1677869068&ei=jM8BZL7EI4aCvPIPn9Wd0AQ&ip=2604:a00:3:2098:216:3eff:fe26:1a29&id=cec69285a31eb2b2&itag=18&source=blogger&susc=bl&eaua=AGNlHydycE4&mime=video/mp4&vprv=1&dur=1641.999&lmt=1677776601304503&txp=1311224&sparams=expire,ei,ip,id,itag,source,susc,eaua,mime,vprv,dur,lmt&sig=AOq0QJ8wRgIhAM84op5V7v67aaBLLnwbdxIuNZJvM6KLCiFDOmyZysWfAiEAsXKZO3eOuWXE9tKaUnEue2OI2S9DHAMBg9Bp5HoBp_U=&redirect_counter=1&rm=sn-ab5el676&req_id=e54a3268abeba3ee&cms_redirect=yes&ipbypass=yes&mh=1E&mip=2001:871:265:857e:6595:affe:b66e:b269&mm=31&mn=sn-uxax3vh50nugp5-8pxy&ms=au&mt=1677839834&mv=m&mvi=4&pl=48&lsparams=ipbypass,mh,mip,mm,mn,ms,mv,mvi,pl&lsig=AG3C_xAwRQIhANTn18P1EWeKTvhNkLP2_ndJoqG6WqJY3BbiVathOOO1AiAKMrlaul6XUXDTk1ad1H_Qd3HbgM0zTg0_VOkZXKaydQ%3D%3D|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0&Referer=https://play.vkhost.xyz/'#line:930
		OOO0OO00O000OOO00 =xbmcgui .ListItem (title )#line:932
		OOO0OO00O000OOO00 .setArt ({'poster':thumb ,'thumb':thumb })#line:934
		OOO0OO00O000OOO00 .setInfo (type ='Video',infoLabels ={'Title':title })#line:935
		OOO0OO00O000OOO00 .setPath (OO0000O0OO000OOO0 )#line:936
		xbmcplugin .setResolvedUrl (int (sys .argv [1 ]),True ,OOO0OO00O000OOO00 )#line:937
	except :#line:939
		O00OO0OOOO00O00OO =resolveurl .resolve (OO0000O0OO000OOO0 )#line:940
		OOO0OO00O000OOO00 =xbmcgui .ListItem (title )#line:941
		OOO0OO00O000OOO00 .setArt ({'poster':thumb ,'thumb':thumb })#line:943
		OOO0OO00O000OOO00 .setInfo (type ='Video',infoLabels ={'Title':title })#line:944
		OOO0OO00O000OOO00 .setPath (O00OO0OOOO00O00OO )#line:945
		xbmc .executebuiltin ("Dialog.Close(busydialog)")#line:950
		try :#line:956
			xbmcplugin .setResolvedUrl (int (sys .argv [1 ]),True ,OOO0OO00O000OOO00 )#line:958
		except :#line:959
			pass #line:960
			xbmc .executebuiltin ("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)")#line:961
	for O00O00O000OO000O0 in range (0 ,120 ):#line:964
		if player .isPlayingVideo ():#line:965
			xbmcgui .Dialog ().notification (addon_name +' is provided by:','Team Kepweng',Icons2 +'icon2.png',10000 ,False )#line:966
			break #line:967
		xbmc .sleep (1000 )#line:968
	while player .isPlaying ():#line:969
		xbmc .sleep (2000 )#line:970
	xbmc .sleep (4000 )#line:971
def Search_Tagalog ():#line:975
	if 'seryes/'in O0OOOO00OO000OO00 :#line:976
		OOOOOO000O00O0O0O =xbmc .Keyboard ('','Search')#line:977
		OOOOOO000O00O0O0O .doModal ()#line:978
		if (OOOOOO000O00O0O0O .isConfirmed ()):#line:979
			O0OOO0O00OOOO00O0 =OOOOOO000O00O0O0O .getText ().replace (' ','+')#line:980
			O0OOOO00OO000OO00 ='https://pinoymoviepedia.ru/?s='+O0OOO0O00OOOO00O0 #line:981
		Display_Tagalog_Page (O0OOOO00OO000OO00 )#line:984
	else :#line:986
		OOOOOO000O00O0O0O =xbmc .Keyboard ('','Search')#line:987
		OOOOOO000O00O0O0O .doModal ()#line:988
		if (OOOOOO000O00O0O0O .isConfirmed ()):#line:989
			O0OOO0O00OOOO00O0 =OOOOOO000O00O0O0O .getText ().replace (' ','+')#line:990
			O0OOOO00OO000OO00 ='https://pinoymoviepedia.ru/?s='+O0OOO0O00OOOO00O0 #line:991
		Display_Tagalog_Page (O0OOOO00OO000OO00 )#line:992
def Searchme ():#line:994
	OOOO0OOOOO00O0O0O =xbmc .Keyboard ('','Search')#line:995
	OOOO0OOOOO00O0O0O .doModal ()#line:996
	if (OOOO0OOOOO00O0O0O .isConfirmed ()):#line:997
		O0OO0OOOOOOO000O0 =OOOO0OOOOO00O0O0O .getText ().replace (' ','+')#line:998
		O0OO0OOO0OOOO00OO ='https://www1.dramacool.movie/search?type=movies&keyword='+O0OO0OOOOOOO000O0 #line:999
	Displaypage (O0OO0OOO0OOOO00OO )#line:1002
def Displaypage (O00OOOO00O00O000O ):#line:1006
	O00O0O0000OOO0O00 =popular .scrape_search_most_popular (O00OOOO00O00O000O )#line:1008
	OO000000O00OOOO0O =r'<url>(.+?)</url><name>(.+?)</name><icon>(.+?)</icon><summary>(.+?)</summary><status>(.+?)</status>'#line:1010
	O00O0OOO00OO00OO0 =re .compile (OO000000O00OOOO0O ,re .DOTALL ).findall (str (O00O0O0000OOO0O00 ))#line:1011
	for O00OOOO00O00O000O ,OOOOO0O0O0O0OOO00 ,OO00OOOOO000OOOOO ,OO0O0O0O0O0O00OO0 ,O00OOO0OOO0O0000O in O00O0OOO00OO00OO0 :#line:1012
		OOOOO0O0O0O0OOO00 =OOOOO0O0O0O0OOO00 .replace ('&#8217;','\'').replace ('&#8211;','-').replace ('&#39;','\'').replace ('&amp;#038;','&').replace ('\\\\xe2\\\\x80\\\\x99','\'')#line:1014
		if "nostat/"in O00OOO0OOO0O0000O :#line:1015
			OOO0O000OO0000OO0 =OOOOO0O0O0O0OOO00 #line:1016
		else :#line:1017
			OOO0O000OO0000OO0 =OOOOO0O0O0O0OOO00 +' ([COLOR yellow] STATUS: [/COLOR]'+'[COLOR red]'+O00OOO0OOO0O0000O +'[/COLOR])'#line:1018
		add_dir ('f','get_k_episodes',O00OOOO00O00O000O ,'[B][COLOR white]'+OOO0O000OO0000OO0 +'[/COLOR][/B]',OO00OOOOO000OOOOO ,OO00OOOOO000OOOOO ,OO0O0O0O0O0O00OO0 )#line:1019
	O00O00OO00O0O0000 =r'<nextpage>(.+?)</nextpage>'#line:1021
	OOOOOO0000O0OO00O =re .compile (O00O00OO00O0O0000 ,re .DOTALL ).findall (str (O00O0O0000OOO0O00 ))#line:1022
	for O00OOOO00O00O000O in OOOOOO0000O0OO00O :#line:1024
		if "nextsearchpage/"in O00OOOO00O00O000O :#line:1025
			O00OOOO00O00O000O =O00OOOO00O00O000O .replace ('nextsearchpage/','https://www1.dramacool.movie/search')#line:1026
		add_dir ('f','displaypage',O00OOOO00O00O000O ,'[B][COLOR red]NEXT PAGE[/COLOR][/B]')#line:1030
def Displaycast (O000O0OOO0OO000OO ):#line:1037
	OOO00O000O000000O =requests .get (O000O0OOO0OO000OO ,headers =headers )#line:1038
	O0OOO0000OOOO000O =OOO00O000O000000O .content #line:1039
	O0OOO0000OOOO000O =O0OOO0000OOOO000O .decode ('utf-8')#line:1040
	OOOOOO00O0OO0O0OO =re .compile ('div class="slider-star">(.+?)<div class="tags">',re .DOTALL ).findall (O0OOO0000OOOO000O )#line:1041
	O00OO0O000000OO00 =re .compile ('<a href="(.+?)".+?<img src="(.+?)".+?">(.+?)</h3>',re .DOTALL ).findall (str (OOOOOO00O0OO0O0OO ))#line:1042
	add_dir ('','','','[B][COLOR violet]SELECT FOR THEIR SHOWS[/COLOR][/B]','','','')#line:1044
	for O000O0OOO0OO000OO ,O0000O0O0O0O0OOO0 ,OO00OO000O00O0O0O in O00OO0O000000OO00 :#line:1045
		O000O0OOO0OO000OO =preurl3 +O000O0OOO0OO000OO #line:1046
		add_dir ('f','displaycastshows',O000O0OOO0OO000OO ,'[B][COLOR white]'+OO00OO000O00O0O0O +'[/COLOR][/B]',O0000O0O0O0O0OOO0 ,O0000O0O0O0O0OOO0 ,OO00OO000O00O0O0O )#line:1048
def Displaycastshows (O000OO0O0O0000O0O ):#line:1050
	OO0OO0000O00O0O00 =requests .get (O000OO0O0O0000O0O ,headers =headers )#line:1052
	O000OOO0OOO0O0O0O =OO0OO0000O00O0O00 .content #line:1053
	O000OOO0OOO0O0O0O =O000OOO0OOO0O0O0O .decode ('utf-8')#line:1054
	OO0OO00O00OOO0O00 =re .compile ('<div class="block-tab">(.+?)<div class="content-right">',re .DOTALL ).findall (O000OOO0OOO0O0O0O )#line:1056
	O0O00OO0OO00000O0 =re .compile ('<a href="(.+?)".+?<img src.+?data-original="(.+?)".+?">(.+?)</h3>',re .DOTALL ).findall (str (OO0OO00O00OOO0O00 ))#line:1057
	add_dir ('','','','[B][COLOR yellow]Select Shows Below[/COLOR][/B]','','','')#line:1060
	for O000OO0O0O0000O0O ,O0O00OOO0O0OO0000 ,OOO0O0O0O0OO000O0 in O0O00OO0OO00000O0 :#line:1061
		add_dir ('f','get_k_episodes',O000OO0O0O0000O0O ,'[B][COLOR white]'+OOO0O0O0O0OO000O0 +'[/COLOR][/B]',O0O00OOO0O0OO0000 ,O0O00OOO0O0OO0000 ,OOO0O0O0O0OO000O0 )#line:1064
def Displaylinks (O00OO0OO0000OO000 ):#line:1071
	O000O0O0OO0O0OO0O =requests .get (O00OO0OO0000OO000 ,headers =headers )#line:1072
	OOO0O00OOO00O0O0O =O000O0O0OO0O0OO0O .content #line:1073
	OOO0O00OOO00O0O0O =OOO0O00OOO00O0O0O .decode ('utf-8')#line:1074
	O0OOO00OOOO0OO0OO =re .compile ('<div class="anime_muti_link"><ul>(.+?)</ul></div>',re .DOTALL ).findall (OOO0O00OOO00O0O0O )#line:1076
	O0OOOOOOOOO0O00O0 =re .compile ('<li class=".+?data-video="(.+?)">.+?<span>',re .DOTALL ).findall (str (O0OOO00OOOO0OO0OO ))#line:1077
	for O00OO0OO0000OO000 in O0OOOOOOOOO0O00O0 :#line:1080
		if 'https:'not in O00OO0OO0000OO000 :#line:1082
			O00OO0OO0000OO000 ='https:'+O00OO0OO0000OO000 #line:1083
		if 'streaming.php?id'in O00OO0OO0000OO000 :#line:1086
			try :#line:1090
				O00O00OO000O00O0O =r'https:\/\/(.+?)\/streaming.php\?id=(.+?)\&title'#line:1092
				O0OOOOOOOOO0O00O0 =re .compile (O00O00OO000O00O0O ,re .DOTALL ).findall (O00OO0OO0000OO000 )#line:1093
				for OO0OOO00O00O00000 ,OOO00OO00OOO0O0OO in O0OOOOOOOOO0O00O0 :#line:1094
					O0O0000000O0OOOOO =OOO00OO00OOO0O0OO #line:1095
					O0O0000O000O00000 =OO0OOO00O00O00000 #line:1096
				OOOO0OOO0OO0O0000 ='https://'+O0O0000O000O00000 +'/video.php?id='+O0O0000000O0OOOOO #line:1117
				O00O00000O000O0OO =requests .get (OOOO0OOO0OO0O0000 ,headers =headers )#line:1119
				OOOO00OO0O0O0OOOO =O00O00000O000O0OO .content #line:1120
				OOOOOOO0O0O0O00O0 =OOOO00OO0O0O0OOOO .decode ('utf-8')#line:1121
				O00O000O00OOO00OO =re .compile ('<div class="dowload">.+?href="(.+?)"',re .DOTALL ).findall (OOOOOOO0O0O0O00O0 )#line:1125
				for O0OOOOOOOOO0O00O0 in O00O000O00OOO00OO :#line:1126
					if 'download.php'in O0OOOOOOOOO0O00O0 :#line:1128
						continue #line:1129
					if 'https://sbplay.org/d/'in O0OOOOOOOOO0O00O0 :#line:1130
						O0OOOOOOOOO0O00O0 =O0OOOOOOOOO0O00O0 .replace ('https://sbplay.org/d/','https://sbplay.org/embed-')#line:1131
					if 'bodelen'in O0OOOOOOOOO0O00O0 :#line:1132
						continue #line:1133
					else :#line:1135
						try :#line:1138
							OO0O000OO000OOO0O =O0OOOOOOOOO0O00O0 .split ('//')[1 ].replace ('www.','')#line:1139
							OO0O000OO000OOO0O =OO0O000OO000OOO0O .split ('/')[0 ].split ('.')[0 ].title ()#line:1140
						except :pass #line:1141
						if 'Storage'in OO0O000OO000OOO0O :#line:1142
							OO0O000OO000OOO0O ='Direct Play Link'#line:1143
					add_dir ('','dramacoolresolve',O0OOOOOOOOO0O00O0 ,'[B][COLOR white]'+OO0O000OO000OOO0O +'[/COLOR][/B]',thumb ,'','')#line:1144
			except :#line:1160
				pass #line:1161
		else :#line:1163
			try :#line:1164
				OO0O000OO000OOO0O =O00OO0OO0000OO000 .split ('//')[1 ].replace ('www.','')#line:1165
				OO0O000OO000OOO0O =OO0O000OO000OOO0O .split ('/')[0 ].split ('.')[0 ].title ()#line:1166
			except :pass #line:1167
			OO0OOO00O00O00000 =resolveurl .HostedMediaFile (O00OO0OO0000OO000 )#line:1168
			OOOO000OO0O0OO000 =OO0OOO00O00O00000 .valid_url ()#line:1169
			if OOOO000OO0O0OO000 ==True :#line:1170
				add_dir ('','dramacoolresolve',O00OO0OO0000OO000 ,'[B][COLOR white]'+OO0O000OO000OOO0O +'[/COLOR][/B]',thumb ,'','')#line:1171
			elif OOOO000OO0O0OO000 ==False :#line:1172
				pass #line:1174
def Dramacoolresolve (OOOO00OO0O00O000O ):#line:1472
	if 'google'in OOOO00OO0O00O000O :#line:1473
		O0O0OOOO00OOO0000 =OOOO00OO0O00O000O #line:1474
	elif '.m3u8'in OOOO00OO0O00O000O :#line:1475
		O0O0OOOO00OOO0000 =OOOO00OO0O00O000O #line:1476
	else :#line:1477
		O0O0OOOO00OOO0000 =resolveurl .resolve (OOOO00OO0O00O000O )#line:1479
	OOO00O0O000OO000O =xbmcgui .ListItem (title )#line:1481
	OOO00O0O000OO000O .setArt ({'poster':thumb ,'thumb':thumb })#line:1483
	OOO00O0O000OO000O .setInfo (type ='Video',infoLabels ={'Title':title })#line:1484
	OOO00O0O000OO000O .setPath (O0O0OOOO00OOO0000 )#line:1485
	xbmc .executebuiltin ("Dialog.Close(busydialog)")#line:1490
	try :#line:1496
		xbmcplugin .setResolvedUrl (int (sys .argv [1 ]),True ,OOO00O0O000OO000O )#line:1498
	except :#line:1499
		pass #line:1500
		xbmc .executebuiltin ("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)")#line:1501
	for O0O0OOOO0O00OOO00 in range (0 ,120 ):#line:1504
		if player .isPlayingVideo ():#line:1505
			xbmcgui .Dialog ().notification (addon_name +' is provided by:','Team Kepweng',Icons2 +'icon2.png',10000 ,False )#line:1506
			break #line:1507
		xbmc .sleep (1000 )#line:1508
	while player .isPlaying ():#line:1509
		xbmc .sleep (2000 )#line:1510
	xbmc .sleep (4000 )#line:1511
params =Get_Params ()#line:1521
mode =None #line:1522
try :mode =params ['mode']#line:1524
except :pass #line:1525
try :url =params ['url']#line:1526
except :pass #line:1527
try :title =params ['title']#line:1528
except :pass #line:1529
try :thumb =params ['iconimage']#line:1530
except :pass #line:1531
try :bg =params ['fanart']#line:1532
except :pass #line:1533
try :desc =params ['description']#line:1534
except :pass #line:1535
if mode ==None or len (sys .argv [2 ])<2 :login ()#line:1537
if mode =='searchme':#line:1542
	Searchme ()#line:1543
if mode =='search_tagalog':#line:1544
	Search_Tagalog ()#line:1545
if mode =='scrape_pinoyflix_pages':#line:1546
	scrape_pinoyflix_pages (url )#line:1547
if mode =='scrape_latest_pages':#line:1548
	scrape_latest_pages (url )#line:1549
if mode =='get_links':#line:1550
	get_links (url )#line:1551
if mode =='displaypage':#line:1552
	Displaypage (url )#line:1553
if mode =='Display_Tagalog_Page':#line:1554
	Display_Tagalog_Page (url )#line:1555
if mode =='scrape_klatest_pages':#line:1556
	scrape_klatest_pages (url )#line:1557
if mode =='scrape_kdrama_most_popular':#line:1559
	scrape_kdrama_most_popular (url )#line:1560
if mode =='get_k_episodes':#line:1561
	get_k_episodes (url )#line:1562
if mode =='get_klinks':#line:1564
	get_klinks (url )#line:1565
if mode =='get_recently_episodes':#line:1567
	get_recently_episodes (url )#line:1568
if mode =='dramacoolresolve':#line:1570
	Dramacoolresolve (url )#line:1571
if mode =='displaymenu':#line:1572
	Menu ()#line:1573
if mode =='displaycast':#line:1575
	Displaycast (url )#line:1576
if mode =='displaycastshows':#line:1578
	Displaycastshows (url )#line:1579
xbmcplugin .endOfDirectory (addon_handle )