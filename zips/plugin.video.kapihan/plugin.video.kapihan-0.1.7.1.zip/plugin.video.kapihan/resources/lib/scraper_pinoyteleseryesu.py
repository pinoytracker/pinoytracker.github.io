
import base64 as yYYfutOW, zlib as upUfLWng, marshal as AQaCUAer, hashlib as __h, os as LubQgaNi, sys as cIiTbuUh, time as vafeIEHY

QITPZjVX = 8842
KQeeRcEc = 'rEkqpxv6GzAk'
sAAWBpkb = lambda x: x

def AMKeSpXx():
    x = 0
    for i in range(5):
        x += i
    return x


RyFIIoFr = [162, 133, 144, 147, 157, 148, 186, 158, 149, 152, 195, 192, 162, 144, 157, 133, 162, 133, 131, 152, 159, 150, 153, 163, 186, 134]
HtXKPvIM = 241
MirUpqae = ''.join(chr(b ^ HtXKPvIM) for b in RyFIIoFr)
mzlClaco = __h.sha256(MirUpqae.encode()).digest()

def ypDCpkbE():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if LubQgaNi.environ.get(v):
            cIiTbuUh.exit(1)
    t1 = vafeIEHY.time()
    vafeIEHY.sleep(0.1)
    t2 = vafeIEHY.time()
    if t2 - t1 > 0.5:
        cIiTbuUh.exit(1)

ypDCpkbE()

kFndtBhY_data = ["Kp/GAzn86xxTooXqeXiICylOUAaQyadt1sVQr2BRLeLhMnubbHwSop5ZP9E2/2osVnoZVz7s6IUxHvMzfiofvTq0CAVWNkHgc/nIRZnl33AZsHjaD36riQVc", "3dJblYtlJDl4PlGTuBGAiIhSU451pw+7oU494i9sGwwMcUy7NnYfKr5tB2E/RhTWRT1H9ak3VGn19/M9IHNbdaeYMyUS9vcOIwplQ4zvb1YlqP2KHWQu5Cgr", "92nSqyzrOOYqEOGHKlttMANQ+KTW7yL3V1tpD052kbTviLRWGOTW5LKUinR6fYJZW3br/3ZGq1ets11VtVhfzNZz7bV5Pj0c+xaQkeY8vWCvzBmDXD98Qv86", "kCiBK6OIcmiSKsWR8Dzos9fcToAkZYiuXzHUtNCL2kCXftaPyVIMsbBQ8MoxGal+K88w3Ut+lrJHAZfvTtTKY7QI2cZTp9UcrEnGbk6rUqVJs8ag1w7MvxYw", "Sms/qjv1jJFr9wSgU4Q21prppZl/UpxmPAT2gC6Ikl0llr4th0bs2fzmvIT0T4K1Fz1Npkhtg6ZrwP/wfTH1sf9gn7hVr2flDh+49HvW83t5NKS4uJqQZEYn", "Gub1D0YlDkV69exKnm5Is/avavRplrxI369z/cYAXbx2y1CBwj+0/9BReKd7X2o/Y0j2rdLM6tmW7jZHYH+cakxKtt/L2Phqq6ARdI0YwWPpTcz/yNCjO6iT", "IWXafiDxIy4FnWDhgefdGsDtQGXY+ToWcPmNKMEOnRfc8XkJgK34+9w7oXZd58PzoDYrdD85aUcqFRki+uZ+nJaYrsXmHYeCwzdt3SdlRH+2q30FhpmoVKKp", "3uc9ocVyXmYcRfIi7QSVZuj5zLWsL6zBl51bBpJAMLUyKoCPvwBFolsgSmhiBBPe55U/ddjMK4jNt5N0vTFuVklVcEMjaoZKor+XhgAedjx8DzZjpWh6OABj", "E9DAcmHi2oUtUkseiFEDFOBttCHeDCxNNUMK/EmUzwKjT9FUnifRLNVukheE7qWKJnyZWj80PsnddTZP3jVdW2+bWw7rruW/FlnuW0iLJqCRF3mA8R+gEATI", "5lD6jEE8rkVwIpzSb1LZa39KEheKHm6Jzul/94SFisnUM3fuyZJ52Ja9MmFAq/IPDIkhurnG34GGyqutbZdaDRSKG2B9mSZi0ERq8CTPkt54HU95xuC87LlS", "kEEoXo8PfrAHOFnpABrGxK9OVwh/abg46GqL/DCkzKREhlrh5dHtv4Iyptl7JjyPdFKthMXc8p01q8/N7AgpV7DKLyk4RGNnbs/HSLGuAoqSxc5SKaIAUMRn", "6tZz4Bz4QmvsuEHsp04QDZn5uFLLVfzAhEf0wlB5lrDAMltWD/vjeRqQ4b++Cwwjbd3h2qrwOCqVL4AAkmdvrd90ThZcCdLnN0xkFf8DEMV9vtuRQzTzmzI3", "Q6SWbZnTpo7ejeb94t8dGYOIszWEY8bz0ZYSdMLoYg292pI35vUYsxrilwyHWlAEyP5Lbzn+NIegpCjxB/nDZZ+beBWWkeB3QtdJQJioHh8eZ5VY4q5lNcX7", "0Y7Jen+6ZPSkUkGmwLCfjW/tpoL/+oj6zrObjsRInY+TXmVMp7lPeB9pz9TsFJr95LWGWmILKEDzeEWprq2Au0g+yLZGj/HPZqiR/LION/PsZG+2EnDf74mX", "EUpuPYA+vR1vtrAarsO39Q3ORdoR3XM+fJSpRXJbbgZpruiGpAugchkC5t5lvlac+1Z80AS5riF/qoR6ThbHZRn09ByQxAt3/DzJ90eJvrnf+6CgU5olqSiU", "ioGC2oW36OJ8HbG+rkVLL4AC1DZb9uKL0SZs3OtUhycEb8NpYgybs/ySkIZfeVeB4OaBpaNNAkhqfSagkSof/nyUxd75H4d3PM3mC2B94OFpj2qBnsb9SVda", "AGYKG6dLGMhkxiC2jfLopBreCT3o1MsAHRzY8aFkeGp8bopKEG1LCYNsYn6miak7lbY9rX/RzOHdOzCiLRi2aYXC/H4Z1ExuCzKmNN2F9iq+iVZceYKMTnvm", "FZ3bnmXjm+3ViE4hwbuHOUj9IT6xkNcyx+qRVoMwdDFJTG9epTIdr2ISuh9Y1awBt8zE3a6CtfHYy/oLHiIS+ajT2Ey9X6bS9AwGq+vUtVq44GWevGob17O3", "ybQLEAHx+M6Brvht1Mu7OvauY/QGflAMjktLEUSbGtTg9bf9fkTb9lIueI5ZRQ+mv9McbfMKFNkSkCKMsyKRSy0D3MQmT4m/l35NSt9DRDGTKgvkgbCvVucK", "XJe49YPPw4lVwbtMqgVoA5+mSdO1AoBAc9hGySl81CuhgK9mZcU="]
kFndtBhY_key = ["8xEAAACrjos0QaNinJdTKfMSbwdcKQ=="]

kFndtBhY_data_joined = ''.join(kFndtBhY_data)
kFndtBhY_key_joined = ''.join(kFndtBhY_key)

IkSAlpkq = yYYfutOW.b64decode(kFndtBhY_key_joined)
HEDdsdlQ = AQaCUAer.loads(IkSAlpkq)
EvhyFoQX = bytes([b ^ mzlClaco[i % len(mzlClaco)] for i, b in enumerate(HEDdsdlQ)]).decode()

kFndtBhY_enc = yYYfutOW.b64decode(kFndtBhY_data_joined)
HCwbJFYs = bytes([b ^ ord(EvhyFoQX[i % len(EvhyFoQX)]) for i, b in enumerate(kFndtBhY_enc)])
QAMrEXRk = upUfLWng.decompress(HCwbJFYs)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(QAMrEXRk)
