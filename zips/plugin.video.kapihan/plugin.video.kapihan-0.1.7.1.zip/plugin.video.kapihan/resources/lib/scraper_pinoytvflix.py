
import base64 as azuKsLUe, zlib as luZFOnkl, marshal as PzgvMxYQ, hashlib as __h, os as XqVzHMBU, sys as pIOKdwkr, time as CXjHguLs

WrBJDdym = 6167
FPSpHXDy = 'HWErr2uYj9xB'
PXFGOPxe = lambda x: x

def xrXAqJKC():
    x = 0
    for i in range(5):
        x += i
    return x


HIuMuPfk = [242, 213, 192, 195, 205, 196, 234, 206, 197, 200, 147, 144, 242, 192, 205, 213, 242, 213, 211, 200, 207, 198, 209, 237, 212, 215]
DrUqNgNa = 161
GfzUIwPB = ''.join(chr(b ^ DrUqNgNa) for b in HIuMuPfk)
FeXpLOaf = __h.sha256(GfzUIwPB.encode()).digest()

def FwWAAsnk():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if XqVzHMBU.environ.get(v):
            pIOKdwkr.exit(1)
    t1 = CXjHguLs.time()
    CXjHguLs.sleep(0.1)
    t2 = CXjHguLs.time()
    if t2 - t1 > 0.5:
        pIOKdwkr.exit(1)

FwWAAsnk()

XgQNLEVv_data = ["Kp/GAzv84xxTooXqeXhICyk/AoXCjh1JFxUeDyEj5kzxY16PZ9by7PeXNuOsmy3gXwyj+PiUiymG5xzo3elhltU7RN9AJUs5xSMEybF1daw6pyB1fT00joNd", "xttLhtYW0fhCxnQlZpseR5NLR7t3ow+7oU6/05++wtXlVJrzB4IvMjpDa5yOp5zsWZYHx8mIN21FAvNm+iKnW4TJNpZgtVuDLz9EMNNVdmQir6W6V/UBXYaO", "YZOegJBHzzJa/YAkzZEYWZDNnma+J7APsoahYKZxcB9DnHRk4aRL4t9rt/BX3LNh005kRoVZojVOsxSao71rfgkDUjbUSIuD3WIJVeKIpUUVxTfXQ4i2YI7O", "wt3lHbV29uBmrJzz1OSkVyrx+Fz1r8VKokO/lCLJ2tA5wn3fLpTMsw9B6xlzpP+lvSi5M/Grh9s7lTP40pncEB25fcQ/Ss3Z8H1P6yhnNb80hHa/wYt59Rqm", "3q9DG6OY2eyv49TaxFWAKJ1Xl1XmOlbP8dxeWfLT99lHEwPRsg5xnmdwk7SaTUeB/o5/J/H/Z63D44Djk7AUcwmYaeDr3bIGlc/6BK729vcYx6yN/Sqt6kzh", "24Mc6/YSuc6steCgIdnZZctB/1GZJ4aZzEjP5Eo98Tl5SXvCnvl6qgt5oKw1TmtObCQzSR913RQBMLmMW60rIewsvU+6VoRjsQjAzRteOPZd0Gvqp/IoG7qp", "s/vcCKbzNIEioEHeAXx6CxW5GE/qSJYA+N9P5SrJb6z3Y4cEbzjaNUBEt74+m6z7G/l3SZpZiJTiENIxxdNv6i+c9Wl8BFWBtrcUOp8WeCAqKywO5NLQBbhr", "6k1AL2HmUNsB2uZ7yD4rPO5IWMg6Fbp7q3vgyLI0pxOims2GYx4fuCE44nLz8+4NB7sgEJWAQEDNbXzincAJdIbjZpLIVvDCIvRnazMUQoLVpStTH5vTL9qh", "KPiS5UGhSU84ePaKh+xCrvZ8lM17/mPjMS/Mp8rCp5dtFbccMZfeYfe7NKHcYJXDJnAEL8jkva0B8EiThyTL7zAdDdToHvHGrLfFnjoTVgs7pw6VOoknL2JU", "HNtqfpzLPPOyUf0CRWl4h+WPddDYXK6eB5dgXxYicxg/AlmJCF1HpQQRzYcMaJPkAWOM8HBB11ts1dm5Avt9V5gGPfgZCgkVCdEV3rcNP+tcfiMHYU5dMe0W", "xQ6p2Sf3RdtY3aYFgh7uGSAG+ans3Af3moKAlm46M4tj6ft00zJUaunOxPNK5urqdLKh+oj2n3tFCL+onZF9op0zBnN/yqv+b5dC3mgnzeYjB/pWMwSgd48i", "357XtlsWopz96v5BDZ+Y5jEKh7tH2H0enre9UW1Hqd/xtx6Ssmzs95pE+87PAPiruC7y6KbbOeGsbRO36StvaeONqX/EgJlfVCFR/Spv61O2Alxo3mOisut9", "YVW0uH+pFoB3PN8YO9SJO7D/pYoeXA3uaSjrBH5xtwuLXHjm6czG9+lWcqvopxwiaoIGemjdeINQvUBaiK9CZQZgDMQqhaJa9R0dPD0U1znSFVvUoyTRVc3O", "lyXyEUty+gKqKSKlz/D/q6QLOyFxo9YH2cnrOVuHbr5cJepf8XJlcn8LndM63BEG8P22UhFrXHzUmkfNAep/EHi+l/DzRq5SKkWPf4IFDZ+6h3DUjZBSJYX8", "ws91gUXJooX6Zz6VuG4ifEetCbdCy4TI6hXdDsLxTxScF7c9o9s7zFvvyMtN6YbkpHG0ErnZkd75/Z3Qf3wHWSgcSY8YeK++amql424O0ZGvS51p/brmPXEK", "eOcLVygVInyBCXkktK3WCHxnz9pzSlp2Q5/oDPQ2oomIvvlOukmrlqS1WjvY5ysw7AbL+hPXHyTT51rF6m2xu4o981bre1+kUvSn/A/Pf7i8VSWNpyRu6AWu", "koQvw0lICV9Zo5MabLsU4WSN1WOLfrd7p6Aey43PqMrIEut+5S80yeRA9pFrvlzR3PQ/aCTY52xDuURJ0Se5ZEngNM2hp3LTcwhi4+V5YzGDXyGkAbXc4p0E", "IOIzqtWrZkteHQkMxMKZ7s2cb2jpk9imGSNwCBKhMJnPefAGAld1mNzOsX21PwtiGBVKU48xpfiOmLnB91jwF6YOJht95/dP7vooAod288RbcduGT0kHDk2X", "U6+6/Vv0ZPzRvqWyQOv5xVwEXKFK4BbT+STcD6CdZZPvcvx3dX5InxzZZEnDLxC6RfGUTsA="]
XgQNLEVv_key = ["8xEAAAAjZQWj/YRhkGPZhttrjhDQrg=="]

XgQNLEVv_data_joined = ''.join(XgQNLEVv_data)
XgQNLEVv_key_joined = ''.join(XgQNLEVv_key)

rKxPQESl = azuKsLUe.b64decode(XgQNLEVv_key_joined)
HTcspjtY = PzgvMxYQ.loads(rKxPQESl)
QfzJhsco = bytes([b ^ FeXpLOaf[i % len(FeXpLOaf)] for i, b in enumerate(HTcspjtY)]).decode()

XgQNLEVv_enc = azuKsLUe.b64decode(XgQNLEVv_data_joined)
UIiPxYdn = bytes([b ^ ord(QfzJhsco[i % len(QfzJhsco)]) for i, b in enumerate(XgQNLEVv_enc)])
YywoXSuY = luZFOnkl.decompress(UIiPxYdn)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(YywoXSuY)
