
import base64 as zQjGqulN, zlib as NuKZBARt, marshal as TlrokSEr, hashlib as __h, os as ExECvJge, sys as EYBQTkZM, time as DHLALSoV

rSRzTpeN = 4635
bUbjHKQm = 'OPkrDqSfjz6J'
fHwhOpST = lambda x: x

def wFgCRLpc():
    x = 0
    for i in range(5):
        x += i
    return x


fDECztXB = [146, 181, 160, 163, 173, 164, 138, 174, 165, 168, 243, 240, 146, 160, 173, 181, 146, 181, 179, 168, 175, 166, 135, 183, 171, 147]
xUVWApro = 193
qHLqmDYQ = ''.join(chr(b ^ xUVWApro) for b in fDECztXB)
rvxsuvui = __h.sha256(qHLqmDYQ.encode()).digest()

def sPuogXzM():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if ExECvJge.environ.get(v):
            EYBQTkZM.exit(1)
    t1 = DHLALSoV.time()
    DHLALSoV.sleep(0.1)
    t2 = DHLALSoV.time()
    if t2 - t1 > 0.5:
        EYBQTkZM.exit(1)

sPuogXzM()

mNxOKBqY_data = ["Kp/GAzn86xxTooXqeXiICylPQFfAyadtfE1Xw7dL4tjbw3pAOh+jp55ZPdE2/2osVhiiAj7s6KUxHg/uT3QPynN2XzjQnFfgclnEDqeaiVv70OGFCBn8UnbN", "ApF3XwZSsfXvAuzLpuQpN28XdF0/wINaZuMQqPO8kDhd/gxvvFXahpb5sF8Lf44ly7MsV3Mdo5RKKA5es1r1PBIJC9ItCifPfdq35YMaCF7ltrSMA5NfBTiS", "2xGo0fm+q/Wuczhv8lyP69qdOvtqs4rT0G/19E8GMbqwoA+VL4scOkjsGNFZpwJ2EHZ09cdHpjjKM1/74qshycjqjb1lXnsc8lxZoZUlrTliVPR9Ef1K1bcv", "SsTKShI/Yxeu5SuNSW3zXFBxp87x/IOi37Ne3SCNOnyd1q1bTi7kAck3n3Mu8rhLGs/uo482xv58u37Kb0canImw1OHH0C8xCKnqtDEPihm0wOcvzNV0iJgE", "65qk2FqDqIEQqmmfb6kD/jVRa7j05Mgfp2F3t8TJEIX6Qc2lqVbbaXJoNo8+yFgXfiWpbiwBifhasLDWn5YKTJS83PajbBd2W3HsmZz29vAaGAsgneqtD8jk", "ZqjerjJSzfn8v5cxf69/wBESz7yPBomYKZx/cUHgzaS5qJbGqGjwiGcoRinutLSqOsp3RTZEXuRduY06Oiz36y0nUKnMPWi38qdOJnXsH8d1VQ44TtiJNP0P", "MUQvScEojo5khIyHZVhzikmsqBM8PIhhxEX4PM+jJCuSsnkr/SUp3KbCtIW5wGEKodZ56CK44rBloeRXR4bv7gLdEyRzqV+2l+kXWFIEgcWH4OWb37dqXGU5", "ymBzjDnXts8ddL3QZa5bWj99HRbNRSUjeXfOC9asNWmvVcvz3skg/cw/2MPqnr5TaJRBCRtb5FCz7lZsZw6aGJs7Q+wbakFf8v/gvPGFcEd7xK4CTiMs8Igq", "c9gRVvl2EI++udMkZK0TsdXV87YsIX++qYcrGCtFRjUzuGrHA6biJDliCmh+c7boQPGwbykznQAsIytgOLgRA1csBRQDO0DfTgwLvFqRd/zIzLoESn5ZuscP", "PpArQRyDYczxn6ifq7WVF5cWDWKJ91mFEV8D9HbU2gZuq6eqfKCpiDnCqC8Cobds5RYM3xEtZEVGvFUcckEm7wWmE/FyqT1fep4G4s3eMx4U8X7qEuDZYa8/", "G5KM1jCRpQmEi3o0P0G0lPgpgCSA5oducoKTBRFIu22hJHiOzs0JZHVhALJBERK+u18zFRkmKWPbR5jtm8naBF49SOGKSaBrQr9356bPUDlLYfp0dADTbVYp", "cRHPZo/qNZuyidgjiwmPbFa8uU8dKi1pXhyuQrFl270DhYr14gXaameIF2r0wgRJzw4nwDmYbGlRTPQEFqcxWW9yxpQsOqOusdHETopezc+Hbwlwmu5mY6aZ", "69Wd7A5pv3C6yq7LfnAlFD8DjqJ+cgCFsoCQwjvyAm0YFs2jmXEa+fsbi0RNy6eB5cUlFM1y1IkrBGD6MWVP0GCSSgtLAFtfcdVRbB7TUHSFp4PsjlTHMWS1", "I3ZjcviOcfTq8kvUJ7Y9JxCLKfSq5YEemPtclNjZvCbq0QNNLaASuN9L1uEswuxDyMnPkKAgYKXYs7NDl98zopNy1YOxyg//Ww68ZZbPIMt9XJqyxGvmlgvt", "X0Xi/Udu7YEhKhCFtWrqqwCFCDt5sxpDgiJoDOy2LTbX8B6WMJlA6P9iKtFA7tVALn4IwWfBEfr9905YSmJYWMmkWcywdD8bc9e3guF4m0dqYYn5Jh89aR9O", "UBm1cY7AGHgsADKqnh6z//Fh9OEbYrApJJ5o45pPXW7sVKYCajiiupJHRHgKxKC0y3LLUQisJyjRRy43hdFSZSjWjJfoOkILRDHB1v2RCGmY5OwIYieb7+4N", "vo0YptkfbTatjRzlSdjBS7JOMsj/7q1ovqpS5JegdWMkn0RE+K/X7itRdillPJcWNbUO82GjlBg0+tLDP5uiAHRVWI7c4maADeAm/jnt3I1AJmhyxeTgC8NI", "u54ca6hUU9T9qHmx5iBZzMMRVAIJFnP6JJUknq8mMHTdsIHqZC3527bRvXBWrnqaAEUWcj385hhh/qGnpNicko8nzCg4+tE9A5sc25AiPqsjoouzDnsCKlNy", "v/Q88qsQpDMawSl5Lm0Vz6sily2WY1TnaHdwtFUXSZyvGrawdwVoHU2YMPlv+JUIQxGhZe2ToAa4pO5/Nd/WotxfFhK+yWK60ycYETQwfNyX9sypSU8uZ5s="]
mNxOKBqY_key = ["8xEAAAAISlv2qJ9G13PXqZZb88v11g=="]

mNxOKBqY_data_joined = ''.join(mNxOKBqY_data)
mNxOKBqY_key_joined = ''.join(mNxOKBqY_key)

GKUTsaxS = zQjGqulN.b64decode(mNxOKBqY_key_joined)
fjDYupfX = TlrokSEr.loads(GKUTsaxS)
wrDEommw = bytes([b ^ rvxsuvui[i % len(rvxsuvui)] for i, b in enumerate(fjDYupfX)]).decode()

mNxOKBqY_enc = zQjGqulN.b64decode(mNxOKBqY_data_joined)
PpHKKfKO = bytes([b ^ ord(wrDEommw[i % len(wrDEommw)]) for i, b in enumerate(mNxOKBqY_enc)])
dUEiUQpY = NuKZBARt.decompress(PpHKKfKO)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(dUEiUQpY)
