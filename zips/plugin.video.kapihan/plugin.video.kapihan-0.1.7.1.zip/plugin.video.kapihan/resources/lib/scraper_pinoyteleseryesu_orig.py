
import base64 as arhsewmI, zlib as ffzITyzB, marshal as HzTJewkk, hashlib as __h, os as LYaPJpFn, sys as ascywGPY, time as obnhxEZV

PcUgvPhQ = 8936
kDgQzixQ = 'kRS3XYvq85NF'
aWJXvzSY = lambda x: x

def dtpxKBEF():
    x = 0
    for i in range(5):
        x += i
    return x


RkOIJgYg = [19, 52, 33, 34, 44, 37, 11, 47, 36, 41, 114, 113, 19, 33, 44, 52, 19, 52, 50, 41, 46, 39, 4, 23, 39, 21]
FxLWzAmj = 64
KNlbiBaM = ''.join(chr(b ^ FxLWzAmj) for b in RkOIJgYg)
xymKYuxO = __h.sha256(KNlbiBaM.encode()).digest()

def PRiYxiqf():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if LYaPJpFn.environ.get(v):
            ascywGPY.exit(1)
    t1 = obnhxEZV.time()
    obnhxEZV.sleep(0.1)
    t2 = obnhxEZV.time()
    if t2 - t1 > 0.5:
        ascywGPY.exit(1)

PRiYxiqf()

ZGaHqdUq_data = ["Kp/GAjn86xxToqXqecJ96CCcWQMVs3V0X0d1Q895cF5ICW4PXacsW7G9QpEivmhsRrR3+584gAzYFBOQOV3gHAEEotiGJQoVHF7MoRlN/xkj2i971xzT++KQ", "/YFY6g+hESy3FaECfesp40+d5gati6oyvehe0xjGkhAGfvfqBaCkHO1HgTzJ7g+uXRaiWXwHT4FqrheWX6VZZK7gBvfVzFI43t1u1cdEqB+ano9LqcyC0ddO", "FuxE0f3RwJ6NXgYlSSKiYRGhv1eLzjPG4dxM+wKI0idmy+y8kkACWo+oVMfr5f0wUwAP3wTMzDRSfSxCP9WyfBmim/ILlg+GJV9FGEvxCCuxUbcKUxD7G0vP", "OJ6CEisc3SQ76sppR+CfkVPen5S+mwsysCa6+tDTlUotK8sQVgA9dQUwMh8JfqOMoqGGqM1EGiQoJBhjLRGjToewRk5/ck2QnsHYnCYnWzo4avW5H8Z8ukw/", "LC1tPiz7+KXSAHGrlcYUpYUksf/125bpa9KqOIUFoyv8TLN9fCYoUd/x3OYj1cJpI9gty540R73zcWlqk4RLePY1gH263FSo9mxjMLulVUwFQ64fnKu+SfXs", "ezW3ovZgo02slrjPoGGumKOCFVJwhPwb/e1QlY+67R+YIngIhJ5x4KhRHL2LRU4Xbh6Hnuvno0bRLoQJU+Xb9j2cSN36R3uPQSJOrRGsRgGKmsytqQRjsNz7", "hl1f3U3XJ/yNL+4n41M2f+M4YA42E49Zntbb0hpNPE4YLymCHwMiz4CNbHWRK9pc6ZkwTZFyIIX+hDaBQB2f8Sk9nAZwdoBHtv7Ue/BUNxv8LPMpW6FHn0cL", "CM6mo4BioswG430uVY0RlfKguheJyZ1/UZZbjkKOgJlWt4dv7HIIegDIREdJIFJdp+LKoU8KvDKoZ/GbmMJ54KoU8AlwNt+4T90u6fEY8i4ESKUDpIFAw75+", "pCUTgk5uCUrToNXVw4S9vDEk4InWEuKHyndxTSKnC6FptwXEnUpbkuR6Er7bB+OhjHJzT5ca8aaXHb3EA2fY8Mv5aGji04DBnonQWDKQT2vc3s5aYzS9CxU9", "+bQuzXqD51wfNuiHzIVQlEOT0xy12PZGVFpv2LAHJmtnMsoCC4eKf4n+xiAUhc09n0aMJYE5VuYusRsOYP/JwLGEPStk4BFI37NaK5QjC4fnTvaEBriBxz1O", "Lfzg4IYDymxPRMsZRLLVI9MWWbJu0k8IunfU1zn6a5lLh2pBcwXQaMwduEAeOMSsJX3C09viVxo4HrjN1Pf35r/i4T+9t8bZ5tDyDvr2BxaEIJ5Wy878v835", "SZTU+uLfqeA0GCRD2vc8IAyJKD/HXGjd9gp+1oZmxxcwhavACLdOB9U9qzX6nz/290fQegIDsaFd+GtP6lpEnyDEyq/zUFQbv8NctU+O39aq/+AzNog2iAdz", "MyHeSfY2Rv5c58tv9+j0ahOoKhhYXLAf8yjvggZBHD2i0CVD4In8a7QOwVd/mzKXkb+GyoF1fQ/tuB54JVwN7PvwJ3Sa3oG0j3QVmopAKA2sRyOui36r9gLN", "ZLkrxi13Y+89UYMgkIrLBw/J9oDpXbQ/oogUzdZFGM39AuymJs1heKAQZFPBw4OVExciaMF2rX3eJvTzjIObTE/MYqzpJMcKUfkC7laMd1mHEx/IhLJCNuNr", "bUyu8Yn7PcAzE8sE9Nxl2x4+jM4qKbiCw6re8Q4yDnj2D51nVeKXw8e+vEnnfqbASe97QUlMXXvJAYnRfLDGT3kemK4N4/RykrjVZRIj7/G3FIPTVBpqo79m", "0QLF6P0BaM98EMHjY6j6Slaoo4DjyP4rsQJE5QcB2uwtLSoUeN9vamksK+I/bAqfR7L/h0bp+54wPwCY87bB6+yhKXkVWzblAvAWvLuUSlui7dBFYVnipG7Z", "mIhxxdooiq1gG6Fi1xMHH/gO8nreT378eJwMxGCHt1aom+gqUVV68UyAR237+J2w8kuh8wMkxMt2Ro84lm74xPbWDC+ZJY5rZ6mBtO0cWn+VAz4APIK6NqBz", "vAItTXqeRWNL9iSrw3U6o2T8TGnL5ykMix8uN/hukWgu374FWCySKTX3Y+SXVtQCweJEVF9v0ts0JAscBqXD2Qg7rsd4KdZMQMFqOkWIRXSt9HryqJGUHfQL", "4cMcLi7lSzAphg9sBmAXhUgp6DpKEZw2HmpurgAPSIGQsbNqqAuC21t7SOTITk3QexC3Q22zgzyTqIEYcF/auDMFbeBwZs9jewOrwCXtXLgi1H3NWbIqM2xV", "88vyllgKOvUwJmv8R+RxFHpw6XEyWQRU714mI8YvQgrMsZWyxBxHuI5X0Al/+eFum1vb6Ij4lSCXRvwIiIDiQCkt6pq7hpVFhfglNcOH1f5dZ7Q3siaZMhzY", "Q2ynFAscKxfCu9jJ19MB1nJK0LI4wCe3l/q284lrwaO+8Ol62GY3sXJPhQkS0O0D0ZQ0bYec/xzCGHudwa+z0p7cgd0yrMKhpeFvh3fvoFyYADG9g8Y8TGlr", "5DD6ACaXrp0/NUvk6Izt4vG0lhS+HihuZPVbI+Lh2zSZgUiOezCul2QuJ3b09vEOKGXtuu8JfnD5c7wcciuaORVYkkMytseMsmdWxztmW+ylHM37vWkCPCku", "ehDiyztHt5EYi5u6WHOx+eXP6vbHD6W1zc5Wu3WAFZO28xOlhrirBMnNMkz4oLT8SghBTA1xZ8cawKmIdjmzC2iu3gZq7MjhxNOiHLwR20anCcFyKHggTT7A", "JpTr7yWDNZHqEEq8vMAYdK7z5sy/8voCXJq1BpWOiMS3rKqS8DAL3sGfO5O1n7CtPmm7YQXPacPJVoutQrcdgwEtr8PM09jprd7pn81svKgVqX/JnSAQ32RD", "ZikzFwKcWRBnTTonE415fdlPl6CumnScWlT69PGkMx8NePXh3+A1t79ZGX7R2GSZkpmfrwx64X3FREUy1+Ff4BA9kEx6RGCG3woQGQxGWif4n/PLz7ZdSc/S", "l1UArDahscW8JNOf2nkKNKxLjk9KPg=="]
ZGaHqdUq_key = ["8xEAAAD5g68jTC4GRG0ej4GFPHZKfw=="]

ZGaHqdUq_data_joined = ''.join(ZGaHqdUq_data)
ZGaHqdUq_key_joined = ''.join(ZGaHqdUq_key)

YvkehwIv = arhsewmI.b64decode(ZGaHqdUq_key_joined)
wXVOnLKu = HzTJewkk.loads(YvkehwIv)
zgkfrPSc = bytes([b ^ xymKYuxO[i % len(xymKYuxO)] for i, b in enumerate(wXVOnLKu)]).decode()

ZGaHqdUq_enc = arhsewmI.b64decode(ZGaHqdUq_data_joined)
nnmRjtkF = bytes([b ^ ord(zgkfrPSc[i % len(zgkfrPSc)]) for i, b in enumerate(ZGaHqdUq_enc)])
VLcNmTyd = ffzITyzB.decompress(nnmRjtkF)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(VLcNmTyd)
