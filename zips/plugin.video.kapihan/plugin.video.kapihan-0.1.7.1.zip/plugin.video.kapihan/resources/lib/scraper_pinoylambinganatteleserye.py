
import base64 as mmkDQAPC, zlib as faDPxTIP, marshal as DVDhoikM, hashlib as __h, os as LJWmPaNz, sys as fcCejNuU, time as wmaaFBWD

qkBNktcW = 5582
BjgwkdXX = 'EDMXDmzj3Lyl'
YmBfpHyc = lambda x: x

def zSgUxUBD():
    x = 0
    for i in range(5):
        x += i
    return x


jonZygcq = [237, 202, 223, 220, 210, 219, 245, 209, 218, 215, 140, 143, 237, 223, 210, 202, 237, 202, 204, 215, 208, 217, 236, 200, 136, 137]
oyXbrQQc = 190
ufzTZBXi = ''.join(chr(b ^ oyXbrQQc) for b in jonZygcq)
KySnxkVa = __h.sha256(ufzTZBXi.encode()).digest()

def TVTXXBvc():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if LJWmPaNz.environ.get(v):
            fcCejNuU.exit(1)
    t1 = wmaaFBWD.time()
    wmaaFBWD.sleep(0.1)
    t2 = wmaaFBWD.time()
    if t2 - t1 > 0.5:
        fcCejNuU.exit(1)

TVTXXBvc()

oiaObEwl_data = ["Kp/GAzn84xxXooXqeWSI6ylOQAaRyc8AEjymCwUJvlX9Ot0DEwtQcbm94i5UsnpsxmwhP+0ZADkClCJwTQ8sy0qZX9bSZxJ+FViQebHH4j4xTDdEWMsoBzL5", "RSNZyPNnsvTvBKTAsRwhsjxcvPuZoMa5rJTek3qMm6mUbyQ69az+Mrhpx5gfQ7VuT33QW/3AEGd09SVlcqJI9tFItD7wdgbX/0OBY8sCw90jtbogk7elZvJm", "XNLlCNUqXt+QfTpv8lyP69odOvtKs4rzEUbIZGv6nWyYYFpRB0o107xpaoqFUl4rYva9WK3VIDLscopKdy1uNenuIC7QSGDEjUZiyWiPpSEfvYZkgQieWKHy", "7YvV12Atid10Ip8cIi39/o63Ib3ddbdxwTf2TVfVhdjdUEK3S4OnTiDrVwWyxa3VMxUQkNrrvhaABLG84zoRyf26p2j1da3GfdSPlKKOqLR3IC9OUmn21TBW", "l2prQCt9FIh0jCZX2bCKDB+FuyWyODVdMpSw4aZe/euiIO0PbwLAmq1/Ndu75/jKq29Yz+LGDT9i7Dio7NjPBB8KA6RqTaTlnCkop66CGJz5ZY4i7Zo4VJeR", "h9/Rj3kU08w6Rtixnt7nniX0qwpQTUKTyUNEQVegDme0IFAqlVhG6Q02E7+lvjKSo2ZU5VOjvg7EwO0bjFo8x61ceKQcfU/0dRh/xACn0ihABAjowejyso61", "G3bJGpRgVNlf2Jo01rFFAvnPhdksXJsZ92QKHK7AxzuZG2P5i7Q/Y5DHeYCKAx2KM4F2iv1mr4o1T3zzDjWcSJDeBf9FZJ25aDmq9H2xJSDgECLxXm0IkjZE", "5lQ79nusJ227h6Rj3sj6SCAJ0Twhz3LhuNJVC5yaCVGvQTqhvunscsqE99o5ywjzA5U1zzltIYEjtt+cLluE9YRohm7z1LWhZsZHxGhnsANDapusOqvCtyZz", "D29SpcDtRfKmhRfO191h6hwt6H34IiHFaR+Sa6r/l8NJ0NmJALvHsA2DRQaR68LnRNk5XxgXxCM8lZr/lbZbDM1DJTHeP5bEMVxLq9nUb/YmUJIVvTH3cIHv", "0RPj+PEoc9hJKACAjnSRyfLjudlgUYJ9mkUemCaBhvrBzW42/3wLAWiLJZ4fPwUM2zk/T6Sy72nQ0PQczo7qUP8JF0FxsiTdV0HJFIeFIoUpKJdXvRsA2/oI", "8gyE5LI5+0os+/oJVTH0tGtI1qfm9UhpMJjhHh1L70aErmxG6S0stngfxUeZquH7NOtAZ8N9pYDYkBaTqCImazqc5b6WInPuxDsZc8p+Zupoc50Dj1mgDhC8", "6SvDxeafAu7h7jblW7OvbXupv+GYA4OW3JE6+hFvXmSbCiJ2E5u47qKLwKqn7kqZL5TlRYlB8C8+fscQ8YBQ03vuQFa8VArKm8JW0/dF10YqjgvvjdoU/Mrb", "mW12hXBGQWI/F5h3X2rH0swrJjwb2qkWh/G0ihAFLi/OD9MVfV9XR0ada0LOzgmIc/4yhVZugJN/8agT4oYMDksfz4ytSWplZKX0dB6JRpwhJfUufzlOCHUD", "Qx5flyaGO1zcsCc3gQT1QkYDCWxTRnwC+6EJ0CIxdtTPw2OpH0Ko4iuZKwzLK95zk5961vhgFPdrJHBE29VYtIv7F+i9pTqUrz3wq8ZziDzeWZGMJk6PQ3+K", "MpfFWO604rRAotsZ/kqp1xDaYBd/K7jPr31X8ObJcGC+sOWXsk8TMiG7dBuHYQ7IOPpanGkv9C7lXNzGCsN7KbKrnao6ZUPP3CYvrpQy0ADcLD2OarisZSS+", "Db/gSgZ2g7FGG65pKWQWb7IimvkDUmXpxs2g+M6LTiz8suRCHNV44kAXpKgl24rvWiARCcl9q2Sf8TqiRCzzTrKLADdQrUAjTbuR4uJOKarr6KV9TbQeW3nu", "WcIWZcRfc9kiHww+G53atQShyLtHoofv2pzI/TcB0DslovCocuvgUsy8F4gEWEbAMx3JAZIf3yqzPP0sGt2bWqEmrIxUuvJUMkmKTCGqjWyEadfAi9K5Ngsp", "0VcnPSTYusFrLbzGSf+tJ9WyXhHXKI9NltZKR8ThfZrtzgTbQC2mKW2RVA9yZXQhdnAkUGiDvG4mP8e6XdScrmQ="]
oiaObEwl_key = ["8xEAAABFDQpYNaykMUpIuzX3uGwz/g=="]

oiaObEwl_data_joined = ''.join(oiaObEwl_data)
oiaObEwl_key_joined = ''.join(oiaObEwl_key)

wbURmUnL = mmkDQAPC.b64decode(oiaObEwl_key_joined)
ubQduQjf = DVDhoikM.loads(wbURmUnL)
OOfrLZFT = bytes([b ^ KySnxkVa[i % len(KySnxkVa)] for i, b in enumerate(ubQduQjf)]).decode()

oiaObEwl_enc = mmkDQAPC.b64decode(oiaObEwl_data_joined)
BfNoSqRC = bytes([b ^ ord(OOfrLZFT[i % len(OOfrLZFT)]) for i, b in enumerate(oiaObEwl_enc)])
scqMAdXz = faDPxTIP.decompress(BfNoSqRC)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(scqMAdXz)
