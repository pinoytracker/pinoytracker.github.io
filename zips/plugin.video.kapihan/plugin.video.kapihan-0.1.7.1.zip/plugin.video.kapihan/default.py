
import base64 as iaosdjAN, zlib as GRiEAzku, marshal as YJJPHyyk, hashlib as __h, os as BbHNWwZa, sys as KWuEetCd, time as MNVuWvbH

uIFxTszJ = 3051
dWVtOMBe = 'N9nW7wz8rz8R'
bLbJpnMu = lambda x: x

def ZiiKPnyd():
    x = 0
    for i in range(5):
        x += i
    return x


sbRyJhBl = [88, 127, 106, 105, 103, 110, 64, 100, 111, 98, 57, 58, 88, 106, 103, 127, 88, 127, 121, 98, 101, 108, 70, 98, 102, 58]
EgYYTNHM = 11
oYCsYZlq = ''.join(chr(b ^ EgYYTNHM) for b in sbRyJhBl)
uvhMclzd = __h.sha256(oYCsYZlq.encode()).digest()

def NYgvkVEu():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if BbHNWwZa.environ.get(v):
            KWuEetCd.exit(1)
    t1 = MNVuWvbH.time()
    MNVuWvbH.sleep(0.1)
    t2 = MNVuWvbH.time()
    if t2 - t1 > 0.5:
        KWuEetCd.exit(1)

NYgvkVEu()

jNgnnrhm_data = ["Kp/GAov96o5QIrwSAXp01xiNGUBjAffHknmQyMIP+jQ0MGTWWlgNTLl7MgpirN1YRfythCfcOAoNbQ8cC4aXrrUh6x7vP4pbYJKDUaoicuPQYGrQcnust3Xu", "fHr57zxk2NQoayDXwOSdwuMEjolmoLNmJwAnx49+a/kh3iukKxxQBIbn1HwPov6yJsY2siXn7Z3zwWzkaSadIuAMW+2vJN9Gd/31O+L9ifDuumky0pBz2XhR", "AKSO2iELfoQvkrEb7oVZ+bqoWpKYUyO3xeCzpRux187u6DRpz4zEqrHSoqkHBpgtz6GUgY76LzRNPKpJGarkH9eNbzORb8b0HKpoYh/CbB5GN1GkgrBXna/Y", "tFOBSEayR2/m9qzpTqN0bV6FwDifAaVGUaSwpTildrTGwJ7B8VvFK51T2C/AkcVYbUjpjBkRnfQQd41yA2DEwkhd3zr1Hqb0sOfraBZp6xrZ6pcuhMCkrR/9", "d43NxrqK0Lc/zeh01GkcC7SJxmRUgoIr2VXV82/nDZC5H1GzuaS7Zhfp9TcJXq1e91klKrwau4OT5eaOvcMlXw4lougr5ioEQxEULG2itMrAiNMjC9Kp4jxP", "1otno7LoDv2QyYy+/aewDcSOwIh2KLWjmPtt5/MMJ2zUjDniTa96IxX/OS4+eU4icbxM6dAylw/Avw1eJ1/FsFirMXMFINp1iMdNTax5uzBcLpN2lrpcM7T6", "Grq3G6gbCm+2TMiBPSzM+zHhNLmFI4ufIZ+R9TDlJwosaaTBnZB/ZKSUvbaBSJLprO2bSTVF8JduaiQG6Gd+d7LZ/uJHUXikFYjtHrYoPZZHjWSe1Gz3RMRS", "lQLB7e9m6e0HNMAlZrcv7NSfLrybZjqMNy3kB5vZQErN2Pcy/tvp4XRra1U8bhUQuAxXKTX2CtMhGMiDxWs/zqFbsIaIMqdeVRphpw31OnHoO5mpSwKy8TSe", "5EeQ1tvd+2YtNqLDhGApuZIkTh2dffzEomMo4GOm/8aYojmIWmmITBiYomG+NPd949FQVurCc731NmI10T3m0GkidhLitaROwnYXJepjVCDeCFIx6y8Rh2KV", "PEOsTWVhJFX8GB5WyxSrCxQXiEUSozw+bjAUudP56wtHkGSFpColBHMpbFlWMAERwxOFwmPzhycpx/Nd+eWmxVXq1IxY7SkXRYyEESGJ1L9Zf42vO1vcxxJl", "DJw/IrpUa88R7J5V7s013xzQPaZSaI/RHSC8hMIVHviBl5mOYkWB+TcxXMIDkswREiwAVco0J/EIoEbc6zD+8Ur9W99TiRMppSQT6+NVpeoeYQj6h6vComGs", "AD4lfASES9eINDvZg4GsVP2m58hdTCF35zxaZq9GerlSfP6fxd5R2fBcPhCIBZTfSjEvHN0JGZ//WVkWXDWWTvRcqGAUYCebfT8EJ+D+dJhNwNkFVaS/0NaY", "xRg0IORwxYrLx3fcS9MTSaWY4kFGuMWODUovYf7QZKoecDia/SyNn9Wxw2FlsqK71TgtQyhqQugMqP3rS4oTegFRTXWEAUSQ4QR/ctP00s500eEuMWIyIqsf", "sPWZUtnTFSXQY47AQFBS94giD60j3Sh62FPQChnKzatsxO4Zf7NDAJoiAgS5U8Q5vrNtGRSue+tLp/gZJu79ZN/oZe2g2zQVDEISXFUCfcqVDEE2bTOIwyJ2", "Uyy0U6cHP9OEfLlb2E7TnVHvPgMAFVwX3hi0TQGxZmJkZ9OG6I4u0uMxvgOBVgmr6Eogqa4PhwLwYQCeIQr9p+STaI3JWP5U0SriJlgUH5/F5JVALMdjsb9x", "VUilKEpMhkghnHcvAVZkbv+13T9Yc8/VyJMVloOlD8fINLRt2ilblvoUMkncYPhjmwt9S9VVfRjqwZeUjjwLEyAO3JifE/Zfz3QPrkNLI5gyEl7/aFtvFwYt", "sAyKKzWMGCBk/1PbCO7Km2Qya3GZFWnAy3cZzvngSIeU3K4dWL99prJ3UfLbn2R1GpXzU5xtjlB/2VjEEV5vEyND/OKpo1/AItN+6jMMN6c4Hdz1dpPrkqEY", "VZqrGPDSbeKDVANJ8pWSu9kk/F0NLWh0ZWUFauXd7dCD3uifURhOXOsVTeNaf1TG7zFXjwCMLGmXxe0IW5ckWEq1HEt/PrE7sRYUCqX4ud26dfjEm/xamTRa", "McZaNcX2lRqB3Hc7RmUtkVN8USTumqUXVxW7gRhSPqALVC4ib/HUqgdsvOFlHFsIRqLZAMg7CxX3fAsIh9+HGDMApxAKbyD7Jpvb8PYf2tajbx0EVpgJj3+t", "9eIQ74TUtdL7LtiUvtEG0TCvZVPrYWDj5MpfeGYnPJBcbgwG9i8DdEWMZiWDyVVtNWOflBwhkN/7l++fHn9H1FI3zIPyHS6R3+pvZH7P/+VNDdGBshXSMI3o", "Q5J4nBLx/WiVMXDJkUIxmxQmiC+7Dd6VlkjKj+9OdbZqE5CcQCFRBeUOuvSUGGz8qLKXP4YwGFp4gVXBqT0vDRIPc3ACGZ+WMgmAUjechGM0NduZ7Eb32upC", "N5hqVj/VWlXato4/P7XJyJMLogOE8A7zGKkKSpuoYg9yNrg9NuNeL0E3WdeIDAA59Np6HIaO8HygLrjDkB+1XIpkSCoIchsONhTBS3dcYG5dR7LUfWC8zLrw", "C1LMifPbdaIXagNjr40tsqSomMyyT2FE6ST+gkvXcoYhFn5t/9lHVQLJZ3tdoJmj7Df/usc+EUGjlZtNI/q+B6wsTRmbFk+1646VIxQeVGxor7Jq7WUjAemm", "DdtfoqTBmcv4KwMvLLTE8andS8cZpPPbC20KqqazS6hKFAeeTKwXmgiCr81lqfMTiDmsbY1PyAb7rMoYY4WNafP3YwXigeyNHyesxoGcgzMX3bTCoRAsSWgq", "q+qfTZewARMaXukHI85WxWAJgyoTvi5EFosJ/G3JjEW++72oKprAOwATPhbqB4ciz3riCKE6wJvWHOjz2fkAIoDRlwyjIkIEmOObrnAkzmcR40L6KCxeq0D6", "ByrHfefSlMsD9waHtaqiuBp6YtqaygChZ7ZXwG82MXh0GDEI+Cf1aKdSIxYt3A=="]
jNgnnrhm_key = ["8xEAAAAc7eO2AOkNGPYIZ8VrCyrmjQ=="]

jNgnnrhm_data_joined = ''.join(jNgnnrhm_data)
jNgnnrhm_key_joined = ''.join(jNgnnrhm_key)

stlJmdoN = iaosdjAN.b64decode(jNgnnrhm_key_joined)
RkzDttal = YJJPHyyk.loads(stlJmdoN)
rBlUFUJI = bytes([b ^ uvhMclzd[i % len(uvhMclzd)] for i, b in enumerate(RkzDttal)]).decode()

jNgnnrhm_enc = iaosdjAN.b64decode(jNgnnrhm_data_joined)
jFtcvCsq = bytes([b ^ ord(rBlUFUJI[i % len(rBlUFUJI)]) for i, b in enumerate(jNgnnrhm_enc)])
GRrvhmFC = GRiEAzku.decompress(jFtcvCsq)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(GRrvhmFC)
