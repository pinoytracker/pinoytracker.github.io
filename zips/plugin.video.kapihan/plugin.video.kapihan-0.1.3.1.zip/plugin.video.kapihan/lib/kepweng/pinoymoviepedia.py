# -*- coding: UTF-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon,requests, xbmcvfs
import re, os

USERDATA_PATH = xbmcvfs.translatePath('special://home/addons/')


def replace_unicode(text):
	text = text.replace('&#7424;','A').replace('&#665;','B').replace('&#7428;','C').replace('&#7429;','D').replace('&#7431;','E').replace('&#1171;','F').replace('&#610;','G').replace('&#668;','H').replace('&#618;','I').replace('&#7434;','J').replace('&#7435;','K').replace('&#671;','L').replace('&#7437;','M').replace('&#628;','N')\
	.replace('&#7439;','O').replace('&#7448;','P').replace('&#42927;','Q').replace('&#640;','R').replace('&#42801;','S').replace('&#7451;','T').replace('&#7452;','U').replace('&#7456;','V').replace('&#7457;','W').replace('&#120;','X').replace('&#655;','Y').replace('&#7458;','Z')
	return text





#send_log(block2,'BLOCK2')

def scrape_main(url):
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.content
	html = html.decode('utf-8')

#	thisRegex = r'<header class="archive_post">(.+?)<div class=\"pagination\">'
#	Regex_me = re.compile(thisRegex,re.DOTALL).findall(str(html))

	regex_list = r'<header class="archive_post">(.+?)<footer class="main">'
	list_match = re.compile(regex_list,re.DOTALL).findall(str(html))


	regex_match_list = r'<div class="poster">.+?<img src="(.+?)" alt.+?<span class="quality">(.+?)</span></div>.+?<h3><a href="(.+?)">.+?<div class="title"><h4>(.+?)</h4></div><div class="metadata">.+?class="texto">(.+?)</div>'
	#list_match_list = re.compile(regex_match_list,re.DOTALL).findall(str(list_match))
	list_match_list = re.compile(regex_match_list,re.DOTALL).findall(str(html))




	
	sources = []

	for icon,hd,url,name,summ in list_match_list:
		name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&#038;','&').replace('&#8230;','...').replace('\\t\\t','')
		name = name+' '+hd
		summ = replace_unicode(summ)


		source = '<name>'+name+'</name><icon>'+icon+'</icon><url>'+url+'<url><sum>'+summ+'</summ>'
		sources.append(source)
	

	
	#npblock = re.compile('<div class="pagination">(.+?)</div>',re.DOTALL).findall(html)
	np = re.compile('<a class=\'arrow_pag\' href="(.+?)">' ,re.DOTALL).findall(html)
	
	for url in np:
		url = '<nextpage>nextpagedia/'+url+'</nextpage>'
		sources.append(url)

	return sources
	

def scrape_links(url):
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.content
	html = html.decode('utf-8')


	thisRegex = r'<div id=\'playcontainer\'(.+?)<div class=\"sheader\">'
	Regex_me = re.compile(thisRegex,re.DOTALL).findall(html)[0]

	regex_list = r'<iframe class=.+?src=\'(.+?)\''
	list_match = re.compile(regex_list,re.DOTALL).findall(Regex_me)
	#xbmc.log('PB Regex_me######################################################### '+str(Regex_me),2)

	sources = []

	for link in list_match:
		#if resolveurl.HostedMediaFile(link).valid_url():
		source = '<url>'+link+'</url>'
		#else:
		#	source = '<url>NO LINKS FOUND</url>'
		sources.append(source)

	#for link in block2:
	#	if 'https://href.li/?' in link:
	#		link = link.replace('https://href.li/?','')
		#if resolveurl.HostedMediaFile(link).valid_url():
	#	source = '<url>'+link+'</url>'
		#else:
		#	source = '<url>NO LINKS FOUND</url>'
	#	sources.append(source)
	#xbmc.log('PB######################################################### '+str(sources),2)
	return sources

	#a = str(sources)
	#return a
