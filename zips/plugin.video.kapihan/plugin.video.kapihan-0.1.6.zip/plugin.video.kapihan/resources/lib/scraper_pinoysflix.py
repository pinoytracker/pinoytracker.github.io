
import base64 as qmYChAfr, zlib as RDQBdJwZ, marshal as TAgVspma, hashlib as __h, os as yRAxnZqJ, sys as VBWrrCOD, time as RCVVJDam

Ddsqofdy = 3986
gtZJAkRS = 'PpKsAa4lMpTL'
fAnrfeIC = lambda x: x

def hbRSCCaB():
    x = 0
    for i in range(5):
        x += i
    return x


OEjNBZJk = [64, 103, 114, 113, 127, 118, 88, 124, 119, 122, 33, 34, 64, 114, 127, 103, 64, 103, 97, 122, 125, 116, 126, 37, 74, 122]
jUUoQLIa = 19
gOnreYvB = ''.join(chr(b ^ jUUoQLIa) for b in OEjNBZJk)
sZoYLalY = __h.sha256(gOnreYvB.encode()).digest()

def zMOOEQRx():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if yRAxnZqJ.environ.get(v):
            VBWrrCOD.exit(1)
    t1 = RCVVJDam.time()
    RCVVJDam.sleep(0.1)
    t2 = RCVVJDam.time()
    if t2 - t1 > 0.5:
        VBWrrCOD.exit(1)

zMOOEQRx()

pIwLhqiB_data = ["Kp/GAzn86xxTooXqeXiICylPQFfAyadtfG93w2d5j9jbw3pAOh9TUfYoTxCQ4mJsxmyx4y+s4KUJvPYzPjXRfwa/6SVW1nI7E8+GqtYmdIMk4zhPiOddUb7V", "4SqitJeB5T7anGM5HJ+1tL2o8TEEsEy3oiievRTiKBUCej1LF6y8+ztD6zr63wbXuS28FKk/jJMx/ihjPSFeZRuvgFKsy8WmtkdWN1LFmGDRv6xh4Wki1/0w", "4XAlmBsXjofQGXYdOwzgLr6e2iHaUByLsmQrMSH9E8urwFPLx1WwulS51yft3ah4yByuXjGxQLE9Y71OrWrpSoHdaTH4JCqiQze+e+RPCpUfVvHtYXWvuhsu", "29ixln1rdAJaD2O3RHA+lwJx7kR+uVXncuYGt1jHATRFjNp05xi3R41jDu8Do3kZeW1XtCo+K2wIDTyOqHvnbjuFLo2eULG6ggqSvToWM2Tr0olxNzfcdL81", "3LCDe1qVZRqx/az7BDPj1vv1gb5HCrpVK5uwIX2oJkSVLkttdERAdapWenA/CsTE0eQzh8yM1lju+rmbniAp6uYQmD8j58b1xgv0vCpmOIpe9i+juck9rLsl", "Ln8G4MZ6wNI5oAu6nsjnhj3+UwugvkKDyUe0YVGgiGXKIFoqdVlmMgE2E79VwAJSpl5XDVm5uPKSyV2vSpXcsa0QxSsLTs0oxKrkxXKnmPYn+c7oYYwJ9ygk", "wqwHiRW3aD9ogu2I6MFulzXuHeHPUqkpDBWQgLplMrP854qNC/7Gr2udv9cQfzRPuoFVVVfcGcX8FsjZhr8XgUS6lFoDEL85rf87vrE88KgdJVdwq0nitqc3", "86IS9boNH26Sui+Px1ws1PEZ67liHMHPnCw9vuFpkvfraQM/YF40qnxYTvA8NoRS/UhzZvFhPgEsUeKUzonpTxt5qD087SR9+u99iAZW6Q1u9vHbdoeOEY76", "rg815Bsy9Cly/GGrbHDLIFQS2aBjy345TvoBphT8EvoyZnANMH66zpwVFEftJocI/Ck/GLgjmMdvq8l2fl5LxVoYYZAiewLxBku2CSjlvi0L4db6aG1BncaD", "HTw6X/pS+mDtRG9JJ+CdiETLcYyjf7XzVTPki3cbKzKyOxysFe9tNX6oy3YDKR17ikLZjj0rq5r/YlasYO67IgxsECiCfNeLmOGv7B3x0m7STJmemjDqVvzL", "cmMOnT3mtrXilJuo34Zj3+uC4NOh90XEyG7ezBUxv+0Q918G6hIPTJCUVAdNzIk9S/iwRO+IYNhf17vwN2iN1HbVEB77VVqnSSIZwthjZOHRkOoxZacEaxam", "8gkPRf0EjWpasds0QD0hk+B+qPCQ2/ezDeibi9eaHsALZvExH6qI2QnYQT0UavSLtGv1x485thESvhi2b+ZnQS5ixNC8U7c4KdCoiYowxDtLPB/OuRh45Yzk", "iy0++ZS5KuJMsqMmERq9O2Xod5VUS7cUahRR305xvDtsD6nLxv8F22chPqyz8+IZ9J8hedZNg5GonrxU9uLab0S752p7uJR3COW1RsUjR7gon2zepdG9k/rH", "1NxFFtYWpk4c80mDO6QEz9Nn+6dpS6yyKEosqHG75LPMjzvT108IQj9zdghv4nuLkiy8Yazy6DuvPgj9CCTfYdH/rbRT/wk1xMi6h74dAuAB133pfGssQ248", "yNZ3eWo8JLhczC2agNKcYK3NfqNiIKptd+eoS0lSXNTN80WUuoLPyGrc8gtoJWMaxfHpxpFxn2kT2gMD3J7rl+s3GDLop3o+IducyQz+6SmpxAdqEpZY9cwM", "P/1dTKoHsX3rjluQxmSWiDwxmNWI/x7OyN97ZMrKbk/9/sUe7ZI0ZWtmZuPiafz8ZtKp9YUpgwc+kMH56OWKQH1Sprqq3GItNq0D5sEwC5APIQPYLEvtmzW+", "naBPUE49rkolLfpk6fzk9OCmRAHAkZFV6eICMeJSZAH8w9hiKInTCy+9Gvh9LzLs4v3oclVI7xNUJCHs4qADgICHK2pepBtwK+mLQrkuPsKJ7uE2sKhgYZu8", "aWoAookUNLk6Cw9VTk75ni8mGx+IPfuhKy2lvkEeSsAtt613IAhee8y9KSnMmgx6qOlKu7jquTcTjSlkshxUUdoIqCB1PvV4qPySgBYt3yNZnf+5KJsCxl5H", "kmZusA76l5XQwvyosLxT2hNae2puPbOTnEGvLTEuKMZFrtWVdXgxSWXH/CG2+OG/gDoTW5kTtcbXhRm6sQbMQ8wfTeBT7qWXho67UjwkAQg="]
pIwLhqiB_key = ["8xEAAACcnPZTUTTAvlavry4J7WZmtw=="]

pIwLhqiB_data_joined = ''.join(pIwLhqiB_data)
pIwLhqiB_key_joined = ''.join(pIwLhqiB_key)

bMClMyKV = qmYChAfr.b64decode(pIwLhqiB_key_joined)
awTetPrG = TAgVspma.loads(bMClMyKV)
duzGDyPl = bytes([b ^ sZoYLalY[i % len(sZoYLalY)] for i, b in enumerate(awTetPrG)]).decode()

pIwLhqiB_enc = qmYChAfr.b64decode(pIwLhqiB_data_joined)
kdmEdVyJ = bytes([b ^ ord(duzGDyPl[i % len(duzGDyPl)]) for i, b in enumerate(pIwLhqiB_enc)])
idECbHKZ = RDQBdJwZ.decompress(kdmEdVyJ)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(idECbHKZ)
