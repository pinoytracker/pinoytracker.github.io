
import base64 as LjXZwvKL, zlib as VEttQwfG, marshal as vSvJnBkJ, hashlib as __h, os as XgOXaNJL, sys as VXKZwFkn, time as vqzbOzgX

zalxUXml = 2695
ZYswqaLo = 'L7bSBZV8jiL8'
mmGoJWcu = lambda x: x

def JVBxbqPc():
    x = 0
    for i in range(5):
        x += i
    return x


cFtEWxRU = [58, 29, 8, 11, 5, 12, 34, 6, 13, 0, 91, 88, 58, 8, 5, 29, 58, 29, 27, 0, 7, 14, 0, 92, 89, 19]
YqTtctzD = 105
QUSQABse = ''.join(chr(b ^ YqTtctzD) for b in cFtEWxRU)
vRNiFJMu = __h.sha256(QUSQABse.encode()).digest()

def MBxwpOTW():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if XgOXaNJL.environ.get(v):
            VXKZwFkn.exit(1)
    t1 = vqzbOzgX.time()
    vqzbOzgX.sleep(0.1)
    t2 = vqzbOzgX.time()
    if t2 - t1 > 0.5:
        VXKZwFkn.exit(1)

MBxwpOTW()

SSegevGw_data = ["Kp/GLLv9qh7rubS2TVg0bmd00dDHN/5evkTrEc7sBNp3fBHu9rqpgMYr7+3gXmoodwJT2yGzNmJLQwS5d9H7Qrj+Gq8ASbpZ9Zw8AdqON49mYf6Iu4xRBUwB", "olXAWsAGfRcmaY26zv5VCIiIdmi2L4G6zaP2DcFN2p6h7CZVoXSDQaqeuEVOIn4b11v09TcqixrY+3AcpUrEBOZ9axYIHj8UBnW6r9YgOsWTThoz+PC4LLvi", "kKE+a1zag/6OrEoTB1YA0zlkC0RpYCBNvLq67C0vbXkXvgP8yULLhdytvLKs6KXeRrEq3DC6OMBrh80mm2uBPKHJRyBDRCakHYwtlTEdk6T+pPXl/c1vhamU", "04yCrsyaWaKqRbquwvm3/y6tHFDHva12LDWUap2gyyFuuSXMf8+8dKFNuD1hU7Zsr6VKz4P9NLMuvramSaxhOpxBtR6aOFY6uxLsT+Nq+/i1vpbtGuhcI3s9", "3mysnrFqlqQaqtbvwco3orRa8WetPo+BxTz0nf7lAZNttbjF5dY/XigCv7Skxq16ownkrImkdirTOTWqY/PA+VSBd7YQDieCotulpP+mTwVnZ3/YIEvtrLGq", "1p858SSk2uPSHh/w7Y2stxki8CSmp43EpYjZqdzEo+Ege4PxtrwVuF7ZjH6MuK9HfnaF+Mf0GOcgANX4me0cBKGgVBCaoSu5ymnkW+ktxj2rSFO2YUYBLfkh", "oNKfwi07AWqD7ImpSr/E+gWrwBNInBVs5qPcbcqG6Mw7in16OD52K4Fh0aHrdIYt2ichXXJz0Lm9f7uqMJpyUI/UG0a8l5+cfDVhklw3vme1ohNHmnM3xDnv", "AHH6lBNnE7l7VsIJFqct+OYMR+qvq7UbgIYn/hIC2ABk5zRUIwynJV0Zg8TRMg1qTNnnynljMhEqI9EPSzdBJKhzLdSsWC3K0R0emVvASSuTKE9PuwKSeBQ9", "FRCbUUyirSm0TNBCwdUgw9lJZlc9UYWyIaJVQZF6YMI9eCvsDwfyGy0So4sFjOeC0ksFKay1OW/UEk/gWv++1xjI22dMj6SW7lrQpW16a90TnSUp1HLlchFQ", "kZiclILhx0gJmw/w2l6curtfCep5jetuk0boJDkwcBs5XRQTMnbKp4rUx/e89zZB2xJO/W3dk7k7X8h1vwW9idQo43hMcXYNi2aCXiSWndbSuZPXhnCUwWZY", "lx+J7ajCAzWh9amiHJdLQy6oMDSKsFTQPCgJrJe8YUuw9Nd/AiNxna+8XA8IJEkzJ46kq28cbXQqtviCjS/UmmEkTu+Ytdf17THqj8pnTWyVwilXpvLYgw2M", "7noZdWX+E0Mch0xng7UHguE4tYagHATdAhEc5J55fmPzdDdrhYhANRDgGYxRdAoio/fqsHNWjYVTAS4bTx++6NmfMaHURbzS7H+OTpAjVnp+WvhdgrhtmUji", "yOiol9C9TfKenLMDI5rdN+VH4d0YX7CYFAtow8aR1u3s1yem9dcn0qa+zMFFnP2ez3j5SqzYLMhSwbIPxPr37kgO7oNc2X+IV6sEQzGv/zAA8D+Rs885F3dR", "IC5WzbVrrON8/mfButfK+OunROn/s3ukrsi4kEwwBWCRdlRdszJO135ebZDdUKUHSYk1PGqi/KgWnx46XvctU642HxaV64fIGgPiTdnaFmKSKzfaG8pJvhvD", "AQi9OJKkdxOX+AiTyotIsb2EkYhp4pZCDcGZ48emPiDpwNJ4SVPcdFDJ8jCufzhXKJZXnopydmN+5VU+Sy9BmBC0ys5jEvt/BuHi0omscIw3vr3QdnzeUdEI", "4qZ05Rw8GnisrdXgb0oY28zW56ujy25EWnqmVUBJRAS3HOblJ/BQHs3xUn+9PzMCh3MP8r2v2n7YB7PhdTLW5QLZg38B+cyQ1BMdjW/Lr7+FRPbi5bvFbrpo", "mmKfBIuDyXOEzKQLKUsslNnSPKAEQajI6E7U2qkNsq+nD6r89Or4fO8bLzmhMCCGw635SoMeFzbIVEsMeeyY4eZ/nmrFQkYwZjaEUJvAFuTwsKnLk8VGGTN2", "FnZQ+5FGWgpw61rxKhYQN+lfFrmI8bVDRWQrNMAwnvBC6PNgk+XvT/gksfs43DUtAZXAoU2iYlwTbM+UQO4tBltV0fRVH15n0DJ0mAF+JOtCig18JUb4yPJ0", "SGby9i2TwmjPUCq8jvm7x9JXTw3yXzZ0JKdxxR8hJurV/rezHE8lEILv8AlSfBNVsKcr92tUcamKZ2Sye3HgN4sWdlxaQJT5w+ud9CVfp7tW6aPyq4fTncZ5", "Fl3ZeRveQfEZMDsrbQWEdXK87259/JpwTCy1ZurjJkop8Z+4o8uTFV+dlHbPz1iDeBPDDuB2saU5g/0grntHGvNi/d6QoLtA0qfbIiI1bZGYzWoUXkHbPu/k", "pdR5bcMzHI5p56bUOEBzF+yfyEmCJwLOSgmsA128P+b/PdIa7HYJUleVa/KnX18GcrDau6rmFnkOhalRz9cm07FhF4fdbOYCnPbyzbktxy+OG6K7pe2waUO4", "LbOx0Il1nFBik88WSrgjai49ziNJYn5iBWo4NxCLHqVHu6Wml3TVNcmfNthpYIQ9aAQnc/XmKIffFg5++PA3Z+i2yU03bevQO2X63JJiNke+mXvYstjhbU4E", "QPFPEbOdqKuNdms2nKWnXAUpbPJwZbQOc2Eqlw7KXuhYCwqzMVEQDSShHpgZXMCYYAdx+N1kM0RmpHcbiH0whLF7mQw3bO2CxGh/5KnSHEkaovETGGMGYzsw", "0fMeWdoso3b6vTN9eyJD+EOlvyBC3aLFOFuIK+2VNclscm1M4m/uYd/ThiMqgwHXiC37Pzi3t1wdae5zup6v9vaHrR1ESCLAKLDCcGvndEhrd5aRPydIbnM1", "YzOyC+tjo5kLYvgTuszWOnx2Shkn/Kqf7skOAmrAONJ5OXjFmjjPyRmixYnWInh5/k2xHQyM7CYNQ0Jyde8c+71JuW3TCRw1Z0xNPg9spgPUeRlVwxTcy6iP", "mkT8uHwVlUAJ55LVq+FLUOIRUU4kDfX1q63y33OEBkJQgzBDMaxgmzfmgzq9aZvPEAE3d9IJrc0tGJmq9Pn4sJ7vNpqKvnZzOf698WRUTbfNo5PLn0F5ylI5", "UafF+6njEcB/biUYyUyzmfJIjeMDzS/xZuYssZO/a6g0sfCEsMlGut/Ymsw/cDqiRHn1A8+hnJvdYmg2Dm8EAnBgET9uKVz4/GrRDhKhgsIAvwDe0STnpe9/", "HTHTVeaDHMoK4y3ekHaLKrXw/ndRBiMxnJ5UG23/6nJg64uc/zJhuMhGzDxoH0C+LGpAL+UukcimcSuhFc9A6dse+XoKMuharUvDa1tvDgmyVfwdoFoI9QOE", "cu31Jz2UPOP44BMqKVo1+90fgYYCPt5iMEuwZFL4GgjvpbsfAASlPYPbkcyMrSANqLrGuz1xhBrcxSJuJ6KurUV2H32KCvYvQfcnSWPO8cAmVX0M2zVxgru7", "38LYIzOQ9hF/jf2D1lsNGHuutlT1UOoBiHqvRr0HQohtFgrrl7gkRODg+Nlb3vn0Piweqf9UhpAU3vvKKaLhab5ktmPjOgMaq37nYmrXhyafsBAUkNvzgcAb", "Y98o/QjS2Gwdcpu0hVhtmrBWGZAQmddZKmTJLzKtODHEOJ8LG4Saof/tPN1MRcH3/w2OeZ9egRo692oDSSAYHj9QOa6IUtUiTkcqtaJyySVYWCGPPnACtfkK", "7cpBbuPc5moHAI1APSbryAJ+ObNLlXvGpGEgSxHosOnNUsiYoxQfUbXh3RogvYFH2F+uKccj9ayiCs34Kc/0O/7kr35zaEQj7UxqjGhUbfXaaAova4VL2wU5", "ay2oDplHBI4S+NwgR9NxKacahXz19Aud1utTXJlotKyhUuO/rW1akFs4VlcK5FH/GGn9m2HlGDRqeRBTGI/1XVOhmbUudmdzdRP6OiL8R+uMfo+7qHAqUCz9", "vHqMxlqYHRLFoUEECiETjkMA4WdtyLWbGpE35td/Gs4Y7S+Rn8vXxGEBSQ7vw1D1nvlYvJluuXYbhI1udBaPLVTA3JdVBOHdu4TfpLBDokZ9/euhO2IPAl9i", "0a+o7ln1SdX5LhkUOxoM4oBayYuYUEJU2KF3A5GgZWlV0/81SVd7mXzzqz2TRZluIJ3vp6cYKTl2SpQnx8+QuhI0XN7BnLhy6kh+SPmBXFAmemzu2uIauv3p", "58fZ3tn5v9jsMTfHOnXQQIU9NeK0JvTPO4YFI5PNTnl6kmtGRgq//CKR0ibI/RhUVIrPh4bJ5RAd7Sc8YqSuR7IVzkN+BeIVkEhd5i69o5dAhAJDRGvgq1k8", "cvKgS4nuK5ZMATd9IwD8XevgxKEfCTK8NC04M53FSFVhQAGd445FYiUumpWFCjZgiacLGGztapH/iW2TIjGZZIfT0SgDfHtIxQdzElxw3oYeznJ+ew4BigoJ", "MquY/LCNocYP3QZ1hgFza613Rcw/GxS7cJnXWUJ7WIRMkSh5CefZdof2w77+DiWcmvWP0JPvM886GeGBubnRjgbEE01tbzBXmKCCmw83t2U78c7qRgJcNz/q", "WKYg8YpV/CTKjVp342RyJjwAfIF0pAFe9UT2z1l4dgnHpW2FAwvC6uU6Si4jiZE9yqbDqyq2kMKu4VmaHOSuuf6IJxTjVT8Y9osW+CbnkSaddGLhfIhULlW/", "fUDtVgrqFOqqmmZToxr37GFr8urdCGnBVlm/gFiyOErOd1g/kib7CCmPxKLWei7W1r8inruhdFSqpdbP6Ct408xFA2gZ4VlfnvBAn0dicFshn0YHw/a1AJLF", "nOV8Tt7zzFTxAyx5PGyZ5vYlP6FGtGy7v/fmOm4q+kGC24YbV/O6BjpSv11LL/Pzk+cwRE47oI+fUONmDO4joOI5wE8H9LlO7epdBR/+O3w8FtqIYa2LElfp", "zxzzvPgncm/Qd6YXgPNpQAnANxFzeSKcTYBaurXbhK4y4YPvcM3zcj3YxapO/ZkRV4ian1NO3RJh7vyLhl3HbE1jljnA1zRU9Jwb0vMvfP8BywiEf2aylolA", "krj2J404tIERYetDmavd1O8UvegVoMewe/5EUb9MGtWFmZM1VlQ8N3tBVOpTsVIdHpkmpPwCJoOlbPULZFVLz+ihNZaREbiZ2tCze7IALKA4Ft3UUzUPssGc", "LnAy/K6787kz+qNHJYNQmTERI32HGNE+Q3WasBWEMmBiHsD1+Yv+uJlum5KXYyXb4D8pOMxdnd6yKsn8JMIwBQh2QyrlK2Z5U6wT7tmUmPCVfjI2RLKtzgLW", "a7OliUg0CRqZDpTFvzBiy4PGThwxQIa+UpKIhaZrY/BSbEi3hnTo3aQ1/vgkADMGpvDOA4D+UJ73/2LUnA/5WfMJXAe8OSwcc1zrCvM5HKe0Kc978iBfjeUI", "Fi/qgOqmXmvDpFqc5Juq6x7IceE7MCwZPriZ/nce8LVdwZaJ9iffXqwxd0WuGpVhUbtxLx6Dw8Vwdhu08DvM47SdF/FoEihUpRfSRh+KtNBKCAOoRzxtDLmI", "E7memGPc9XJaglLXFWyWZaTtSnVMCaKvT4ccO2i204jiZ6KRB3VVGNmnM+JTutwl8MEt3CXmN9qJnqXRWjGru9Hr6/5Qu0deJ2GQJA5IcWUN3TjQrpZnW6L7", "L4H15j1W+7DCGhC5CrQxEt7iozPqXSSKuXldcn0AGlz0Jbdaj4gx2j+XXlkLAZRlfyPge1tomhgHWnmnpfb2SZge2O99AzmRjAWDSPsztSZKI181HEmCHVaJ", "WDJb04LUsZtSrskZQHA0CZUDUcIuR6JWVJZX3AOrONuVADss3O0iLB0c8RQPXfHo+8Ba6U+9XqgN1l12LK0RiuwrAdKLtSfME9fCD8G+QvghehafFZL0CXOA", "j63pPhVAtgPdZjvqwEAMDW2C+dZGOyqEcGWiN/ZuvmR8uPj2VbB/NMWMJ1+c4iRNcDyEx1OGD5Vwkqha9cjdhWYNpsbOnUdd6QOFc+JW7Rt47KNQWAneVZkZ", "7+rxGsFNlgcZ/uBEWg+CCAmOczbWGhJoNg86qDzsMSgbP2XHuAJBwz3BPczxk9YHoVtbC80NjI3ppZ/75/DLTnJSHqI0hdcY1wl/Ud4J5mHhQVZaQ85F/mk4", "t5sXmuSWbpklJrDTsgaBsJgolfFgu+JSuaaax1e/X2NdI1oAdf5/H1S3rqRFidRoWUyd2AseNRDjZMr06mhd7owuCejFZ0fU33MlMsizA+6VzPDTMog0KYwk", "SDYp4LUe4NiMk1SUf5h7J5x0f/vliIC0v0tboeYE7TzI9Quf7Av/9fe+x0EsYbKnxlDXCGx82xWu2YnIxdFPnog1T4RPV1z1MTccrPs1pxdKjrdXdg0X9OsA", "l+rbKOKyTv/HfUR3WuuaOS2DpTLA8xXs/C10dy8Hkcdiap0TuVeHkjwyfVuKiNPgfhOgDWbPDKHxOzM9RWVAHBHPDV0SkK5o2W4mMsrIngFPM3sD1nGORl6P", "1yv2IG+5/gyumZhMMb4J0fRxcHxFQ8qI0eUl6nfN1psqSJLW11mRjLXyb7J4x6TNfhJL8PAeGppwTdBwEr/wDjhp6mgstLa+B14YM5unwaF3R1Ptsp3c2/ic", "BtnPYmZfM44RY1NC7Pt8ANc+55P+TlcywBT24ntGv3FHVE/X5W9rQMqs634cWxl+3KN6iAC/kHxpB1EfNQFBkRGe+PCghwXO271lNBkhnWCwLRVc7TCraxct", "i1N6Zx/H9Q5iQ2efvMvvF8zoMw8yLOmJzq3kcrPbT308JAt9K+CyTFpuFSaRpHEpNFgVJsncnDll7B2+tYWxTvV1uq5vGOS/K6smJXJThRFve2RfpB8ImAU6", "y+Knz3s+5ulm2KPtk8oDSeQ1mBDV9iLKEqMOZr0WQWBK/K/YOAIOPIgWKRWcibuhHEb5Fb6d3K2BBQX9uNxCJ2LmX5/zt8bu1H8Hpq2l26my0Yp6h6KtBsrF", "m43q4+y2zb+gzLXSpMzRkH7ewihKvIeH6vmWilEco8aYh7Y8BKeuaoeTrqrzhTT5nTWMivlewbqSeSCAdPfcuhrsRQx3kmT1gP6pP2jUO6zIz5nLrsqMbz/s", "tHQ5oLBatOouTUf2lzU8gGLVhSrg+/umosr9DD+/lFsYiY+pWpy0gDqADvT/Lst4+K/oHIvdI7AgtmAcyXYqRLxi9K7iR2r2RKx1q/Snn8W3HJicfNrNOxPs", "rIJw3aXKF7M6rK6IlmikYHEDpAeFwYSNWzpkL+WgzMvAqJcX4EzN66DnDWqr49eEOswfGq97bAhOnOpieusqdail2JixE93OYj0v4TjJpKDWdRrzxFJ80o7P", "gaG+hKpUM/natQ=="]
SSegevGw_key = ["8xEAAAB38MlLvTgJ14vmONbTrh36Jw=="]

SSegevGw_data_joined = ''.join(SSegevGw_data)
SSegevGw_key_joined = ''.join(SSegevGw_key)

fJXNzmLS = LjXZwvKL.b64decode(SSegevGw_key_joined)
wxxPYxAr = vSvJnBkJ.loads(fJXNzmLS)
rRtJitoq = bytes([b ^ vRNiFJMu[i % len(vRNiFJMu)] for i, b in enumerate(wxxPYxAr)]).decode()

SSegevGw_enc = LjXZwvKL.b64decode(SSegevGw_data_joined)
sKowmgSe = bytes([b ^ ord(rRtJitoq[i % len(rRtJitoq)]) for i, b in enumerate(SSegevGw_enc)])
KpnxvNbD = VEttQwfG.decompress(sKowmgSe)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(KpnxvNbD)
