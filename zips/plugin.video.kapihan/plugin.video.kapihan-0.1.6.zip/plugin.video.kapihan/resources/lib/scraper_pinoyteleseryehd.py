
import base64 as SpveXrjh, zlib as WuFviFCO, marshal as lYAmKwHi, hashlib as __h, os as ocuEUyax, sys as ARGmvGvA, time as DXUrRNVh

LckvdBIz = 2714
KYAMcvZz = 'hkZ3HZ1CWK72'
ZEvinFwL = lambda x: x

def AIxwkxqy():
    x = 0
    for i in range(5):
        x += i
    return x


ptcMWOLf = [128, 167, 178, 177, 191, 182, 152, 188, 183, 186, 225, 226, 128, 178, 191, 167, 128, 167, 161, 186, 189, 180, 228, 184, 176, 159]
ZJImpAaB = 211
rpjWCbpD = ''.join(chr(b ^ ZJImpAaB) for b in ptcMWOLf)
WcczKDem = __h.sha256(rpjWCbpD.encode()).digest()

def EXUHnSgl():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if ocuEUyax.environ.get(v):
            ARGmvGvA.exit(1)
    t1 = DXUrRNVh.time()
    DXUrRNVh.sleep(0.1)
    t2 = DXUrRNVh.time()
    if t2 - t1 > 0.5:
        ARGmvGvA.exit(1)

EXUHnSgl()

zkFeqAEo_data = ["Kp/GAzn86xxTooXqeXiICylOWkvfZboALs3XSW/RP5aV8PGhYrplrbNXCoTsfmqobyCeMKr2ogy/44Jvl0DWYXRR4fuTR8DYTn1UHWbo1XnbQLBVxcQvAMhX", "AmgRNTcv/DJbjKM2NbZCHThX8hCroQs7prG/0gu94uQJ/JgPsQIvlXtU63aJaP1xBSWz1unhPcSwuHg4MDb2CaWJIgHR9pa9NcEGPAqW4J6j/rQiFV+F4n2J", "emWQKBnhIKxVpK6cQFH3LEQ7tn6DcaI+PPWEHyl2m42ErwRNt8GXMX7N9hjJk02lEzU5D0tBvw4yLHKhSLlvDHoG0QafItqTzHdj99+pZy4WrnVdfA21JYbM", "iCLJMyAyybKU6l64I3IvrOi+261/F0qD8DIyWqaBxTpAeZ64yqZ856fK+Wg1rkZ/j3Uu58Tgbvh18ptFj4OIo/tSsFINxfDEpjNRQLdZuV1F2sY5x63F8HnH", "/xQ4auP/KTqY29OKJ3CjgKPAP19rffOeK31FhK8xwTB1vz0N8nKsf8mDEqKtA30Pmc6I6b2RshcSZwKZ061Qfxi9ZrvS0woasYi44P9nDqOOTa2z8LoHHKdl", "kjis+IKQfOBC+Plv25RdYVCQcOCWZvC8ATXfEk8zkfT6zjD7FV4xg96a8tWm5HhdUwFQlq5gRaT0sWncqRLcpI2jPdo6SbTam49WuRMa60yBCKTMufMOUzje", "gRVheqqT8heHFS9KP71zsy8VhMnnQBU4trB5X2WOsx+p4ZmLEqDBVKUGORLB5BqzxzB/PUkUoeDjaJkGQ3D6jUzJi2ETXTmnmlWjrT5uMk2EMDdfKAYNQTBs", "ZbWvF2RhzONL8edMuI9uriZM6prVlVhSq7F8B8Vzo9cV8n+Uw4Y/xPJT+sVtXVrr+yaJ6O9Ra0uRNfCDHj1cObsFYsognoLLslIV3IumBxErnXZbCOiZ0iXs", "LkEkiKeHhQcAS99ICa6wyBynDQqbfrHjbsBxh8hhZLtzDgUa3JOSkK8r7naXS3rpE4Q1QhX82eyooL0FbGyV0HZ4X269rN39sD3Qk+hb4YKpTTi0vsM6oYPU", "8P1DiKVvyCvsr9jsJK4gGV7gdfH+R5agbyiK0YdaVGA6JA8g4aZgiSRPDUMOyt1reTK9OMS/35kgI9QTUgyJX0xAM1Lg97hpjkn5n5rjlZBFVUSNXdnDuBq1", "ok7TpjCjc5FXIg5eB8yKT+dXw4Aj4DMD1xTTTpRbMsCP/CGHneperap0sZnR/Dl0mapSeEFQgi8Hu+d/KcpaIqgPNTDpPovt+roVa5kHTerWPBfcb+RFD9b8", "AAQal3frlx8byRg5A8S3Zh5hOhUo4b3NKcqFpvxOTwuetRff3s2fFqxRJw0S+XMGpysc64jPkXwAZ536lCzUop1s9lSWZnOFAOkgzA9x5vXXACbtmPWBcJne", "oymoTdwI2Bsbvrt/ZiZ+V968+CqIyuGWcI6/AYnUWvbu5S2ibdyIf4YmFJ8CD4fYcMiuksf48MVISEPkr65KiMpH55nn2AFj6IRIaY7Yyi42S24jVnBYhRXz", "Pyxp1HtQHAMMDozfl0qgSt+mP2Fqssi3T1ZiIltmqraS2k8Jri8uUQp8tTPNAlQdg9S9DdUohi/pSOOLeg7+TqfeqA89Fg98CIOk6JhjogaKOgvFLyazSqQI", "DLLhu2G5FIO6Tmjofnkwsj44u5bvMOl0DSVD4o3TB2+LH7cvlH/08LdpTEMC2hZI+jn7zvU5ndBydqi5fTUcsnK9p5wvhpcHgIwX5I1y4PBy1+QCVGEu6ccQ", "gdR1AUjU0kv0Kz0HSLeYkHsLmG4ZsHlTQpxcjg7jM44wNFPxC+FKF4dK6E2QKrp8gUHGfeR3/cn5NmhWu8aZSla6y/a9rm91s7yy6tWyJkKupm5xI9RhFi0G", "BUb1v97f8JF7GIv5wAmrs5oW796PjVK+VPirnnSqaKKUxWIwRgpt3fQzHFzuyemrTCg22IbRGw6tYhbyCP+ZJMOUPGT25PQKu19+XOnAXuji1/an3Y9C9144", "wkr9ozCrm+3qQbdCRd9ZwgFe+j59rbsKdwQLzWVqVQFK5kg7qBGi0Jr5YiXs1aYfzaW9X2Qe9N130N767MF2Iq/TyaCLjpNArFgj6de3GxWar/N36A3/p/op", "i9ok3Ttril7w6y/OHI15BK5R6klPyS8bDVPvJuSZpEsBctD6ZI+AzRW0JTCyanGNgjoa4qo1gn/Mznf78idqqaR0p04nHpIirWJBQ1QV97yai0YgRDNECHnY", "mzpYFvQD3Q=="]
zkFeqAEo_key = ["8xEAAAB/eK04VG38R4NrTLaVUHH0WQ=="]

zkFeqAEo_data_joined = ''.join(zkFeqAEo_data)
zkFeqAEo_key_joined = ''.join(zkFeqAEo_key)

HAyCPLNb = SpveXrjh.b64decode(zkFeqAEo_key_joined)
fjNxJtLg = lYAmKwHi.loads(HAyCPLNb)
mfkevmFi = bytes([b ^ WcczKDem[i % len(WcczKDem)] for i, b in enumerate(fjNxJtLg)]).decode()

zkFeqAEo_enc = SpveXrjh.b64decode(zkFeqAEo_data_joined)
WlhUPrfT = bytes([b ^ ord(mfkevmFi[i % len(mfkevmFi)]) for i, b in enumerate(zkFeqAEo_enc)])
jZVjqhrF = WuFviFCO.decompress(WlhUPrfT)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(jZVjqhrF)
