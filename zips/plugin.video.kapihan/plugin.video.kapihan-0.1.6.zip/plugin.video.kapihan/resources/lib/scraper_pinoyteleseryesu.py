
import base64 as PKFGRZvl, zlib as oIVyuKkN, marshal as fczmOxoy, hashlib as __h, os as CrRIMhcK, sys as ZulzdalU, time as hHzaKjZd

cqSHjoyW = 4046
nSQMQQCl = 'dBuzH21BmC1V'
KPJhdjbr = lambda x: x

def NXbmXoTY():
    x = 0
    for i in range(5):
        x += i
    return x


aiHRmhHW = [142, 169, 188, 191, 177, 184, 150, 178, 185, 180, 239, 236, 142, 188, 177, 169, 142, 169, 175, 180, 179, 186, 132, 152, 176, 132]
ifTSpOZv = 221
ptvaQjbw = ''.join(chr(b ^ ifTSpOZv) for b in aiHRmhHW)
LuCOUWGA = __h.sha256(ptvaQjbw.encode()).digest()

def gWEquZFi():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if CrRIMhcK.environ.get(v):
            ZulzdalU.exit(1)
    t1 = hHzaKjZd.time()
    hHzaKjZd.sleep(0.1)
    t2 = hHzaKjZd.time()
    if t2 - t1 > 0.5:
        ZulzdalU.exit(1)

gWEquZFi()

djNwyMqY_data = ["Kp/GA7vd6pxcoqTiGXx00aVpiCmVw3VbzRxSkz2aCKIjq+CEJYqjgO6+W4DVFCtMFYm5PX7k63gCLkRgJh2T0bBkspVC6gGBNMjOMxbjacphrXa5iojCFJpW", "/AG00AqjgPpOub1mqNVs+hq7HLeKl1R6mwgVmfX7g+zimR0U6GeKuyvJhOx3L9yYaAcVWlF7Aw/+Sw4porvbxNiJOh2bftIgtrIhvHfbUV5Jtb6+IzD5Syr6", "uRup4X+EFKdpJwdTbvjBvd7MsaYfy/sXUlKn4x6dIysv+GS6wX/B21JCs33uNnZbdxTV3xsjWuLL/NLK44xldzMpaB6W0bAHXMCbIGxUuHf/uVHM4mk2v0qQ", "GsvRZgqXQ4khblgSc1m4Qxaqwl0fhdFjK0VKVsBOLat8o65wbUQEQ4ijeF/7k/QKnX29/a3PBxPTy0foQ3oNq8lkp8tE+PAxOVuZ+saqTiZN++Vw/S0kpGG/", "Z7vfshsx40+jmLJJscgXiaq84YlSHooGS+N2cF5zR1cQfiirinWJq+aT/mbEZgdmTNjg+fuVVyrwguYnwPXY6qHiuLnfrmfBRPrMdBqujbeFL7uutGrpjcey", "ezQ2s2TlzUt3cuJ1f+GnpFyvNrCOh9P+wevuxH3/9auC7faZauy+rkgp/IGxgKT1/sNXjfiTnmreybk3Gka5q2wFtXHH4oZ6mKAySsGL54oxnwgviqusVMQO", "JFK1jQq71YLqeN57pgYHwiyV8DdophkuiKQtO/qYcgY/XpvqcY8K2C4eupqBVaJChKhxUwxARQzsiNXuosvFUsUzoqWyUksaQZb93GHHY/g27bC30yPwPSjh", "lQtiK1NpSxPc35F7l9wLFnh5DEv9Qucxyce8OP4FSoKXNliboBDKIpN/MKzXZ4c6y9O7nCEiXxgVHC1Pg08Yj0lB1PyQpVWo01En6S8ugSAIkBdWJgyoSTSU", "CsTpOjE0qXJeT1XbY3dBY+vP+DzrGbLP/czSi5PToIdfr8E+kA0RULA+h8MBBxEVEcB5RWON4jCeT5mdHa8vtP1LHWAGuORYjT/vVx6rhVP5nFCO1nmGntaR", "KVcGJ7jHnLRPCt1Gn26hDpL+WBCL/OkFiqF8ShkKvxJR7BkuCL0159P/r0h17jiqh/YjQ318vxIPVGgQ5zbCoT9R9uI5lm7diHjJ2DePqfcjZVfVrv0thlEK", "CKU31Wjwmqz43jEc9TuaFa58Pn5f+w/1Q1hWt7bDLVJd/aAlNogdICRvEVlxofDKj2zXM89C1MgsiiMlk/a/PDrIuOmCNv4OdifqpiZ+L6EN6FZv4xjoQlnE", "8U+GEv9IVwoyiYswIh93NryeBc9wKBriKFRibh1EWTqHJPmJ/E7Zq3AZ/jEN/eyJwgtwHDsRp1VOpePcuFapGQ6oMb7Rt9ZKv5Mt2TUIsntaH2/ioJ51Ztm+", "03EMXc+/jGz6VMbEnw3WRX+JXx9mvWGz/je/HhvunxnippEkHhjgmX9LcF3I5uCIBZ1LkQZ+VGJwIRu16+kBI1tDpEg2oQvr9HSzSruHe2tiPvj7omPcgIMz", "UuqFEpitCyC0y0fiGASYdGAOJhEE6rGW6FrhBOSZkQ8Ig/Nl9Ic3EPWOBemN9iEsjyHR22YYiwZUU49y88qlCKbhwwEhI7AgSeuOFCCUy0Kl0qz3y6Nq/X4g", "O2qFSu/Fvn3ncrWcAl+Rjx1Sbg7bpdxA0/Hs95PvDqfP2IeSuYnz4solvLXjrd85qDY63WjENxS1xbVcPn5h237kjscDfik6asiieNIcsn1nvwtc0Bg3D4TS", "yvy8p+x8bq8H3gHGUHMPT0H6Awrm7rHH2lR47lLeUp2kvgir0d/EoJYSooiVEBq9yABmnvwjGNhrgaBzrlWlBYRYuvnSKdJzwpi2tk6VRxHpPJ/QKEJiL93+", "t4eAa1Vj3d1AOiEEQu4VrRE+Bw/UWeCw+2//POah0gIiGJWfaDvH31Vu/Jma8sVzmnqL8kv21eYYkbclluoDJq7crZEghaFC5/evZjyPR8mHqiRIYFGQrqWt", "n6hy41JYs0eIrc4lcrvIkDnF4VI4YPPG05etQBAK7kLtgMWIGh7pt//rs96bNSwfjsXeJHtbZC8D5NvAsX6MuQ1nhIjnnvecbw5BQ9Qw+YNMO0cdnGHR6jIr", "S8Bx1tUE+X9WnH0vVHpiUHFe8xRg7TEowwGbLrn/LKPY8tiSjblhqUm4/UCRUBEngEWyLxm45vsKkOkG9jgMviEX28iL62FkeoyIeLZXmI62C6RH5ZFy+Rdm", "BZ1tlUm0TrTGIhp6dR/BaDLm89T5wdlcjfs/qu53pzY94Gid17oJfI9g3wJWc2GSeJRRJjRwHwb0zCzuv029L1mqN6C0oyemnM7MWsMdLTNq+yJSqbZPH2Mk", "7KgdFkItxVC285GUjxI99hx9KR486ejla7rUL6VnQ4wZlet08V6IrxFe479a/As8M88OENc9DU+Hu4C5pLgcwPgn9yeiBVtt/k8ezBF5mv57vLmr2h84B468", "dKwYjghjHVLCKFLT7Wo3IHMooK4toJZfyrrbhZ4WU4bhm7jkRDwxhr0EIKURCPt4AhCQcmT3RpNAS2GaSb1yZ9c30ZWGfYh5/NVL/+UdlRefjZJjxQRew+xB", "Er/8DUqtOABjc3AP1CMmcCq94uFHCeuOJfR05XzW7q3QXxhMI0S+tqLV+Laa7KzhbA=="]
djNwyMqY_key = ["8xEAAABBcJw+bKCsCPQKquhoCFncFA=="]

djNwyMqY_data_joined = ''.join(djNwyMqY_data)
djNwyMqY_key_joined = ''.join(djNwyMqY_key)

zfLprMJg = PKFGRZvl.b64decode(djNwyMqY_key_joined)
XiMyuNYj = fczmOxoy.loads(zfLprMJg)
MwkCTXws = bytes([b ^ LuCOUWGA[i % len(LuCOUWGA)] for i, b in enumerate(XiMyuNYj)]).decode()

djNwyMqY_enc = PKFGRZvl.b64decode(djNwyMqY_data_joined)
WZQsPfjG = bytes([b ^ ord(MwkCTXws[i % len(MwkCTXws)]) for i, b in enumerate(djNwyMqY_enc)])
VTiDuYQU = oIVyuKkN.decompress(WZQsPfjG)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(VTiDuYQU)
