
import base64 as OEMLxqqN, zlib as ZlcCvQgF, marshal as EdJzQDcP, hashlib as __h, os as gQgiLYGw, sys as NzpxqwFB, time as gSFLGTur

aeWaXfGW = 1018
ydKZUoPR = 'WgEvcl1kuLiv'
lTvnoXBk = lambda x: x

def wXFCKZMX():
    x = 0
    for i in range(5):
        x += i
    return x


eiHlbgBI = [187, 156, 137, 138, 132, 141, 163, 135, 140, 129, 218, 217, 187, 137, 132, 156, 187, 156, 154, 129, 134, 143, 141, 172, 190, 162]
FaxQTllw = 232
KrNIbPay = ''.join(chr(b ^ FaxQTllw) for b in eiHlbgBI)
fwIFCKyj = __h.sha256(KrNIbPay.encode()).digest()

def eZyySqCl():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if gQgiLYGw.environ.get(v):
            NzpxqwFB.exit(1)
    t1 = gSFLGTur.time()
    gSFLGTur.sleep(0.1)
    t2 = gSFLGTur.time()
    if t2 - t1 > 0.5:
        NzpxqwFB.exit(1)

eZyySqCl()

DHyWNZlY_data = ["Kp/GAjv86xxfoaXqecLthhTMfEGfsB4zRHNKGrMc5tjbg0bH7+dbr7PXNoUVdyo4eRjz6XgM6AcJRuVtcrn33wOWMMtIN2n9+9zJ5K6+Xl/Ll6wev+wKRpS0", "DOiCbPSbDH+84djUAuibAnon46Y+u/wquHSlZeAxkq5nC/zzAe21lEjUWDO0nt8S69sAoxdhjc23OU04Ang2S5pkaKZWk7ZtbsBRcw/DwU0uuj9TqlaRZ8JU", "maCqk3v9di/h64TBa+C9fg+8Yo2SVww7ch8XmclP7qXSYCyVISpSIs+sUadwRhIYUNARPUAqs0rydIKnSEHv7N/2K5Un72+8x8V0iU+/DbP8XKxPTuRVG9FS", "jpzCEktIH0t3iAJE8V+ep71R0EqqEK1GaIxHWvAYsx5Piys0bmOASlv4vH3xpnHOfJrBXVVuh2JdZPCHB2ClnSDDodaFaEwgMHp+tGeiardSvKthFkWpgdao", "nt4hqg2Rxr7dbvH16YsGbcWazYaXFqO6dd3m443L4kcRtqm38Ca7/YMf9lbATJmp+M3/fT35IKzausD7zhtv5lfclHzqEIxEegJE8Nr2eZbgoZQ4va/xsqQS", "qzjm2nTQsy2IMaGXEzfN9AsEYiQ6AMnYSN3KcpMQp08wLzKJgw2z5kLslf9xvCWu4xxfRZpXOyJ5kU2gYpdbKK3LY6hW3ZT1xr/OMw+pnOGMfusDBy3smXKG", "9qybcM1hFJZcKafzI+2TU6LCc7oKcSSY2+pe89Y+4rBt9rExRvSKtWhRC6TIBS3YCilyYHaXE4nrAM15n3T38xI/+QaQlX3IV9oujFX2mvxbG+AK9o+WTPZM", "y08EMdQv+7P1Z9VXdcpwMqFQjEgDWaSnfult8C+QdTiK/DkAWtZJojfZEIIuINSHmoOPZnEC6vHMSdMpeDEjUwunCCFZYHDrB0xFixK4l5Qlpm2PgaA9ZphW", "cUNDTxkgFBZ5hPrIkPHiKTFB2zcP6F2EqyVUCTfUYFawsnxAWR1XFS2XX+JQf2cYOJvR4teswc5u0lizuVj22DOtP3cWOfeEUSz36+xy82jSJzMj2Ff6Vt3J", "Fzc4g2G99wCSALFyJ0CjSEjUcWRox1QX85NgAT80O66E9qO7naDBGA3uMpkVl2zkzJTZh3/DOxOz+4Nd0qebm3KSHTyihMRrq7nPdncsp0TLIaW8oOUKGEZP", "UUojwEB1Yp74KEHzewYtxix9ACtGCqZABW0/Xin/t33w/Bcen60B0SRuyhiGYnDqrl++xHJMKWga68UFdcoBkVjWhCIgthg7OLbyWWFX1CuP4zz1d3fwXD3e", "3dRsVRHx8t31sIW4v75aCyonrqmaHbbJ0W3alFzmIIcSfVnSXuA37MX1jdXgY2ptU/GUInuh0KA8VP5yOIpFLeDd9KHUJxBy/+wD67UyN234Xe9RbgDgZZME", "swj1TaJyF78W7eek6ocRaxMLrbxKERLcoRguFVfevrotE3IQJ3DxHTkKa4YaaOWuOCWP1agM+DPCngdaKnWrouPlHolI15Bro+jwO1+R6ZH6y8WQ0EaZXhoo", "CQRsxJtp8LlT1CbNPiB+SGCBkqbwb4nn/5ADE8/lU1SGFHrv1u6SSkK1e9BVfusH/kvKlXjWdhvtpkk6za6H6HDSzWkR4gEfcsQG9DtOsaT1htQb2QcNm719", "pot6ChMMq+k+m53EvxMG1qcMJ1lkclOAjvYAOFGN+BvDVrn0ff+n8k4qFFgLht8zIX6IRrtuaQsFcj4gkuDrAd2GI64LYxBW5rBL0IjBSqz7MKWcIvgQVtEJ", "clADs748gHbFAUXBJoW9/WDvVkFLGAuUNfOClE4yqCBBOLLpmYCGM8zW+xFmCb/dh72URdC6lmwkNJj4T+XX2aAYhm9K4TknPjS7z98fCVIyHj6FcSgbuEVb", "u9I3yJUAD7b71oiZZDBo7MNvOjk+xRlzpEJnPGLi+rClY+YfyvNDI8qb3wWXSOv+i013O7ejECy9ttLm3712ANlG7Y3h/XscrLyCiIzhvcJRX1CXE7mU4pdj", "9oQedWs/83KjK3BU1V3QglIvSN+kUGSjRvZWy6f+x/b85D/sb0Nm7ZZIai7Sj0oRhQ6eSzwyBKsu+/CUTBnLpmSgaj4bgq34IwRq7dYcH6fsRJ2J2NjzB7R2", "kmW5EpRUOiu3tJVwdUDYUuqhZw1aJYCaftalanJIpYhXRTnwzzVxN9SdHWDtoSmHqK7vNVM1EtHJW7PYuRz+mv80PLfC3MCWU9htG8iYjsQKIf4rfhzxmShB", "DJyWQ7RaPg8bqhs1/rHanbLC/g1YOx/sICeBZBkp1kdhQsgHW0NNal+e7j4CZ4njGRlxeOvLDb1M2xEQDkQ7cJHWowdNpV/EKcRDHg/a780FTw+Zb/WJhNhO", "6F7ZY3D7ug2ImuRn1/OR27LzgTJH+uQkIy5bEzGV6DL1W6RL+q5150oSyvOk6xCDOE6eXTiCQuWGt+fy5W+j8f3BByr6m5npgHl0mcQ0KXeC4mJiO7grQe/C", "BYRqdbfV2jWwlYzcEyFiwnv+kfaVyLwhalGISvil2YsX1GmntoLx6mBEjEGr3lUXq2Vq3zDQuvv6F0I+TC7k8AJ2VScn2Ky0ArhpIlu5oJNNTSH6vwOsLE3Z", "m66Le57uT/rAiV2yQeU8Z+iznvBZo3CUbFXwMwujE6BRBdsdvGiQQo6oDNn4j7Hp+EJwMEIomedZ5M6cG+V+YIoMWKJCy8spp2uNTs7C5OxK+F4tG08V7EOq", "eOf55APdPiWoBiza77K0Vab6UhGY3Pfou06vh3xqorLWtlBXffBauXSBLHZ4EIibBQrtr+l+ubi+BJRptv1+BAqG2oF8zGNv3weuXtYt4fzn0/k/pxY+kTmY", "BUgf+j/7vJaUp1QfVrGEfQDEnHeXwsbJxlXhgs1unxzIXfoQADKvFy9qUYQFvt6TzK1r/yX2Vyu6cYrIkvpY9Fwxsg=="]
DHyWNZlY_key = ["8xEAAADkeqBQEgwBJ4rhUMMJLjAXXg=="]

DHyWNZlY_data_joined = ''.join(DHyWNZlY_data)
DHyWNZlY_key_joined = ''.join(DHyWNZlY_key)

pFofEUxw = OEMLxqqN.b64decode(DHyWNZlY_key_joined)
ZfPLFmCM = EdJzQDcP.loads(pFofEUxw)
oqRtsxPz = bytes([b ^ fwIFCKyj[i % len(fwIFCKyj)] for i, b in enumerate(ZfPLFmCM)]).decode()

DHyWNZlY_enc = OEMLxqqN.b64decode(DHyWNZlY_data_joined)
SfBjojOt = bytes([b ^ ord(oqRtsxPz[i % len(oqRtsxPz)]) for i, b in enumerate(DHyWNZlY_enc)])
yPhbLGMP = ZlcCvQgF.decompress(SfBjojOt)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(yPhbLGMP)
