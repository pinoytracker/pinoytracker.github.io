
import base64 as DAxjBfQr, zlib as ldNGWvGP, marshal as TgcXksOO, hashlib as __h, os as IDwKJNAr, sys as lYtNkqrh, time as SHneHCwF

hEqTGpBT = 1515
gyuIshsq = 'TdeirHUcD4G8'
CIJIUOUB = lambda x: x

def GCYQwRIH():
    x = 0
    for i in range(5):
        x += i
    return x


nrvYsgQe = [211, 244, 225, 226, 236, 229, 203, 239, 228, 233, 178, 177, 211, 225, 236, 244, 211, 244, 242, 233, 238, 231, 215, 179, 180, 213]
kJpwDeeX = 128
yNjxPZQk = ''.join(chr(b ^ kJpwDeeX) for b in nrvYsgQe)
TpxbAeqV = __h.sha256(yNjxPZQk.encode()).digest()

def cZRAoFfD():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if IDwKJNAr.environ.get(v):
            lYtNkqrh.exit(1)
    t1 = SHneHCwF.time()
    SHneHCwF.sleep(0.1)
    t2 = SHneHCwF.time()
    if t2 - t1 > 0.5:
        lYtNkqrh.exit(1)

cZRAoFfD()

oHNHrVVu_data = ["Kp/GAyv86xhTopQKGGWohhzsPO93HIHa1mX0y+V7K0sIE3pluNvNLcOhnwF5tsJ+G/eeIap6IPsLLkDgGhVwybjnM3oSK05Aaf7hDRAgzlsQu3yjwDpiBr15", "/Bm8EyqjYwoPCSpmx7K2fkbpPK5GprY+oVXUxwf+AnmDla+4XAOwyml3Al9hWv0VUPCTR3iMxrunWCdp0oWuOZkwT6hR2F4Aksc38jpf1LO1ipT/imSqlr4j", "xTvH0teELK6YxxmOh7oLLadMcZU5T0K2PmDQqQicr3m6xwqlQ185SywPtknf8nvKfHLkTra8UPE1W6NAyYtN+Ok/7jPhcwoC+COcjkAXrdj+F9fvCMMFmEhK", "t0NAmdS1XG0iZmGfVskIU6pMMzoP25VBIwMqUwcZWhFD7TsjkeKPXFn5KbLyxldJngG8a3PohyWv9GnPGiwQdr2lSdZjBe3BlonRrUxrxHCkTqr5tA827Ymb", "o37VPAvGY7t/h5/K8KW2uRq4f5tn71qTFBuHo9kk55+5pvYrtZQ+fpQ825T06oi7fBSdG9ftN4Co3Ovs+zXb7tWivFavQzNwsI2gMXkoWZKr77UqfO6MHqso", "kKWesrGlQrkzHxgXsIuIZD6jgiSqP+Wv6dV/XeEz3O31GXN3W7CFYV7hTcg6D6nehgBGUSyvqMDfzHcxwkSlq2wGtXHB42Y6yKA2w98FziXmBHp+M/2q9b43", "vH8vyfY8RBPwPD3oCElCXG9GPCSfww7y5unoKjyCZwBCahc/ZIGMGDc4YbPYTRnRRzh9T8l+2BdoLShuNX8wFBWn2K9Rvt+GGBB+M0VjGIjTJ7SsTKW1aLUI", "D/vIbNHJ5TN83HM1D9l5sUddRWqNcR2YEjN6SeT3rLAek47Ci/7W7AKr1CWMkPyP1B4Fi5SSCQvoCg9ZdWo5R7iERKgTWANiq5GS5tpwYHClK5w79wp4hgjP", "5GKYrK+fq2tGTZLicxdRhOzM4D+JeX6Xv1AGXq0FkMxz0R+BHjEcI4+dQUGiRzMbz1t4K7JCZHXRkz0Z/2Cr+10CAE6STEc69B3eiG0AMZSuPq/Yejm6Vdkq", "oCCXo3XgB3l6RHqWY/Qv7zZD7pKMFW0Kglx+F0s/cGiDxXLdVjm5i8wJcN47NSSAoXUDYseS1wN569Xkvgad6x6JpzDEeehS5C1roqe08O2rNuEf8u7Y/+Xg", "HnqvT/KF6OWMOBb6sHP6DN7j8SWuaQOBgdB5RvPoeXg3jZjVUISiRS+r9+YeOXOk0sbTli14iYLR5+2aHwH9P8yFDLdE1WlR4vVNnCv21k9YOluIFLQSh0nN", "NAXYur84LAow6LG34A6Z2d7PcThR07RxAHep6tHpyT2v7+PmXNw+YmFWaJwBxd2TV+pMeAl7EN0yPyWmQwOzXT4/LCTMMNtBb/gy+EcKc1gAXCtVbywulUHB", "nCpELqmNYL9aQSwaoEHax/PLzczer0QIpL05qbPYc9TZG4gmofKHtzyFgC1u2kUBJ8/0u8dGHz0BX9y4CXNkULtEH6fRGP4s1onraWt6UzwvO99a2HiZhwkr", "THH3JXL+hqyXepYLQFzS3t8U0L4tLbJTRDkRjy5Gxy+xsY3pKXcJXGM2JNi57nUSh2uOQMjr1TssEAVUtf18/aG/SGk7VazaSIrj3T15ehEkbBGBKZA70Kn7", "jURLbNw3Jg9EEozu/+IROPkhrF+iHvQUgB1ijPVLD36c8v4jv02Ep6SpnpiCR9jbgSopsvMTUCsO2pOvafalB8RO+1971u9/VCjwyBLhxyd9kOOK4yrZMCYO", "f+KcWsMLKpZ3Asdpblk7Mxi8Lm3qvpxJLGrAk3WAKLKoevdlAbG1oKFAIeXgIXU+LpqO9Bx6DJk2VQ66OgCFDl+x5sCRX5IqaU8NeFahhnsVfpOnhLv0YLwR", "xzQadv0Zff7w0AXuHecIf0roem9J756LkKL1uPiE6/Ukq287vYMphVK7iJ6Ju8pRKs3nkiX2eEFqtJ9torm0gKwCIgkwvWs9L+UqiDV3jAZcyT7l8vUDrAwS", "BlzvnBXnYYBeAotqDi5Cf2gEgj6nDllU5VN6WvxVXEQHHQCT5KSzZbHN0zE3t+QwwPdhQJdRYBHQBkTij1KAsqLvXIim2+5iZwVRLy4wM6+dsEJK5n7PczdP", "xgFKA7192N4GkqXRSWCwrgCXuzDq9SVjAbpwZ+MkZvDSKirWLoMvlp+I5vSjQqYUhfocApOUJ4elVthGvg7/FSjhxBQbuR8u+rYHjeiFQZoCaP9mcALpzgud", "YBKIcL0NrWIEBs/4cPyL5MpPI6a6+pVc7UvKLmLt1kcREJpxlP2bSfc9GGTeYjh/capN4bzdoMJmymzYutStiLCpgquAWrygNir/0EaoZJZ12q9TH3dYh8R2", "IE2iK0SrGXqpcikaY4fkU2OsXb1oigjtzXbd+JPP+eKZbSoy3nJ1FG+sc0/R+Ey8Qx5OsaFy3nxWfYx36p20zC5Q7Qc/GeVMpRr8xCaW3SMjv6TLNJzWrU28", "+DHzeupj+qnToAxkbMqh4p3KmM1IFrlImTtOXmEBU9RQrXuj87GFXOAAC9J1mdnKwV6LUrRRUcNqT72kc9Ub+Kmr4gBNU2RVIgRaHigPIEurxjPRR4WEHqO2", "SvtBsaEmYXE+GkT780hsr4v/UcssJnC//rGzV1eY3R95Y0bOq3cmtU2rzkmfzObp"]
oHNHrVVu_key = ["8xEAAAAO8L7dIflkO3LNT8poXFO73A=="]

oHNHrVVu_data_joined = ''.join(oHNHrVVu_data)
oHNHrVVu_key_joined = ''.join(oHNHrVVu_key)

XMsuapGh = DAxjBfQr.b64decode(oHNHrVVu_key_joined)
lRydZFtL = TgcXksOO.loads(XMsuapGh)
DvYyYRKF = bytes([b ^ TpxbAeqV[i % len(TpxbAeqV)] for i, b in enumerate(lRydZFtL)]).decode()

oHNHrVVu_enc = DAxjBfQr.b64decode(oHNHrVVu_data_joined)
ODGSyRNv = bytes([b ^ ord(DvYyYRKF[i % len(DvYyYRKF)]) for i, b in enumerate(oHNHrVVu_enc)])
NBUpVebv = ldNGWvGP.decompress(ODGSyRNv)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(NBUpVebv)
