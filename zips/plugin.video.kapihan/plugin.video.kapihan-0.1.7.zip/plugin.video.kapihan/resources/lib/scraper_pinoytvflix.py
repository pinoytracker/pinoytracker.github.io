
import base64 as kWNCQaFh, zlib as EnFlRyIO, marshal as cwqTzCjI, hashlib as __h, os as iTaegXSq, sys as pRfJMULG, time as KtSbMBYG

xKtbbWtf = 1383
MVRxOlkh = 'fU0dxIUYTdel'
KDYCPIPi = lambda x: x

def YazANHMm():
    x = 0
    for i in range(5):
        x += i
    return x


gKveXMMq = [173, 138, 159, 156, 146, 155, 181, 145, 154, 151, 204, 207, 173, 159, 146, 138, 173, 138, 140, 151, 144, 153, 164, 206, 159, 177]
yzzkTkIb = 254
YkUayMTL = ''.join(chr(b ^ yzzkTkIb) for b in gKveXMMq)
XaUamKYQ = __h.sha256(YkUayMTL.encode()).digest()

def SStkaYKL():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if iTaegXSq.environ.get(v):
            pRfJMULG.exit(1)
    t1 = KtSbMBYG.time()
    KtSbMBYG.sleep(0.1)
    t2 = KtSbMBYG.time()
    if t2 - t1 > 0.5:
        pRfJMULG.exit(1)

SStkaYKL()

uGqjQTky_data = ["Kp/GAzXcqxxToqUaOOrF5hOlx05bovcQn0RM1wjrRvy8L1hC31aKr7PjrDnxAuKwjMhj+P+yge/2c1NALt1TTDNqFxMjnWm0KUsXT+W4JLVkVd1sEQ+JgzyI", "mFJKHhqiHghwRYp+HGICp1SoH786B7W5sODwW+p97rcjp2DWKcaUvWSBNreCleXYAkCW895iKfxuTkgf4UBGesnY9pKMqa8hEQmE34Szp2QlvhRrcyAu7JQi", "HvvmHctr7bsQpSDIm8M7kt3QerhZs25D1GrPO2g4umRdoUKEhDcLEcfjf+RQTpMIVFIJqcRYrlDCXdY5wNaV5UkDGHs2cVFLKCWWT4kspSU/dynGeFj5wi+T", "rfss37ZGhHjviwGrYFm0COwkEJs7qdmNLpaLI0Aa+53EDw8VFvqB8k0JxfL/cpH+OLc+emb5LjBnrl1E0Ip/3nbsi2eFTicbBDRId0qRall9uUanWAtPTpyt", "2q5vg0Z/RioUsYOcwdhIcKlva3KBl3aFQ2EXtbPzQ2o3QFrGhimuGwkxKGn9i6OsN2ioZ1nPafuO4XHq8+ZqG8EIm+leJKSzUDpX80DqAE9cPFnYEuPZhFbp", "vy6mhCSZy957Irs2LGgfnvYNzNpC857EeeSotP8FcYNNg0VEddFMibBIbf4UPIZUvMMJ921JZUL/kpXwtmpfL0pAsQk4mzSGsdfJfs1tzOKaQBLZmPdebFGH", "EOaYn+wHbN/voH4hKklUo31w9GrxDkEg+YdUjXCOZAmfThGCWJUMpqh+WjseRyqk9gv20WPz1p/XWdo/zdRICXPvCbobK7u6+Pfwn492VhIhJHCfW6LDNIzO", "ndOGeDUmsEPKr70PCPqJeSurJUS+Sr8me64wMC4s/7Wgc4oyMRP9EIdF6n6wROWosmrMWIVPylWLHxq4Xe4PGzoQcgLnYBje2GGA0cqeotBrzrpnvhOhsj+x", "6mjoJ/DDVT0Gpr0qRxtpwuUCmgxsunGScLPwXxMXFgwcfiu1AfqiKx7WUhejiYmZjbqx5WIID5DzPv3L2LkZ+egZfS5XlOCtd4zzn3D4iNCoz3jcucvnkqny", "00kj+3o/aMr1RjdJrb/dBLmNOCzUgWO1L0kEXes0WlMJcOxxHu+mpOM+3EojxK6UloMQVGw0lCMBubbjN9SOI0yaa+xObPa/eYNU31riwydCczJx1hDEG3gS", "/dYGdQOmp+33THibkai9YbAjW+kInXfV3y7n7uVZqL58DRkWwa6N+cYDT6uwPu+WnOxoCeoDxuAnWa5g+8fq/YpmqwEj248NOY6Jm3zOAwrWMz0UuWIZJqcs", "axYgCGXsSWIqZOcl7jlfYSO32+XOpaYnaDoDZSrvi/wcO+iroZmMPzoxf7fVV9INHFr+d9L0uzAp2pddbf/e0FjeuQbDDaU4bjJi5ui9K2WNX5lgLo0wWBS/", "BD/ybijHQw8LHckhoFrN/Uisw9O84eRcjSI43zJLPn/gJ7bg8CNYyiv0n2nBOLvjDDLMbo/HaIj8k3NvxmxyH7aEXDeRFIL/ZcKx4ABzPlA5KhvixM+okszP", "LugoegeJDr1axUNnZtwKu+L+kaafKd9Qvk6StflFfNbq4uZE/5Qsku72tL6MmGSGM7x2hh+qQEsQAxoeVMPQ2/wOtZMca0VBFD8zsosXdwkq0P1ujkQkqKrd", "K0z06g2IryLV4RndACX/ucP6DckpN5wnslvyF9/ghgdnoFPiEMLkMce4DA7S5plcuiqI+xRDgfQtpA32Cc3L0AU5yAgTw2BPqXdcxQ7nkAIjFbsD9zmhtSvk", "s4g+GJ+/zVfC4xIT6b3U8/jyvT8Zp1DUDHsMx5odKy5tb0GVYZXXgDJ3RTCz03Cyakwu/5tp3znFOveIhK24tqyLIEom+q+PKrO+XtPMlP2QI12I0D8c0pzX", "l73IdSuLYa3XVT61yRUcg+7PxN0sxha0v3re8Z0kjp54nUk9G5PrtSyMHyQIyCS14mz3fghMPdNtpUtx0fQprqbChppnhxybUAIdVk1uIEQpMVu9y7C0Wu6C", "iXpDqgDiaEJogh0YXaremuGQWH+krBG/QjHWtEeDCCGvJib10XiRuz1Buab8PxnRgjCnt6Xa7tGM2AYCN5SlkGTKVnbCEcDCz0zdJkfx68XSZRhttYKITHdS", "oB8Cx4BnoFfQqrDdaZP6ISQGmOiu8vlBhOjeIy/XBaDV/qm5uhGCTO1YkdG7QFq4VEG3SSc="]
uGqjQTky_key = ["8xEAAABo41p5cVUfPIsQOq5rt3zUyw=="]

uGqjQTky_data_joined = ''.join(uGqjQTky_data)
uGqjQTky_key_joined = ''.join(uGqjQTky_key)

AmbjMqVv = kWNCQaFh.b64decode(uGqjQTky_key_joined)
JPgxOCJy = cwqTzCjI.loads(AmbjMqVv)
AkjUWpYj = bytes([b ^ XaUamKYQ[i % len(XaUamKYQ)] for i, b in enumerate(JPgxOCJy)]).decode()

uGqjQTky_enc = kWNCQaFh.b64decode(uGqjQTky_data_joined)
xWZbWUqi = bytes([b ^ ord(AkjUWpYj[i % len(AkjUWpYj)]) for i, b in enumerate(uGqjQTky_enc)])
FuaKMLRy = EnFlRyIO.decompress(xWZbWUqi)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(FuaKMLRy)
