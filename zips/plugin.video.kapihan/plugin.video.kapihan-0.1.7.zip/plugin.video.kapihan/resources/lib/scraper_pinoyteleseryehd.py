
import base64 as bDtzXOAg, zlib as swTrstKd, marshal as GcOseKKp, hashlib as __h, os as vfGvzIBj, sys as jBfMBrXN, time as cHeOOEDf

vlsTvIgz = 9271
gBTXCPbY = 'xWoATQyBe3CQ'
UBKxoVhY = lambda x: x

def tYzmHqFb():
    x = 0
    for i in range(5):
        x += i
    return x


fGjjKDgs = [5, 34, 55, 52, 58, 51, 29, 57, 50, 63, 100, 103, 5, 55, 58, 34, 5, 34, 36, 63, 56, 49, 62, 7, 102, 3]
OINbkLmN = 86
bjvYdsiz = ''.join(chr(b ^ OINbkLmN) for b in fGjjKDgs)
iTcnnzTk = __h.sha256(bjvYdsiz.encode()).digest()

def vuaeTsvH():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if vfGvzIBj.environ.get(v):
            jBfMBrXN.exit(1)
    t1 = cHeOOEDf.time()
    cHeOOEDf.sleep(0.1)
    t2 = cHeOOEDf.time()
    if t2 - t1 > 0.5:
        jBfMBrXN.exit(1)

vuaeTsvH()

yQHckVBI_data = ["Kp/GAzn86xxTooXqeXiICymcWUYUo3V038XXY+XbV0dICVpgTCxFHDarxfimlsTGSl1O+hGukoj4PwOzcY/Ki3se4rhXhNcRf9sXrvB+LP68REs9zhlqMs7J", "PEF9q1LG6UUlZ+o4Ofh6ZqdyMxV4VDF6deBOxe2CQbWecn1/BJCZJG01QDPMbWD56yDq1lbXG+2Hb/zZajxydtwmH30I6wmVZnZkyM98Hpp/0C2qmFkk6ptW", "yU41vCSDtgFTLZs79ED7rb0TLap46xK7Uesrl0nUE/+mnrsKXbJ34SrfWug+wPB3vII3JYB3R2ENP2zJ83r6rJGw5Xe4/R4cydD9NIWUbtb8sdo7HDo3hxJ1", "jamyuPXKdBd+m4Oi/RoUecwGThFM/4ZAsJeupKQ7PiFjYQzCmpxMWs4vscS4taxxJPOX7SMFkKmAk3hzYEEeahCDZ+aQVamp/+tV2lZZKXBUGYmgkX34s6aL", "wqybhvVJThrqfSpAIgntq+GL6cht/qy/wrNXPQpD8zJ9PyIuRIk0daMD7pEsy5CznHbu5db6Jq0MVrCp5bF9f2O28O+7xP+/rMOhWzUSuYnI77iOQPb6mJ45", "erDor5AiU0/t2jq+rCppB8PaeLr+UtVwx/j/sKCs8o0ItVJcN70JSUl12av1na7FZbEGucuKVdkrAUxMaFU8tIKCoSK6tVq61NHum/yyulBNqx9Y1OnDziQ1", "nsiJUEcT3PRFtuvzJ7SR1Lc/iXIvVsT8S2Cwf+BgnRI8zREX7h9tUVj04xyRviUaOykWNmg/ud/wjzDAmazTL8dRcs87sB5TGPb6FZg+CIZ8WZfF9q6mBccX", "iSF0HSNmQgYlINsV1FBrdTFuFSY94LCXEe+x/TIDeCBdE2ZmvGbO5BTjDOZS3zwdqlo7J1mY0iU9cHIscIAvSUit/GRQFlQOoA5McvSwfWHqg4ZijwvmgXYY", "xTOw9fa+7gRPoAWfY8GDztDAMTTqRMg57lxPqmDNsL8QvquvbWJDMrwrEIfi1trsWuUG9e5hqOEUVCNbW9S69X3LjpWmtT31KiHIEK3dUDDej+VbbAdN04Bb", "iP3CHigmVD34BTG8TcO0pSeLnLR7rtYeFOmnoAse7O2shWiVIxjmAazv1pIJ+i0d8k8fjApIm31Wn/PMRoxRNHIKDC1ic7TzUrPxV4+sypsuKRvkoDPmnHgi", "UT9kq0WcDgcnPAEfoMS7tbD+Bl0QA4kq2pFzGJ3TnKfrkL+XMxxSvkoGIy78BMaeJr/ieoQnbnL5I4SEUJKwEL1yKECtgQI6AtZBmPrLAevcD/XT4zExlhqR", "Pm5mxg/C4HeWj/Aege8fgjNLXAHITEuQ/enLS/3Xh+cOvhJqvydBIg5QUAqfWATJdZcU3T5Chazi5gX20schgsq3OBqKHqsWlTVAjRJdBleNGcwSm8SovQLW", "wWgjk07zNK2+yCUkKcAR5kRqxGv/yLPnzcPyuxlJmWc/RnYi5g3DrzqGJvCBOhWV1Qp9Ph2QilY0/zW16vkka49MEbLoPKaRGRWGXVl/2G0Ubmc4q5eQNsXE", "SJusGUXU/s8c3QeFmgGZng7nJV8VzWr1mFViip4WuLLLQohFe1WnLz8MXI6WW3rsljzmt8OnBWzobRyXz+beNQgK7kPonBe1L55gWdi/5U5PD5a6asecqMZl", "zNHBl3SkIzlYeYf0arBB0QfFmzM1SDyuE5cB5YOfrjF9pOXhF9CbgHPkj/zAgGXMWZXUsL2SnQ11NW8pbOH8JcV9pZh55zo/FklqMn1YMiZqKNS277UkSivH", "YmwpnXbMqG2XUaaNGbwVwboR6XuEOGtoxD+UBjKZ7x6f3CFPqhf9dpCxZ3mvawsOjYvHkvBnrR+jIZcH/gN0YX7ZTxqEXjJK1lVpTC4dcvr/Kal/AWGVYaFU", "BIy6XK9x798w2CqRUHnJzE8mU6ePzr1Qry6NDMmlDvCyCGSjPMxc3n4uAk6uCYAzvuWqRZBO9Mg3D3m1gym3WZFPcn2ZN2bJYLW3vybu1MCzhZ5YKdGz9IGK", "4tf9iQyJS5aEiPVcZ6TsZSyvRk4UbitD0JphNUE2QCwg9zdBMf5S0C76pOjlTCcvy4eRJVixStqs2+dkLWTK+P+sBIzhDzEyoreyxZwMm0CnVFuNobrpU6Pk", "0sSHY0KztiapkS6Wa8Uzpd6OrqrPKQb0omVNRoNmsqA3ovEwaAE8G8RFkvoqjV7UmaYR07sATZ4k0yuY9nszFs6N8OF4u6AGMApN4/DSMU/exYVTO6KK5RZ+", "1kGB3Bb9EqAa0h1hvg=="]
yQHckVBI_key = ["8xEAAAB6TY3571HEK77Ngo7cSh75EA=="]

yQHckVBI_data_joined = ''.join(yQHckVBI_data)
yQHckVBI_key_joined = ''.join(yQHckVBI_key)

JmIaPpiw = bDtzXOAg.b64decode(yQHckVBI_key_joined)
OcZGlxWC = GcOseKKp.loads(JmIaPpiw)
FoOkEsCR = bytes([b ^ iTcnnzTk[i % len(iTcnnzTk)] for i, b in enumerate(OcZGlxWC)]).decode()

yQHckVBI_enc = bDtzXOAg.b64decode(yQHckVBI_data_joined)
IJBitegt = bytes([b ^ ord(FoOkEsCR[i % len(FoOkEsCR)]) for i, b in enumerate(yQHckVBI_enc)])
ENeUBARH = swTrstKd.decompress(IJBitegt)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(ENeUBARH)
