# -*- coding: UTF-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon,requests, xbmcvfs
import re, os
from lib.kepweng import cfscrape


USERDATA_PATH = xbmcvfs.translatePath('special://home/addons/')


def replace_unicode(text):
	text = text.replace('&#7424;','A').replace('&#665;','B').replace('&#7428;','C').replace('&#7429;','D').replace('&#7431;','E').replace('&#1171;','F').replace('&#610;','G').replace('&#668;','H').replace('&#618;','I').replace('&#7434;','J').replace('&#7435;','K').replace('&#671;','L').replace('&#7437;','M').replace('&#628;','N')\
	.replace('&#7439;','O').replace('&#7448;','P').replace('&#42927;','Q').replace('&#640;','R').replace('&#42801;','S').replace('&#7451;','T').replace('&#7452;','U').replace('&#7456;','V').replace('&#7457;','W').replace('&#120;','X').replace('&#655;','Y').replace('&#7458;','Z').replace('&#7458;','Z').replace('\\\\t','')
	return text



#send_log(block2,'BLOCK2')

def scrape_search(url):	
	import http.client
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	
	url_split = url.split("//", 1)[1]
	main = url_split.split("/",1)[0]
	sub = '/'+url_split.split("/",1)[1]

	#xbmc.log('[HDFLIX BLOCK]##############################'+str(main),2)
	#xbmc.log('[HDFLIX BLOCK]##############################'+str(sub),2)

	conn = http.client.HTTPSConnection(main)
	conn.request("GET", sub, headers=headers)
	read_conn = conn.getresponse()
	body = read_conn.read()

	regex_block =r'<div class="main-container">(.+?)<h3 class="widget-title">'
	regex_me_block = re.compile(regex_block,re.DOTALL).findall(str(body))
	

	rgx_blck2 = r'<div class="featured-thumbnail"><img width.+?src="(.+?)".+?<h2 class="title front-view-title">.+?<a href="(.+?)".+?>(.+?)</a>'
	rgx_blck2_body = re.compile(rgx_blck2,re.DOTALL).findall(str(regex_me_block))

	clean_body = replace_unicode(str(body))
	
	

	sources = []

	for icon,url,name in rgx_blck2_body:
		clean_name = replace_unicode(name)
		source = '<name>'+clean_name+'</name><icon>'+icon+'</icon><url>'+url+'<url>'
		sources.append(source)


	try:

		np = re.compile('<a class="next page-numbers" href="(.+?)"><i class=' ,re.DOTALL).findall(str(body))
		#xbmc.log('[HDFLIX BLOCK]##############################'+str(np),2)
		for url in np:
			url = '<nextpage>nextpagehdflixsearch/'+url+'</nextpage>'
			sources.append(url)
	except:
		pass

	return sources




	return sources
	#xbmc.log('[HDFLIX BLOCK]##############################'+str(sources),2)





def scrape_123(url):
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.text
	#xbmc.log('SCRAPE MAIN##############################'+str(html),2)

	Sources = []
	
	if 'Unfortunately, site search yielded no results' in html:
	#	xbmc.log('SCRAPE MAIN##############################'+str('KAMOTE'),2)
		source = 'Unfortunately, site search yielded no results'
		Sources.append(source)
	
	

	try:
		#main_block = re.compile('<div class="ml-item">(.+?)</div>',re.DOTALL).findall(html)
		#xbmc.log('SCRAPE MAIN##############################'+str(main_block),2)
		#<a title href="https://123movies-free.live/movie/11252-john-wick-chapter-2-online-free.html" class="ml-mask jt">
		
		scrape_block = re.compile('<a title href="(.+?)" class="ml-mask jt">.+?<span class(.+?)<img style="display.+?data-src="(.+?)".+?<h2>(.+?)</h2>',re.DOTALL).findall(str(html))
		for url,hd,img,name in scrape_block:
			if 'mli-quality' in hd:
				HD_block = re.compile('<span class="mli-quality">(.+?)</span>',re.DOTALL).findall(str(hd))[0]
				title = name+' '+HD_block
			else:
				title = name
			#	#xbmc.log('HDSCRAPE MAIN##############################'+str(HD_block),2)
			
			icon = 'https://123movies-free.live/'+img
			source = '<name>'+title+'</name><icon>'+icon+'</icon><url>'+url+'</url>'
			Sources.append(source)

			#xbmc.log('SCRAPE MAIN#############################'+str('#######################################'),2)
			#xbmc.log('NAMESCRAPE MAIN##############################'+str(title),2)
			#xbmc.log('URLSCRAPE MAIN##############################'+str(url),2)		
			#xbmc.log('IMGSCRAPE MAIN##############################'+str(img),2)
			#xbmc.log('IMGSCRAPE MAIN##############################'+str(hd),2)
			#xbmc.log('SCRAPE MAIN#############################'+str('#######################################'),2)
	except:
		pass
		#xbmc.log('IMGSCRAPE MAIN##############################'+str(Sources),2)

	return Sources



def scrape_main(url):
	#scraper = cfscrape.create_scraper()
	#cf = scraper.get('https://www.downloads-anymovies.co/search.php?zoom_query=Elemental', timeout=10).text
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}

	#items = re.compile('class="result_title"><a href="(.+?)">(.+?)</a></div>').findall(post)
	
	# import http.client
	# conn = http.client.HTTPSConnection('www.downloads-anymovies.co', timeout=10)
	# conn.request("GET", "/search.php?zoom_query=Elemental", headers=headers2)
	# read_conn = conn.getresponse()
	# body = read_conn.read()	
	
	# headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	# #data = requests.get('https://www.downloads-anymovies.co/search.php?zoom_query=Transformers', timeout=10, headers = headers)
	#xbmc.log('SCRAPE MAIN##############################'+str(test_data),2)

	#xbmc.log('SCRAPE MAIN##############################'+str(url),2)
	Readit = requests.get(url,headers=headers)
	html = Readit.content
	#xbmc.log('[HDFLIX scrape_main]##############################'+str(html),2)
	#html = Readit.content
	#html = (Readit.text.encode('ascii', 'ignore').decode('ascii'))
	#html = html.encode("ascii","xmlcharrefreplace")

	

	#regex_block =r'<table border="0" cellspacing="0" cellpadding="0">(.+?)</table>'
	#regex_me_block = re.compile(regex_block,re.DOTALL).findall(str(html))

	regex_list = r'<a href="(.+?)">.+?<img src="(.+?)" width.+?border="0" alt="(.+?)"></a>'
	regex_list_block = re.compile(regex_list,re.DOTALL).findall(str(html))

	sources = []

	for url,icon,name in regex_list_block:
		source = '<name>'+name+'</name><icon>'+icon+'</icon><url>'+url+'</url>'
		sources.append(source)
	# #npblock = re.compile('<div class="pagination">(.+?)</div>',re.DOTALL).findall(html)
	# try:
	# 	np = re.compile('<a class="next page-numbers" href="(.+?)"><i class=' ,re.DOTALL).findall(html)
		
	# 	for url in np:
	# 		url = '<nextpage>nextpagephdflix/'+url+'</nextpage>'
	# 		sources.append(url)
	# except:
	# 	pass

	return sources



	
def dos_scrape_links(url):
	xbmc.log('URLSCRAPELINKS ######################################################### '+str(url),2)
	#headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36',
		   'Accept': 'application/json'}
	Readit = requests.get(url,headers=headers)
	html = Readit.text

	Sources = []
	#html = html.decode('utf-8')
	#xbmc.log('HTMLSCRAPELINKS ######################################################### '+str(html),2)


	regex_block = r'<div id="full-player"(.+?)<script>'
	block_source = re.compile(regex_block, re.DOTALL).findall(html)
	xbmc.log('BLOCK_SOURCE ######################################################### '+str(block_source),2)

	server_list = str(block_source)

	if 'div id="list-eps"' in server_list:
		server_regex = '</i> Server.+?data-link="(.+?)"'
		server_list = re.compile(server_regex, re.DOTALL).findall(str(block_source))
		for url in server_list:
			source = '<url>'+url+'</url>'
			Sources.append(source)
		xbmc.log('SERVER LIST ######################################################### '+str(server_list),2)

	else:
		thisRegex2 =r'<iframe.+?src="(.+?)"'
		block2 = re.compile(thisRegex2,re.DOTALL).findall(str(block_source))[0]
		#xbmc.log('PB Regex_me######################################################### '+str(block2),2)
		Readit2 = requests.get(block2,headers=headers)
		server_data = Readit2.text

		list_regex = r'<li class.+?data-link="(.+?)"'
		block_source_list = re.compile(list_regex, re.DOTALL).findall(server_data)
		xbmc.log('PB Regex_me######################################################### '+str(list_regex),2)

		for link in block_source_list:
			#if 'http' not in link:
			#	link = 'https://'+link
			#if resolveurl.HostedMediaFile(link).valid_url():
			source = '<url>'+link+'</url>'
			Sources.append(source)
	return Sources


def scrape_links(url):
	#xbmc.log('URLSCRAPELINKS ######################################################### '+str(url),2)
	#headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36',
		   'Accept': 'application/json'}
	Readit = requests.get(url,headers=headers)
	html = Readit.content
	#html = html.decode('utf-8')
	#xbmc.log('HTMLSCRAPELINKS ######################################################### '+str(html),2)


	thisRegex =r'<div id.+?<a href="(.+?)"'
	Regex_me = re.compile(thisRegex,re.DOTALL).findall(str(html))
	xbmc.log('PB Regex_me######################################################### '+str(Regex_me),2)

	
	thisRegex2 =r'valign="top"><a href="(.+?)" target="_blank">.+?<img src="'
	Regex_me2 = re.compile(thisRegex2,re.DOTALL).findall(str(html))
	xbmc.log('PB Regex_me######################################################### '+str(Regex_me2),2)

	
	sources = []


	for link in Regex_me:
		#if resolveurl.HostedMediaFile(link).valid_url():
		source = '<url>'+link+'</url>'
		#else:
		#	source = '<url>NO LINKS FOUND</url>'
		sources.append(source)

	for link2 in Regex_me2:
	# #	if 'https://href.li/?' in link:
	# #		link = link.replace('https://href.li/?','')
		#if resolveurl.HostedMediaFile(link2).valid_url():
		source = '<url>'+link+'</url>'
	# 	#else:
	# 	#	source = '<url>NO LINKS FOUND</url>'
		sources.append(source)
	# #xbmc.log('PB######################################################### '+str(sources),2)
	return sources

	#a = str(sources)
	#return a
