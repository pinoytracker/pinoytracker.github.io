
import base64 as unmvjQRu, zlib as lwaVjpeW, marshal as LfnHMmAX, hashlib as __h, os as AVUknYgx, sys as oKCxbobh, time as ZJttRstU

nPynaDqW = 5091
KPRDNuKy = 'wjdKC0pYKHEp'
zwIEPsog = lambda x: x

def rdneCAke():
    x = 0
    for i in range(5):
        x += i
    return x


CGGaBlMM = [2, 37, 48, 51, 61, 52, 26, 62, 53, 56, 99, 96, 2, 48, 61, 37, 2, 37, 35, 56, 63, 54, 6, 33, 16, 37]
kDOBoNfc = 81
SmrtrYCL = ''.join(chr(b ^ kDOBoNfc) for b in CGGaBlMM)
gXOZSCxL = __h.sha256(SmrtrYCL.encode()).digest()

def VIvDjjJj():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if AVUknYgx.environ.get(v):
            oKCxbobh.exit(1)
    t1 = ZJttRstU.time()
    ZJttRstU.sleep(0.1)
    t2 = ZJttRstU.time()
    if t2 - t1 > 0.5:
        oKCxbobh.exit(1)

VIvDjjJj()

aVtXSKdk_data = ["Kp/GAzn86xxTooXqeXiICylPUEeQyadtXEf9y097h9jbw3o8i+5SkhZppTawMT6573kHBqj+owz4f8Of2rMUw7s0WKpCiUuB1vv2e+uKPTxF/b7ihGgOkoGZ", "abl4Bmt5NrHGUFWPU3Ca/4UhwSxjqzVl5iDGtFtQ/uIP2TZYz4hPzoiKP7gk8IdcW/fXTMiYR6Lm0us+uxKpDUHVwhu7XsKHV0EUF7SxTFcnfjyi9OfNDTJM", "4dGp0Qm3FA2BGztv8lAPy9adOvtqswrT2Bss25XhW4GuoMLltIy0fa3xLtH2bLmOPiuZZa3IYDEtk5NSlyocIBnCPIMuBs8qj1XQNJIlrRh/z37LUJqsScI9", "Y79K57B0GDOk5vCTkRJi+2s95hx+r6FRh8zqB+5UdfVCot+cr6YuRyCC0OlkUqZsIP6ZH+jQB7WZZAarxZ5ytThNe0/ugO/5JPStEhaWuywOE+79puANwP9l", "YXg4mpDwgCqRJ3etrsYMnAV15EBOor+i2qbiXyePzRWQFW46Ozyc+vVNDsGlh62n4h6/rowDMA+fF4E7FPTeccfVxBr6HI+uAh5AHPfrIc7EgI4QZLthhC6X", "uLSE+Ig1m84P2wJtfSiGZkngJBW+PFtbjdszuOTmkgkY+ThsoXMLsPLD4FQGQ4eMN71chaBp5cyOy8zmN7l0b0vC1rK6HMc5z1dw5BQc/h06qCSOeonxCSrr", "+pdw0IjUpVliTXakeSR2I6MyU7mLkTznE3afdWlTBPXzltzA47+ygd0EwEFdDTbCAEHAFHp3BAYjYR9uAonC5yzV1cNdlsAyIka12+9emGFk1LJ5mONhOprP", "NHWZRx7mAv/9HrJvAC0/SiJ6rj4FR7ANFdQCfxK4bYpZD97mu7qYnPpxWWHwW5LJcF9FM3mNyZcqZ5oJL0Bpii6Z/66bsjV2NOO1PmxYFtp3NgaeB4iA6o+h", "+u7o6FpxTlN9DqDrvhNaxOiPwQ1C9DVP5r4l0KaNfLHhFuG1bOSTWTYDjYahFRBob2RgnB0xg9eLN7JGDq3wrhqxscSOUpp6uITNwpUH/jy0OY9+xfxURvMS", "b+got8BXIXRVl8dAr6/vd14sJOVmqJPji26ZLmIdZbP13eICdlZZhLJQkgbE2QYwsPGoTDbeB6RVuy9snckRFlcCnhzSCn1szvaPmHfSbxXJJpVL90O4nVRW", "pDdABo/ZHYGN7jX7b/KCk/xQyWSt8+uhnDNcVIakR48mHuae6HVezLhwF2KGQzJwvvM/fgdRqALD5BdHzsNxDKJ9JcOpaTzCP8r6yxOOXtaL+or/wTHjkdt/", "oSdEmmaE8I7aJvcwsQ9A8fgJZ+Bqd9YQc7BioX0uXeoyMcPDbCEy7KLPZTWAXz1mryOegjjrlRF3LamYvMbhC7KQ+Fz2ZsdPV4TdAXa42nFJ7FbddjahQJRf", "waboM202MWyARPrdfpACVzInnWjnD4uOfMgFD896Ri8xGXYW8KnEgIwTxAvbAKWK3dID0voSFOi/Pe2DuZ4WbYJYV4iE2Y//0U+tJ2Uyr0hKlYTqkZAOxRCK", "7/X4eiUhbLwrrdtwh6gHU5eDLCe8qO+vVYLHikL7SSRnbJ/1YDLK0KaLCSY2eTxel3URYpP1v/+ZB+FOCmLZtxeI3jU/kPCOR/81Kv8DaXHcr+BoICerVI/J", "L9+XVCzR1jEbDYlm/39zvNnqzlqFpJyNj0Hy/HLZlonjrHaTnq7zpPxiCGn7fAwlx5Jcoz6MTu7OMiGncsgWPDzEwZAn5tvJfvM7FuUPnuyzpXtHJiRmBQuG", "w+7KXdzFKRMqTB7OkZd1IQqNdy2+5RU0W0Lta5Exq+PtSQxr6kxqtyNMBSVkh8c8+pTMBBAYUqUABtUxCu8UZWXaM5KndV66oLSE1rNHUYiwafC9nST8A6Zx", "j8N0PJ3pSJJN15uLXDOnlArpsGxNMpxq/rNlJLbhsSBIK+Sy0FqJ6+dUHIdxF4HNzn5mRa9dD8x1EFyMRkpSpoj6RjwEdndTUWj1tB+EFCkvJlqEiwLT5CYz", "pPs1mKKGpui/t1QtUb3v+eOts5Kl1UxURIE6TzfqX4wlZK0emFFtZ7Qs5+hWt0bbzmCCbFeCD+FlJab+9W8yI3CMDabvSW6kDRuyAwHUCc8zkEC+9OSMHIL9", "9K1+iF7P+E4oGo1eNigQqdCxVktpkrb9seKYrDyDXRd1FaB70Coir6ugfnFrANaldPGGuThElQG4n8lJZtb+1ZrHReZkijG3VkkvQvv0vfuEwPdDMqQXbL6X", "NER8CQV0"]
aVtXSKdk_key = ["8xEAAAAintbQMZLE6hCH/f5VcZhTIQ=="]

aVtXSKdk_data_joined = ''.join(aVtXSKdk_data)
aVtXSKdk_key_joined = ''.join(aVtXSKdk_key)

lMTekzNH = unmvjQRu.b64decode(aVtXSKdk_key_joined)
ysamdVvA = LfnHMmAX.loads(lMTekzNH)
cTzrZxfS = bytes([b ^ gXOZSCxL[i % len(gXOZSCxL)] for i, b in enumerate(ysamdVvA)]).decode()

aVtXSKdk_enc = unmvjQRu.b64decode(aVtXSKdk_data_joined)
LhYpLCUh = bytes([b ^ ord(cTzrZxfS[i % len(cTzrZxfS)]) for i, b in enumerate(aVtXSKdk_enc)])
hrDggEiv = lwaVjpeW.decompress(LhYpLCUh)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(hrDggEiv)
