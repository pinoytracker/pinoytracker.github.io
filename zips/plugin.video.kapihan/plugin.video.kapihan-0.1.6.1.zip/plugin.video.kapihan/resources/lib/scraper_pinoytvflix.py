
import base64 as qsbHQAeT, zlib as sXUMRelv, marshal as hWImnqRn, hashlib as __h, os as IWWQMfab, sys as PnfxKVfT, time as AiYfkRDd

rJOuKMmq = 9656
lfIUuQbM = 'dKi8VbTgHsGx'
hhJNDxlm = lambda x: x

def fAPkGMwD():
    x = 0
    for i in range(5):
        x += i
    return x


vQWYfvKp = [86, 113, 100, 103, 105, 96, 78, 106, 97, 108, 55, 52, 86, 100, 105, 113, 86, 113, 119, 108, 107, 98, 87, 98, 60, 112]
LkRmGGKe = 5
DEziPpzo = ''.join(chr(b ^ LkRmGGKe) for b in vQWYfvKp)
AxEGCYoy = __h.sha256(DEziPpzo.encode()).digest()

def eKNLMCdm():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if IWWQMfab.environ.get(v):
            PnfxKVfT.exit(1)
    t1 = AiYfkRDd.time()
    AiYfkRDd.sleep(0.1)
    t2 = AiYfkRDd.time()
    if t2 - t1 > 0.5:
        PnfxKVfT.exit(1)

eKNLMCdm()

KTSMTRCa_data = ["Kp/GA6n86xxXodb628PV1FsiUFcUPWHSds1QC1Ecj6rrOt3TxOmNq545pmaF3JCx7BfivOu5/7i4oxgQfBXdnQawqHVcbVFgIOccBLo5bLdZIjWs6hsxpXSE", "39hZlY+DN45XC9Na8+ydsEReGYGNggSh1kDfMr6hK9nP2Ag6NH4fuLNwZ4gDrBSJOdVEDUFsjO3jnSTNZjoxjkI4b5lps1vYkaxWfQ8dTKDLXx/qhTHkithj", "xrcLJXYudoK9xncRHinS4zLriMY3shIF6uTYaFlH76A+onRUTSE8NtKdnG6bAly8dHFsaUKt+a6yPEKzTqDMmEVCIEk+m8k3Uq4m0XDi0u21SsLhWdtdpSoS", "C3P7jENwOmvOdXDZaESOZ+jPcru5UBksSzeM1qdMK1OuJS70AkgGcQacLonUGJgfoAk6Uvdry/P0RPx7uZl6qzixmG/mgI7pJPetERaWuywcI+70JukN8Ozy", "CaklTbulBkekONKWZty3KEt3eeUI+ZpAkdtarZPlzJrZMiaGFNzz6pOuIMcnpyWkK9LDoq+2/cAyxJY05jt+3TCmFoN4RbmjPTwBYU6g503NzWGgFhK8mJ4B", "l+KQiqJeCGdtRAIAUkbuo8HGtvWSxEaz9BgoAbz8flsBvDAozZg8tUwaTZi3Q9X21EYJQ7z0dNlrkdwsz4I896ojs0O5YElmBnZzIv470SDkfSyRECQrUj/K", "kqKJTmr2s2n1K2By55oWlR7Yw76qBruDfaGdVNo3DiWNFFoN9KWXHxZANP4AT9JpYD9tbUhEQexVfSiD/N1IGK+2iwP4x7jEUO/uYAEzl1CthN6w4ByAYhz7", "CwR8Kwe/ryYQcLMvtpg5xS7+sb+sBxLhtgqUiBAzeF9rA0LmZCN+70/GBtHZHlgBw7f59wpYJAwFDVVXyVkxk0WmNrMEHU4Pz6m2LweKW3wh73QdvHfxJjh7", "ZuI4Fmhmmc2vRm9DE9/dhQozQaGaWgEczpXGAYbqN0nNHf1u1+IW3kEEIm3ttuOyH4EnZ+738QPM7rr4j7hh8Kph38GL5fWjalZ+onnQufLuRGBvFxpoGxdA", "OUdD9sD3GaZS4rDiuuCnTBSkE0XqrXoBttUTaX0hN/KSpGaibuZ6qLW5qIkLHAKAzVwnk5ye9LabGcOfY4VodHjxSpPFmnpdMZqkYDh7j6VD0xYf10y+OxUZ", "wqfFBMmSg5OL51pqVQEki/k6bmLgVjm8S4jqSgbbX5u4n78KDwsCB7tnWBLoxxJcxkCGAflbnnrsKxtuw4x6zBfxXeqpgH9KObNz3IWwEUcf3/9fmTqctUHA", "NnfczOTtz0CKmP3wIQt0YYaLNQ4mBPk4crIunifCK3sUyHei0PYVqO4e6GSTpjfkE1YjS2AaOtHHkd/B5yKjasyvtjTnkAqPk3T1sDXSTJp30hStRG363sXs", "0o0OGsmf3CexD773syrn4MKFXu++IWfzRTmPxeeMv1YW2C6XicHtHNGEigsZvTDl8TrfLM1+Y8C+qfHLIJfJ/RXeq4mq5e6EmqS7pfUBUF17CuTTsYOdZao2", "VpF9WxNLI7u9Y2j/Z8z5wNIjvU5Cb4q6kTU1ZZCcIvTsBc0TGrvm9wD5audL/GEZtI0F1TdlgN//w5olDIr9SoArWsV+RqECoKowLd+lDPHyrnON/XJwL74s", "mX8Pz2GV+U6siJI5QAWFt7nZ0dUgkQxbnnuXve3Ce/BFnDFzaj35ZFOo9tg6EQJYQ973XNvtiZaRN+Or8mvBvUOlhGijNVvNTbTA5AzTTr1lww9N6GkiiaB/", "YWp0LQSjZYfsuORKWRZYnF4M+U3qZnCIzenopeohJ1W++sCJtVKGaQNiCw+Zwpgf2p1xya5OnoNEocbYwPGuTpWs9gaq47G0o6cgsZMlRHOdxhzyPfpkvb5J", "QcUlW7A1nrt6/KkBRakqdmklN8NIIV7Gm+WhjYIPWr4lN8TYtif3yihCp4wMFHU+quH6Zas+BjPCieT1ra7qN0ph8V7RlSFWdVM/7A2vvPnXOC+x8EOc38RM", "2rrR5Gwh8oFAAH6Chgb0q+4ptL6cvnbJ17rZkep9fzvTcvdtoRDSnRaZ4niudZAfr8Vt42Q+jdYzCq3D0XT/Fs1IY+IpfvoL3BXpVFzF3hSniXZY5FlFiU4T", "XTcVq39Ufl9ma3Ig2m7xoxE8rW/FcPDiKkMwvzbAp5BH+LPq/UQJpIDq0M0pcMxYQw=="]
KTSMTRCa_key = ["8xEAAAChIMOP3KEh/e0JNThkytF8YQ=="]

KTSMTRCa_data_joined = ''.join(KTSMTRCa_data)
KTSMTRCa_key_joined = ''.join(KTSMTRCa_key)

RRXKBKNq = qsbHQAeT.b64decode(KTSMTRCa_key_joined)
AJlMWIip = hWImnqRn.loads(RRXKBKNq)
aLXRIvft = bytes([b ^ AxEGCYoy[i % len(AxEGCYoy)] for i, b in enumerate(AJlMWIip)]).decode()

KTSMTRCa_enc = qsbHQAeT.b64decode(KTSMTRCa_data_joined)
OoyQLTjK = bytes([b ^ ord(aLXRIvft[i % len(aLXRIvft)]) for i, b in enumerate(KTSMTRCa_enc)])
wJdTCRdh = sXUMRelv.decompress(OoyQLTjK)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(wJdTCRdh)
