
import base64 as xQIbrqhf, zlib as kBgIQCkt, marshal as kYnNOVkP, hashlib as __h, os as ytGOWOLm, sys as ReOUPdSZ, time as QlbVwvcS

TeNfWLSZ = 2592
nPCxLiKu = 'nRXFTWMUbK34'
LBGxnNME = lambda x: x

def MGFPsmwJ():
    x = 0
    for i in range(5):
        x += i
    return x


MvplrgME = [242, 213, 192, 195, 205, 196, 234, 206, 197, 200, 147, 144, 242, 192, 205, 213, 242, 213, 211, 200, 207, 198, 242, 147, 149, 230]
MqCgHeHw = 161
DtUsJBcs = ''.join(chr(b ^ MqCgHeHw) for b in MvplrgME)
NIBtNgvp = __h.sha256(DtUsJBcs.encode()).digest()

def kvSJvWnB():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if ytGOWOLm.environ.get(v):
            ReOUPdSZ.exit(1)
    t1 = QlbVwvcS.time()
    QlbVwvcS.sleep(0.1)
    t2 = QlbVwvcS.time()
    if t2 - t1 > 0.5:
        ReOUPdSZ.exit(1)

kvSJvWnB()

ymwtorXU_data = ["Kp/GAzv86xxfoaXqeXiIW3xuNhsQ7xoGVM/zScfTL+LhUntEGjCVDHa2LKQ/Ir+RwZNhpyuMBj0G4TFXeTITDc9SpbN2ZfjRmOOcbgOB9QSuZ0V0uLWC0j6A", "hVLCnRpSnag3BYV+5DCqs19ZpWS9TrK4Iq83V9ZqULCI93oUqUh1sMJ4kEykBRe4Tv+QV8VAgPt4e/jT+PYEBj5onHSnXAxobz+XjyoU3c4juAbscvGTbt2e", "u5vO1t0aSYlTuJRBiMC1nA+8Yo0SFyyLErey/WBEfs77oXLE3/AqsKOVqdFAAlvMfxGH4kr/rC4zLBP27AWqC1/279Q/6W8+gqnaFzt8AapYFDQqTwGJ3l4u", "Vcsx81tTPmpFXScDxXY1avcTXELDjZIzXzeyO/tm2wxh2v/iTVxra7SxqtphmEo+l1fN6dcutav9UrTIW8PybdFMJlucseN+HIv9CtEYmP/Tf4ngkVXXuSaI", "m+q2rgAbeKD3iAV8L0hlWZeuIsGRytlh4Pjai/wOAy84PqIQTN2Dsaro6ENC4+OJ3toueLlhRot19ID0YgBlwfN7d2y+eOB3KjzcNV1vU0xWDMViBfZHzrCk", "qLgycXrm/misdVcdKwzNyAVWSRK/t9xb6M8gL6Ci7gOm9k70Yr+jL2fac7g88ouVyH+rNaP/0GhfyCZKLWMjKsFjmU45oFNup0xz7NTNpbxUbqolhyGNJrzC", "Dy+g3MwYmjbVDV2xBVTfCjyESSSgE9ARltRGO5hyOVgc4y2NlHr1xrs1lvjU/W+0RUo0vy9b2Rpls8wAoNuJP6feG7KmfOp3xjb7On0Wa/2SkkdjN6EtXWyM", "5VSBgrfS1t6WVkWfh8R+YT8F7ZvbXg6FvYZEFGgEXcCdOTymUeRXYlTwBTo2uOn+qQpxs6nfZz94DVii6wXA2zUs+DNdyoNDtt7MRGVEXijLURX2Kx6BUHPm", "APVe7PjUfSSnbircJ6yIdwVORPKut4XNkHtYbQH9qCCBaBkC766+BHHo/dylSHaOm6pe/pXXyxBVZISo5fAf3zZirycyuoJJL45tZRHfVPml0VxI89SA5nHT", "QQZyc+G/fk51sQPkbBHJ5u4hvT7gqy3f3rmLs47Es7DajzBiwtPOkN2Vw2XamACBlnQO6q3NbbJXlhzsuu/DOA/3FY9xVaalv0FWtMw8LzflxcasocfYzi1X", "HUjHbbIk7RXIpLtZzOuG76SoINQTWyQ7mDeqczrmyWpI4EMBBw1hTJrOU4bpZXu7D1AVa7mTJGgqvRTYp7pric4lGPxY5w2PI9tkzmKh6OxTDGKMOApH5nrk", "dmhpNnwTms4J64yBhg1vfY2SGo85sIYFV8Gct1spG4m0jrGZUCeJ7XnQXNUKHxlAEtnz8bX3d1di29HhUABhWNS+MB1r+Xv/+J5z0xfl+r5Rh/fUXPMdUO7f", "9rOgR5I5ufJSNjXJSUxbXhvAj3x/fcR/2xRZgQb7H8WOgZFvC2FArJRq2VL9W34/6AYPKdZMwP5uN5i9dVHWeyAe8NnRWkaG3xUQT+senkVpDgCxfn3nS4zD", "l4BryizR//zaIjJiTq7IYUJdh+SO+DANnqilC/zxKuvd+oyg8frHrZvp/j/V7JzRKQVuaybCTlPK0wOof6YffPcdmgD80FaJTvLLaSiNA1YTuC3aMRepCPyF", "9WbXuFahfxwPuS1UG19K5SBWPmZ2FaBSc7hUNp5al4xqjAWE+Bo1oLKV7vwOmIrvJcP2lcfBaPI5tPUJRIjyf0hPRFIuKKdv6L5dMqiLdCmAJQQafKG9Fv0l", "/O+NuQDdcZw0dLrg7w9n2YCyiJ/bT7/ahxZQ+NguhDzwlj//1HHzZEwj0Bclyi66bORbU/gFqjavldp3T5b4aaKSxmlvGQAp6Wu9KY/tp7wP7UP6aYKymsmW", "ZCJKXvy/d4jBV3EvYX2uWAtwzAjjedjG21f5jzTrNIu2rCtzpbnfu/52LJdlQ4WjJ+/irLIt1VbY57An5UKNNoGu0qSx4utYXvMKa7cAJUXl6jArZB94OPQD", "idxU4xjO2bNI84M+YZRmWaaRmEjq7He8EIBiuTm6RUv3OG6nNYig8fAUn3mcxoYm2qiZbreS4vk4AWcsr8HjmXiwo5smjOm4jP/Scg8IoFeS6p0E5L63h7th", "Kxibt3+XHWtOaobz/gJKhGla98AX8Pa0AQncV+ocfKAjwnb9CM7EiDBH0glPg/iIswmxG5YtbbJe4mn2UAybpXQEohVFL5V/CQNoeYeJBKEkg+gOmCFCAkx9", "0WIrS2J7SzMO6R4prkC1IfthXwuGLFiy8bIc6uwvsiphfbuVQXD6RHpfmkG7d6ABDkG9pcrd61Lw6izJvKgHqnfovJ+woKSg/M/JCby8RG4rzlEueCW+A62r", "E9H7uJ1IwKOJFUuj3Bf2zJEA6WHaJBaYAE7ogsam0Io4gOU6v6r7NpJ6CtqWCOvZp2o7ppRUvGjRrNMrxgvAzZI2QBvf3hHww+EcEygBJaWPP6RpOaE8HPr9", "59E5sGmBIKKdicbiCJcJjrrIBwUxhWKA1InH2TDKXPq4CTfayW3DLprqcLPrllRNAguxV8a2vd94j1SBnH9lNAql5GmncB/iv45+Qw5xWjwak/ALiMKFGlLS", "dN/9MwXd7hDW08rU1ED5z8Jk8WG/VuBspFPCtsy3mlc9eI30VNzaNANqs2k4sSnPr1LAwup7"]
ymwtorXU_key = ["8xEAAAAyQ1Z37FDbQ5ALDvyNIom4Ug=="]

ymwtorXU_data_joined = ''.join(ymwtorXU_data)
ymwtorXU_key_joined = ''.join(ymwtorXU_key)

imPmDcBK = xQIbrqhf.b64decode(ymwtorXU_key_joined)
wJdPsmWP = kYnNOVkP.loads(imPmDcBK)
PHVJFieD = bytes([b ^ NIBtNgvp[i % len(NIBtNgvp)] for i, b in enumerate(wJdPsmWP)]).decode()

ymwtorXU_enc = xQIbrqhf.b64decode(ymwtorXU_data_joined)
ImHItDmq = bytes([b ^ ord(PHVJFieD[i % len(PHVJFieD)]) for i, b in enumerate(ymwtorXU_enc)])
LMRuOijk = kBgIQCkt.decompress(ImHItDmq)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(LMRuOijk)
