# -*- coding: UTF-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon,requests, xbmcvfs
import re, os

USERDATA_PATH = xbmcvfs.translatePath('special://home/addons/')


def replace_unicode(text):
	text = text.replace('&#7424;','A').replace('&#665;','B').replace('&#7428;','C').replace('&#7429;','D').replace('&#7431;','E').replace('&#1171;','F').replace('&#610;','G').replace('&#668;','H').replace('&#618;','I').replace('&#7434;','J').replace('&#7435;','K').replace('&#671;','L').replace('&#7437;','M').replace('&#628;','N')\
	.replace('&#7439;','O').replace('&#7448;','P').replace('&#42927;','Q').replace('&#640;','R').replace('&#42801;','S').replace('&#7451;','T').replace('&#7452;','U').replace('&#7456;','V').replace('&#7457;','W').replace('&#120;','X').replace('&#655;','Y').replace('&#7458;','Z')
	return text





#send_log(block2,'BLOCK2')

def scrape_main(url):
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.text

	regex_block =r'<div class="main-container">(.+?)<nav class="navigation pagination"'
	regex_me_block = re.compile(regex_block,re.DOTALL).findall(str(html))

	regex_list = r'<article class="latestPost.+?>.+?<div class="featured-thumbnail"><img width="203" height="150" src="(.+?)".+?title="" /></div>.+?<header><h2 class="title front-view-title">.+?<a href="(.+?)".+?">(.+?)</a></h2>'
	list_match = re.compile(regex_list,re.DOTALL).findall(str(regex_me_block))


	
	sources = []

	for icon,url,name in list_match:
		name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&#038;','&').replace('&#8230;','...').replace('\\t\\t','')
		source = '<name>'+name+'</name><icon>'+icon+'</icon><url>'+url+'<url>'
		sources.append(source)
	

	
	#npblock = re.compile('<div class="pagination">(.+?)</div>',re.DOTALL).findall(html)
	np = re.compile('<a class="next page-numbers" href="(.+?)"><i class=' ,re.DOTALL).findall(html)
	
	for url in np:
		url = '<nextpage>nextpagephdflix/'+url+'</nextpage>'
		sources.append(url)

	return sources
	

def scrape_links(url):
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.content
	html = html.decode('utf-8')


	thisRegex =r'<h2 style=\"text-align(.+?)<div id="recent-posts-2'
	Regex_me = re.compile(thisRegex,re.DOTALL).findall(str(html))[0]
	xbmc.log('PB Regex_me######################################################### '+str(Regex_me),2)

	sources = []


	if "Coming Soon" in Regex_me:
		source = '<url>COMING SOON</url>'
		#else:
		#	source = '<url>NO LINKS FOUND</url>'
		sources.append(source)
	else:
		list_match = re.compile(r'<[iI][fF][rR][aA][mM][eE].+?[sS][rR][cC]="(.+?)"',re.DOTALL).findall(str(Regex_me))

	#match = re.compile('<div class="video-container">(.+?)<div id="video-bottom">',re.DOTALL).findall(html)[0]
	#block1 = re.compile('<[iI][fF][rR][aA][mM][eE] [sS][rR][cC]="(.+?)"',re.DOTALL).findall(str(match))
	#block2 = re.compile('<div class="su-button-center"><a href="(.+?)"',re.DOTALL).findall(str(match))	

		for link in list_match:
			#if resolveurl.HostedMediaFile(link).valid_url():
			source = '<url>'+link+'</url>'
			#else:
			#	source = '<url>NO LINKS FOUND</url>'
			sources.append(source)

	#for link in block2:
	#	if 'https://href.li/?' in link:
	#		link = link.replace('https://href.li/?','')
		#if resolveurl.HostedMediaFile(link).valid_url():
	#	source = '<url>'+link+'</url>'
		#else:
		#	source = '<url>NO LINKS FOUND</url>'
	#	sources.append(source)
	#xbmc.log('PB######################################################### '+str(sources),2)
	return sources

	#a = str(sources)
	#return a
