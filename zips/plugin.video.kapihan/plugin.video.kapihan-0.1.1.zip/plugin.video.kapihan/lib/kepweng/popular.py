# -*- coding: UTF-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon,requests, xbmcvfs
import re, os
#import jsunpack
#import urlresolver
#import resolveurl as resolveurl
#import jsunpack

#from addon.common.addon import Addon
#import json
#import time

#import urlparse
#import __builtin__

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
read_pb = requests.get('https://pastebin.com/raw/gjN94ax1', verify=False, headers=headers)
html_pb = read_pb.content
preurl = 'https://www1.dramacool.movie'
#xbmc.log('PB######################################################### '+str(html_pb),2)
	

#PASTEBIN REGEX BLOCK
#main_regex = re.compile('<ofwshow_regex>(.+?)</ofwshow_regex>',re.DOTALL).findall(html_pb)[0]
#xbmc.log('PB######################################################### '+str(main_regex),2)

#block1 = re.compile('<regex_main>(.+?)</regex_main>',re.DOTALL).findall(str(main_regex))[0]
#block2 = re.compile('<regex_submain>(.+?)</regex_submain>',re.DOTALL).findall(str(main_regex))[0]

#matches = re.compile('<match>(.+?)</match>',re.DOTALL).findall(str(main_regex))[0]
#np_block = re.compile('<np>(.+?)</np>',re.DOTALL).findall(str(main_regex))[0]
#np_phtv = re.compile('<np_phtv>(.+?)</np_phtv>',re.DOTALL).findall(str(main_regex))[0]
#NEXTPAGE
#np = re.compile('<np>(.+?)</np>',re.DOTALL).findall(html_pb)[0]
#xbmc.log('npblock######################################################### '+str(np_block),2)

#USERDATA_PATH = xbmc.translatePath('special://home/addons/')
#XBMCAddon
USERDATA_PATH = xbmcvfs.translatePath('special://home/addons/')
#ADDON_DATA = os.path.join(USERDATA_PATH,'script.module.kepwengnews')
#Log_file = os.path.join(ADDON_DATA,'Import_Log.txt')
#error_file = os.path.join(ADDON_DATA,'ErrorLog.txt')

# def send_log(scraper_data, optional = ''):

# 	if not os.path.exists(Log_file):
# 		full_write = open(Log_file,"w")

# 	elif os.path.exists(Log_file):
# 		full_write = open(Log_file,'a')	
	
# 	Print = '<##########################################################################################\
# 			\n##  query data: '+str(optional)\
# 			+'\n##  Data with: '+str(scraper_data)\
# 			+'\n#########################################################################################>' 
# 	full_write.write(Print+'\n')




# def send_log_error(scraper_data, optional = ''):
# 	if not os.path.exists(error_file):
# 		error_write = open(error_file,"w+")
# 	elif os.path.exists(error_file):
# 		error_write = open(error_file,'a')
	
# 	Print = '<##########################################################################################\
# 			\n##  query data: '+str(optional)\
# 			+'\n##  Data with: '+str(scraper_data)\
# 			+'\n#########################################################################################>' 
# 	error_write.write(Print+'\n')


def replace_unicode(text):
	text = text.replace('&#7424;','A').replace('&#665;','B').replace('&#7428;','C').replace('&#7429;','D').replace('&#7431;','E').replace('&#1171;','F').replace('&#610;','G').replace('&#668;','H').replace('&#618;','I').replace('&#7434;','J').replace('&#7435;','K').replace('&#671;','L').replace('&#7437;','M').replace('&#628;','N')\
	.replace('&#7439;','O').replace('&#7448;','P').replace('&#42927;','Q').replace('&#640;','R').replace('&#42801;','S').replace('&#7451;','T').replace('&#7452;','U').replace('&#7456;','V').replace('&#7457;','W').replace('&#120;','X').replace('&#655;','Y').replace('&#7458;','Z')
	return text

##########  NEW CODES FOR SEARCH POPULAR DRAMA HERE   ########
def scrape_search_most_popular(url):
	#xbmc.log('Scrape_most_popular ##############################'+str(url),2)
	pd = xbmcgui.DialogProgress()
	pd.create('Gathering Links Please Wait ...Dont Cancel')
	#send_log(url,'URL')
	#xbmc.log('scrape_scrape_details##############################'+str(url),2)
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	#html = Readit.content
	#html = html.decode('utf-8')
	html = Readit.text

	np = re.findall('(?s)<li class=\'next\'><a href=\'(.+?)\'',html)
	#xbmc.log('url_np_block ##############################'+str(np),2)

	main_block = re.compile('<ul class=\"switch-block list-episode-item\"(.+?)</ul>',re.DOTALL).findall(html)
	#url_main_block = re.compile('href="(.+?)" class="img"',re.DOTALL).findall(str(main_block))
	url_main_block = re.compile('href="(.+?)" class="img".+?<img src=.+?data-original="(.+?)".+?<h3 class="title".+?>(.+?)</h3>',re.DOTALL).findall(str(main_block))

	m = len(url_main_block)
	per = 100/m
	c=0
	num = 1

	Sources = []
	#send_log(list_match,'MAINBLOCK OFW HTML')
	for url,img,title in url_main_block:
		#xbmc.log('url_main_block ##############################'+str(url),2)

		pd.update(int(c*per),message='[B][COLOR yellow]Getting Status \'{}\'[/COLOR][/B]'.format(url))		
		
		#xbmc.log('scrape_scrape_details##############################'+str(url),2)
		#new_url = "popkdlink/" + url
		#xbmc.log('new_url ############################'+str(new_url),2)
		pre_url = 'https://www1.dramacool.movie'+url
		new_details = scrape_kdrama_details(pre_url)		
		new_details_regex = r'<title>(.+?)</title><icon>(.+?)</icon><status>(.+?)</status><description>(.+?)</description>'
		regex_new_details = re.compile(new_details_regex,re.DOTALL).findall(str(new_details))
		for title,icon,stat,descp in regex_new_details:
			source = '<url>'+url+'</url><name>'+title+'</name><icon>'+icon+'</icon><summary>'+descp+'</summary><status>'+stat+'</status>'
			Sources.append(source)
		c += 1
		num += 1
	pd.close()

	for url in np:
		#xbmc.log('url ##############################'+str(url),2)
		np_url = '<nextpage>nextsearchpage/'+url+'</nextpage>'
		Sources.append(np_url)
	return Sources
##########  NEW CODES FOR SEARCH POPULAR DRAMA TILL HERE   ########






##########  NEW CODES POPULAR DRAMA HERE   ########
def scrape_most_popular(url):
	#xbmc.log('Scrape_most_popular ##############################'+str(url),2)
	pd = xbmcgui.DialogProgress()
	pd.create('Gathering Links Please Wait ...Dont Cancel')
	#send_log(url,'URL')
	#xbmc.log('scrape_scrape_details##############################'+str(url),2)
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	#html = Readit.content
	#html = html.decode('utf-8')
	html = Readit.text

	np = re.findall('(?s)<li class=\'next\'><a href=\'(.+?)\'',html)
	#xbmc.log('url_np_block ##############################'+str(np),2)

	main_block = re.compile('<ul class=\"switch-block list-episode-item\"(.+?)</ul>',re.DOTALL).findall(html)
	#url_main_block = re.compile('href="(.+?)" class="img"',re.DOTALL).findall(str(main_block))
	url_main_block = re.compile('href="(.+?)" class="img".+?<img src=.+?data-original="(.+?)".+?<h3 class="title".+?>(.+?)</h3>',re.DOTALL).findall(str(main_block))

	m = len(url_main_block)
	per = 100/m
	c=0
	num = 1

	Sources = []
	#send_log(list_match,'MAINBLOCK OFW HTML')
	for url,img,title in url_main_block:
		#xbmc.log('url_main_block ##############################'+str(url),2)

		pd.update(int(c*per),message='[B][COLOR yellow]Getting Status \'{}\'[/COLOR][/B]'.format(url))		
		
		#xbmc.log('scrape_scrape_details##############################'+str(url),2)
		#new_url = "popkdlink/" + url
		#xbmc.log('new_url ############################'+str(new_url),2)
		pre_url = 'https://www1.dramacool.movie'+url
		new_details = scrape_kdrama_details(pre_url)		
		new_details_regex = r'<title>(.+?)</title><icon>(.+?)</icon><status>(.+?)</status><description>(.+?)</description>'
		regex_new_details = re.compile(new_details_regex,re.DOTALL).findall(str(new_details))
		for title,icon,stat,descp in regex_new_details:
			source = '<url>'+url+'</url><name>'+title+'</name><icon>'+icon+'</icon><summary>'+descp+'</summary><status>'+stat+'</status>'
			Sources.append(source)
		c += 1
		num += 1
	pd.close()

	for url in np:
		#xbmc.log('url ##############################'+str(url),2)
		np_url = '<nextpage>nextpageppkd/'+url+'</nextpage>'
		Sources.append(np_url)
	return Sources
##########  NEW CODES POPULAR DRAMA TILL HERE   ########



#KDRAMA DESCRIPTION AND STATUS
def scrape_kdrama_details(url):
	#xbmc.log('scrape_kdrama_details ##############################'+str(url),2)
	#send_log(url,'URL')
	#xbmc.log('scrape_popularkdrama_details ##############################'+str(url),2)
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.text
	Sources = []

	main_block = re.compile('<div class="details">(.+?)<div class="slider-star">',re.DOTALL).findall(html)
	matches = re.compile('<div class="img">.+?<img src="(.+?)".+?<h1>(.+?)</h1>.+?<span>Description:</span>.+?<p>(.+?)</p>.+?<p><span>Status:</span>.+?">(.+?)</a>',re.DOTALL).findall(str(main_block))

	for icon,title,description,status in matches:
		title = '<title>'+title+'</title>'
		status = '<status>'+status+'</status>'
		icon = '<icon>'+icon+'</icon>'
		description = '<description>'+description+'</description>'
		block_details = title+icon+status+description
		#xbmc.log('block_details ##############################################################'+str(block_details),2)
		Sources.append(block_details)
	return Sources
	#xbmc.log('sources ##############################'+str(sources),2)
###### KDRAMA DESCRIPTION AND STATUS TILLL HERE #########



###### DISPLAY KDRAMA EPISODES ###########
def display_kdrama_episodes(url):
	#xbmc.log('display_kdrama_episodes ##############################################################'+str(url),2)
	readme = requests.get(url,headers=headers)
	html = readme.text
	#html = html.decode('utf-8')
	Sources = []
	main2 = re.compile('<div class="block tab-container">(.+?)</ul>',re.DOTALL).findall(html)
	matches2 = re.compile('(?s)href="(.+?)"(?:.+?)<span class="(?:.+?)">(.+?)</span>(?:.+?)<h3 class="title".+?>(.+?)</h3>',re.DOTALL).findall(str(main2))
	# xbmc.log('matches2 ##############################################################'+str(matches2),2)
	for url,rs,title in matches2:
		source = '<episodes_url>'+url+'</episodes_url><episodes_sub>'+rs+'</episodes_sub><episodes_num>'+title+'</episodes_num>'
		Sources.append(source)
	# xbmc.log('Sources ##############################################################'+str(Sources),2)
	return Sources
###### DISPLAY KDRAMA EPISODES TILL HERE ###########


###### GET KOREAN PLAY LINKS HERE ###########
def scrape_play_links(url):
	#xbmc.log('scrape_movie_links URLNOW ######################################################## '+str(url),2)
	#pd = xbmcgui.DialogProgress()
	#pd.create('Please Wait ...Dont Cancel')
	Sources = []
	#title_description = []

	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.text

	#xbmc.log('details_me######################################################### '+str(new_url),2)
	#xbmc.log('details_me######################################################### '+str(details_me),2)
	
	get_categ_link_block = re.compile('<div class="category">.+?<span>Category:.+?<a href="(.+?)"',re.DOTALL).findall(html)[0]
	new_url = 'https://www1.dramacool.movie'+ get_categ_link_block
	#xbmc.log('get_categ_link_block ######################################################### '+str(new_url),2)

	playlink_pass = '<playlink_pass>'+new_url+'</playlink_pass>'
	Sources.append(playlink_pass)

	main_block = re.compile('<div class="anime_muti_link"><ul>(.+?)</ul></div>',re.DOTALL).findall(html)
	matches = re.compile('<li class=".+?data-video="(.+?)">.+?<span>',re.DOTALL).findall(str(main_block))


	for url in matches:
		#xbmc.log('URLmatches######################################################### '+str(url),2)
		if 'https:' not in url:
			url = 'https:' + url

		source = '<url>'+url+'</url>'				
		#try:
		#	name = url.split('//')[1].replace('www.','')
		#	name = name.split('/')[0].split('.')[0].title()
		#except:pass
		#xbmc.log('URLNOW######################################################### '+str(url),2)
		#xbmc.log('NAMEURLNOW######################################################### '+str(name),2)
		Sources.append(source)	
	#sources.extend(title_description)
	return Sources
	#xbmc.log('return sources ######################################################### '+str(sources),2)
###### GET KOREAN PLAY LINKS TILL HERE ###########




####### GET BLOCK DETAILS FOR MOVIES EPISODE DRAMA ########
def scrape_movie_details(url):
	#pre_url = url
	xbmc.log('scrape_movie_details URL ######################################################### '+str(url),2)
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.text
	sources = []

	movie_drama_tab = r'<div class="block-tab">.+?<h1>(.+?)</h1>'
	regex_movie_drama_tab = re.compile(movie_drama_tab,re.DOTALL).findall(html)[0]
	#xbmc.log('regex_movie_drama_tab ######################################################### '+str(regex_movie_drama_tab),2)

	main_block = re.compile('<ul class=\"switch-block list-episode-item\"(.+?)</ul>',re.DOTALL).findall(html)
	#xbmc.log('main_block######################################################### '+str(main_block),2)
	url_main_block = re.compile('href="(.+?)" class="img".+?<img src=.+?data-original="(.+?)".+?<span class=.+?>(.+?)</span>.+?<h3 class="title".+?>(.+?)</h3>.+?<span class="ep.+?>(.+?)</span>',re.DOTALL).findall(str(main_block))
	#xbmc.log('url_main_block ######################################################### '+str(url_main_block),2)	
	for url,icon,sub,name,epnum in url_main_block:
	# 	Readit = requests.get(url,headers=headers)
	# 	html = Readit.text
		#descp_link = 'https://www1.dramacool.movie'+url
		#new_summ = scrape_movie_description(descp_link)
		

		summary = "CLICK FOR DETAILS"
		#if "Movie" in regex_movie_drama_tab:
		#	new_url = "movielink/" + url
		#elif "Drama" in regex_movie_drama_tab:
		#	new_url = 'nextrecentlypagekdrama/'+url
		#elif "Kshow" in regex_movie_drama_tab:
		#	new_url = 'nextrecentlypagekdrama/'+url
		#new_url = "movielink/" + url
		#title = title + ' ([COLOR yellow] STATUS: [/COLOR]' + '[COLOR red]'+status +'[/COLOR])'
		#xbmc.log('NEW_ URL ######################################################### '+str(url),2)
		#xbmc.log('NEW_ URL ######################################################### '+str(new_url),2)
		source = '<url>'+url+'</url><name>'+name+'</name><icon>'+icon+'</icon><summary>'+summary+'</summary><status>'+sub+'</status><epnum>'+epnum+'</epnum>'
		#xbmc.log('source ######################################################### '+str(source),2)
			
	# 	# 	# 	send_log(sources,'SOURCES')	

	
	# 	# #try:
	# 	# #	npblock = re.compile(np_block,re.DOTALL).findall(html)[0]
	# 	# #	url = '<nextpage>nextpage/'+npblock+'</nextpage>'
	# 	# #send_log(url,'NEXTPAGE URL')
	# 	# #	sources.append(url)
	# 	# #except:pass
		sources.append(source)
	# #	c += 1
	# #	num += 1
	# #pd.close()

	np = re.findall('(?s)<li class=\'next\'><a href=\'(.+?)\'',html)
	#xbmc.log('URLNOW######################################################### '+str(np),2)

	for url in np:
		xbmc.log('URL regex TAB ######################################################### '+str(np),2)
		if "Movie" in regex_movie_drama_tab:
			nextpage_url = 'nextpagekmovie/'+url
		elif "Drama" in regex_movie_drama_tab:
			nextpage_url = 'nextrecentlypagekdrama/'+url
		elif "Kshow" in regex_movie_drama_tab:
			nextpage_url = 'nextrecentlykshow/'+url

		xbmc.log('nextpage_url ######################################################### '+str(nextpage_url),2)
		holder_url = '<nextpage>'+nextpage_url+'</nextpage>'
		sources.append(holder_url)	
	return sources
####### GET BLOCK DETAILS FOR MOVIES EPISODE DRAMA TILL HERE ###########






# def scrape_movie_description(url):
# 	xbmc.log('scrape_movie_description URLNOW######################################################### '+str(url),2)
# 	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
# 	Readit = requests.get(url,headers=headers)
# 	html = Readit.text
# 	sources = []

# 	#get_categ_link_block = re.compile('<div class="category">.+?<span>Category:.+?<a href="(.+?)"',re.DOTALL).findall(html)
# 	#xbmc.log('get_html ##################################################### '+str(html),2)
# 	#for categ_link in get_categ_link_block:
# 	#	xbmc.log('categ_link  ######################################################### '+str(categ_link),2)
# 		#headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
# 		#Readit = requests.get(url,headers=headers)
# 		#html = Readit.text
# 	details_block = re.compile('<span>Description:</span>.+?<p>(.+?)</p>',re.DOTALL).findall(html)[0]
# 	details_title = re.compile('<div class="info">.+?<h1>(.+?)</h1>',re.DOTALL).findall(html)[0]

# 	#description_source = '<m_descp>'+details_block+'</m_descp>'
# 	new_title = '<m_title>'+details_title+'</m_title><m_descp>'+details_block+'</m_descp>'
	
# 	#sources.append(description_source)
# 	sources.append(new_title)
	
# 	#xbmc.log('details_block ######################################################### '+str(description_source),2)
# 	xbmc.log('details_block ######################################################### '+str(new_title),2)
# 	#return details_block
# 	#return details_title
# 	return sources
# 	xbmc.log('sources###################################################### '+str(sources),2)




#send_log(block2,'BLOCK2')
#ORIG SCRAPE DETAILS HERE#
# def scrape_details(url):
# 	#xbmc.log('1ST url ##############################'+str(url),2)
# 	pd = xbmcgui.DialogProgress()
# 	pd.create('Gathering Links Please Wait ...Dont Cancel')
# 	#send_log(url,'URL')
# 	xbmc.log('scrape_scrape_details##############################'+str(url),2)
# 	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
# 	Readit = requests.get(url,headers=headers)
# 	#html = Readit.content
# 	#html = html.decode('utf-8')
# 	html = Readit.text

# 	main_block = re.compile('<ul class=\"switch-block list-episode-item\"(.+?)</ul>',re.DOTALL).findall(html)
# 	url_main_block = re.compile('href="(.+?)" class="img"',re.DOTALL).findall(str(main_block))

# 	m = len(url_main_block)
# 	per = 100/m
# 	c=0
# 	num = 1

# 	sources = []
# 	#send_log(list_match,'MAINBLOCK OFW HTML')
# 	for url in url_main_block:
# 		xbmc.log('url_main_block ##############################'+str(url),2)

# 		pd.update(int(c*per),message='[B][COLOR yellow]Adding Links \'{}\'[/COLOR][/B]'.format(url))		
		
# 		#xbmc.log('scrape_scrape_details##############################'+str(url),2)
# 		new_url = 'https://www1.dramacool.movie'+url
# 		popular_kdrama_details = scrape_popularkdrama_details(new_url)
# 		xbmc.log('popular_kdrama_details ##############################'+str(popular_kdrama_details),2)
# 		#new_readit = requests.get(new_url,headers=headers)
# 		#new_html = new_readit.text

# 		#regexme = r'<div class="details">(.+?)<div class="slider-star">'
# 		#list_match = re.compile(regexme,re.DOTALL).findall(new_html)

# 		#regexme2 = r'<div class="img">.+?<img src="(.+?)".+?<h1>(.+?)</h1>.+?<span>Description:</span>.+?<p>(.+?)</p>.+?<p><span>Status:</span>.+?">(.+?)</a>'
# 		#list_match2 = re.compile(regexme2,re.DOTALL).findall(str(list_match))
# 		#xbmc.log('scrape_scrape_details##############################'+str(list_match2),2)		

# 		#for icon,title,description,status in list_match2:
# 		#	description = description
# 			#title = title + ' ([COLOR yellow] STATUS: [/COLOR]' + '[COLOR red]'+status +'[/COLOR])'
# 		#	source = '<url>'+url+'</url><name>'+title+'</name><icon>'+icon+'</icon><summary>'+description+'</summary><status>'+status+'</status>'
# 			#send_log(sources,'SOURCES')
# 		sources.append(popular_kdrama_details)
# 		c += 1
# 		num += 1
# 	pd.close()
# 	#return sources

# 	np = re.findall('(?s)<li class=\'next\'><a href=\'(.+?)\'',html)
# 	for url in np:
# 		url = '<nextpage>nextpagek/'+url+'</nextpage>'
# 		sources.append(url)

# 	return sources
#ORIG SCRAPE DETAILS TILL HERE#



	# #player code below
	# getplayer = re.compile('<div id="player">(.+?)</script>',re.DOTALL).findall(html)
	# getformdata = re.compile('get_player\("(.+?)","(.+?)"\)',re.DOTALL).findall(str(getplayer))
	
	# for url_post,thumb in getformdata:
	# 	url_post = url_post
	# 	thumb = thumb
	# 	#send_log(url_post,'OFW DATA')
	# 	#send_log(thumb,'OFW DATA')

	# new_headers = {'authority':'ofwshow.ru',
	# 			'origin':'https://ofwshow.ru',
	# 			'Referer':url,
	# 			'x-requested-with': 'XMLHttpRequest',
	# 			'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}

	# post_player = 'https://ofwshow.ru/function.php'

	# data = {'url': url_post,
	# 		'thumb':thumb}
	
	# get_player_source = requests.post(post_player, data = data, headers = new_headers)
	# player_data = get_player_source.content








# def Displayepisodes(url):
# 	#xbmc.log('##############################################################'+str(url),2)
# 	readme = requests.get(url,headers=headers)
# 	html = readme.content
# 	html = html.decode('utf-8')
	
# 	main_block = re.compile('<div class="details">(.+?)<div class="slider-star">',re.DOTALL).findall(html)
# 	matches = re.compile('<div class="img">.+?<img src="(.+?)".+?<h1>(.+?)</h1>.+?<span>Description:</span>.+?<p>(.+?)</p>.+?<p><span>Status:</span>.+?">(.+?)</a>',re.DOTALL).findall(str(main_block))

# 	for icon,title,description,status in matches:
# 		title = title + ' ([B][COLOR yellow] STATUS: [/COLOR]' + '[COLOR red]'+status +'[/COLOR] )'
	
# 		add_dir('f','displaymenu','','[B][COLOR yellow]Home Menu[/COLOR][/B]','','','')

# 		add_dir('','','','[B][COLOR white]'+title+'[/COLOR][/B]',icon,icon,description)
# 		add_dir('f','displaycast',url,'[B][COLOR white]Select Casts for their Shows [/COLOR][/B]',icon,icon,description)

# 	main2 = re.compile('<div class="block tab-container">(.+?)</ul>',re.DOTALL).findall(html)
# 	matches2 = re.compile('(?s)href="(.+?)"(?:.+?)<span class="(?:.+?)">(.+?)</span>(?:.+?)<h3 class="title".+?>(.+?)</h3>',re.DOTALL).findall(str(main2))
	
# 	for url,rs,title in matches2:
# 		#xbmc.log('URLSSSSSS##################'+str(url),2)
# 		url = preurl + url
# 		#xbmc.log('URLSSSSSS##################'+str(url),2)

# 		show = title.split('   ')[0]
# 		epi = title.split('Episode')[1]
# 		rs = (rs + ' ')
# 		if 'RAW' in rs:
# 			rs = '[COLOR red]'+rs+'[/COLOR]'
# 		else:
# 			rs = '[COLOR yellow]'+rs+'[/COLOR]'
# 		name = rs + show + ' [COLOR blue](Episode' + epi + ')'
# 		add_dir('f','displaylinks',url,'[B][COLOR white]'+name+'[/COLOR][/B]',thumb,thumb,desc)	





# def scrape_links(url):
# 	#xbmc.log('URLNOW######################################################### '+str(url),2)
# 	#pd = xbmcgui.DialogProgress()
# 	#pd.create('Please Wait ...Dont Cancel')
# 	sources = []

# 	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
# 	Readit = requests.get(url,headers=headers)
# 	html = Readit.content




# 	#player code below
# 	getplayer = re.compile('<div id="player">(.+?)</script>',re.DOTALL).findall(html)
# 	getformdata = re.compile('get_player\("(.+?)","(.+?)"\)',re.DOTALL).findall(str(getplayer))
	
# 	for url_post,thumb in getformdata:
# 		url_post = url_post
# 		thumb = thumb
# 		#send_log(url_post,'OFW DATA')
# 		#send_log(thumb,'OFW DATA')

# 	new_headers = {'authority':'ofwshow.ru',
# 				'origin':'https://ofwshow.ru',
# 				'Referer':url,
# 				'x-requested-with': 'XMLHttpRequest',
# 				'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}

# 	post_player = 'https://ofwshow.ru/function.php'

# 	data = {'url': url_post,
# 			'thumb':thumb}
	
# 	get_player_source = requests.post(post_player, data = data, headers = new_headers)
# 	player_data = get_player_source.content


