# -*- coding: UTF-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon,requests, xbmcvfs
import re, os

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
preurl = 'https://www1.dramacool.movie'
USERDATA_PATH = xbmcvfs.translatePath('special://home/addons/')



def replace_unicode(text):
	text = text.replace('&#7424;','A').replace('&#665;','B').replace('&#7428;','C').replace('&#7429;','D').replace('&#7431;','E').replace('&#1171;','F').replace('&#610;','G').replace('&#668;','H').replace('&#618;','I').replace('&#7434;','J').replace('&#7435;','K').replace('&#671;','L').replace('&#7437;','M').replace('&#628;','N')\
	.replace('&#7439;','O').replace('&#7448;','P').replace('&#42927;','Q').replace('&#640;','R').replace('&#42801;','S').replace('&#7451;','T').replace('&#7452;','U').replace('&#7456;','V').replace('&#7457;','W').replace('&#120;','X').replace('&#655;','Y').replace('&#7458;','Z')
	return text

##########  NEW CODES FOR SEARCH POPULAR DRAMA HERE   ########
def scrape_search_most_popular(url):
	#xbmc.log('Scrape_most_popular ##############################'+str(url),2)
	pd = xbmcgui.DialogProgress()
	pd.create('Gathering Links Please Wait ...Dont Cancel')
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.text

	np = re.findall('(?s)<li class=\'next\'><a href=\'(.+?)\'',html)
	#xbmc.log('url_np_block ##############################'+str(np),2)

	main_block = re.compile('<ul class=\"switch-block list-episode-item\"(.+?)</ul>',re.DOTALL).findall(html)
	#url_main_block = re.compile('href="(.+?)" class="img"',re.DOTALL).findall(str(main_block))
	url_main_block = re.compile('href="(.+?)" class="img".+?<img src=.+?data-original="(.+?)".+?<h3 class="title".+?>(.+?)</h3>',re.DOTALL).findall(str(main_block))

	m = len(url_main_block)
	per = 100/m
	c=0
	num = 1

	Sources = []
	#send_log(list_match,'MAINBLOCK OFW HTML')
	for url,img,title in url_main_block:
		#xbmc.log('url_main_block ##############################'+str(url),2)

		pd.update(int(c*per),message='[B][COLOR yellow]Getting Status \'{}\'[/COLOR][/B]'.format(url))		
		
		#xbmc.log('scrape_scrape_details##############################'+str(url),2)
		#new_url = "popkdlink/" + url
		#xbmc.log('new_url ############################'+str(new_url),2)
		pre_url = 'https://www1.dramacool.movie'+url
		new_details = scrape_kdrama_details(pre_url)		
		new_details_regex = r'<title>(.+?)</title><icon>(.+?)</icon><status>(.+?)</status><description>(.+?)</description>'
		regex_new_details = re.compile(new_details_regex,re.DOTALL).findall(str(new_details))
		for title,icon,stat,descp in regex_new_details:
			source = '<url>'+url+'</url><name>'+title+'</name><icon>'+icon+'</icon><summary>'+descp+'</summary><status>'+stat+'</status>'
			Sources.append(source)
		c += 1
		num += 1
	pd.close()

	for url in np:
		#xbmc.log('url ##############################'+str(url),2)
		np_url = '<nextpage>nextsearchpage/'+url+'</nextpage>'
		Sources.append(np_url)
	return Sources
##########  NEW CODES FOR SEARCH POPULAR DRAMA TILL HERE   ########






##########  NEW CODES POPULAR DRAMA HERE   ########
def scrape_most_popular(url):
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	#xbmc.log('Scrape_most_popular ##############################'+str(url),2)
	pd = xbmcgui.DialogProgress()
	pd.create('Gathering Links Please Wait ...Dont Cancel')
	# #send_log(url,'URL')
	# #xbmc.log('scrape_scrape_details##############################'+str(url),2)
	Readit = requests.get(url,headers=headers)
	# #html = Readit.content
	# #html = html.decode('utf-8')
	html = Readit.text

	
	new_pop_url = re.compile(">We moved to <a style=.+?title=.+?href='(.+?)'>",re.DOTALL).findall(str(html))[0]
	#xbmc.log('new_pop_url ##############################'+str(new_pop_url),2)
	url_for_pop = new_pop_url.split('//')[1]

	

	np = re.findall('(?s)<li class=\'next\'><a href=\'(.+?)\'',html)
	#xbmc.log('url_np_block ##############################'+str(np),2)

	main_block = re.compile('<ul class=\"switch-block list-episode-item\"(.+?)</ul>',re.DOTALL).findall(html)
	# #url_main_block = re.compile('href="(.+?)" class="img"',re.DOTALL).findall(str(main_block))
	#url_main_block = re.compile('href="(.+?)" class="img".+?<img src=.+?data-original="(.+?)".+?<h3 class="title".+?>(.+?)</h3>',re.DOTALL).findall(str(main_block))
	url_main_block = re.compile('href="(.+?)" class="img"',re.DOTALL).findall(str(main_block))

	m = len(url_main_block)
	per = 100/m
	c=0
	num = 1

	Sources = []
	# #send_log(list_match,'MAINBLOCK OFW HTML')
	for url in url_main_block:
		#xbmc.log('url_main_block ##############################'+str(title),2)
		#xbmc.log('url_main_block ##############################'+str(url),2)
		#xbmc.log('url_main_block ##############################'+str(img),2)
		pd.update(int(c*per),message='[B][COLOR yellow]Getting Status \'{}\'[/COLOR][/B]'.format(url))		
		
	# 	#xbmc.log('scrape_scrape_details##############################'+str(url),2)
	# 	#new_url = "popkdlink/" + url
	# 	#xbmc.log('new_url ############################'+str(new_url),2)
		#pre_url = 'https://www1.dramacool.movie'+url
		pass_me = url_for_pop+url
		#xbmc.log('url_for_pop ##############################'+str(url_for_pop),2)
		new_details = scrape_kdrama_details_popular(pass_me)
		#xbmc.log('SCRAPE ##############################'+str(new_details),2)
		new_details_regex = r'<title>(.+?)</title><icon>(.+?)</icon><status>(.+?)</status><description>(.+?)</description>'
		regex_new_details = re.compile(new_details_regex,re.DOTALL).findall(str(new_details))
		for title,icon,stat,descp in regex_new_details:
			source = '<url>'+url+'</url><name>'+title+'</name><icon>'+icon+'</icon><summary>'+descp+'</summary><status>'+stat+'</status>'
			Sources.append(source)
		c += 1
		num += 1
	pd.close()

	for url in np:
	# 	#xbmc.log('url ##############################'+str(url),2)
		np_url = '<nextpage>nextpageppkd/'+url+'</nextpage>'
		Sources.append(np_url)
	return Sources
##########  NEW CODES POPULAR DRAMA TILL HERE   ########



#KDRAMA DESCRIPTION AND STATUS
def scrape_kdrama_details_popular(url):
	#xbmc.log('scrape_kdrama_details_popular ##############################'+str(url),2)
	import http.client
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	
	main = url.split("/", 1)[0]
	sub = '/'+url.split("/", 1)[1]
	#xbmc.log('main scrape_kdrama_details_popular ##############################'+str(main),2)
	#xbmc.log('sub scrape_kdrama_details_popular ##############################'+str(sub),2)


	
	conn = http.client.HTTPSConnection(main)
	conn.request("GET", sub, headers=headers)
	r1 = conn.getresponse()
	body = r1.read()
	#xbmc.log('body ##############################'+str(body),2)

	Sources = []

	main_block = re.compile('<div class="details">(.+?)<div class="slider-star">',re.DOTALL).findall(str(body))
	matches = re.compile('<div class="img">.+?<img src="(.+?)".+?<h1>(.+?)</h1>.+?<span>Description:</span>.+?<p>(.+?)</p>.+?<p><span>Status:</span>.+?">(.+?)</a>',re.DOTALL).findall(str(main_block))
	#xbmc.log('matchesr ##############################'+str(matches),2)

	for icon,title,description,status in matches:
		title = '<title>'+title+'</title>'
		status = '<status>'+status+'</status>'
		icon = '<icon>'+icon+'</icon>'
		description = '<description>'+description+'</description>'
		block_details = title+icon+status+description
		#xbmc.log('block_details ##############################################################'+str(block_details),2)
		Sources.append(block_details)
	conn.close()
	return Sources

def scrape_kdrama_details(url):
	#xbmc.log('scrape_kdrama_detailsURL ##############################################################'+str(url),2)
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.text
	Sources = []

	main_block = re.compile('<div class="details">(.+?)<div class="slider-star">',re.DOTALL).findall(str(html))
	#xbmc.log('scrape_kdrama_details ##############################'+str(main_block),2)
	matches = re.compile('<div class="img">.+?<img src="(.+?)".+?<h1>(.+?)</h1>.+?<span>Description:</span>.+?<p>(.+?)</p>.+?<p><span>Status:</span>.+?">(.+?)</a>',re.DOTALL).findall(str(main_block))

	for icon,title,description,status in matches:
		title = '<title>'+title+'</title>'
		status = '<status>'+status+'</status>'
		icon = '<icon>'+icon+'</icon>'
		description = '<description>'+description+'</description>'
		block_details = title+icon+status+description
		#xbmc.log('block_details ##############################################################'+str(block_details),2)
		Sources.append(block_details)
	#conn.close()
	return Sources	
	#xbmc.log('sources ##############################'+str(sources),2)
###### KDRAMA DESCRIPTION AND STATUS TILLL HERE #########



###### DISPLAY KDRAMA EPISODES ###########
def display_kdrama_episodes(url):
	#xbmc.log('display_kdrama_episodes ##############################################################'+str(url),2)
	readme = requests.get(url,headers=headers)
	html = readme.text
	#html = html.decode('utf-8')
	Sources = []
	main2 = re.compile('<div class="block tab-container">(.+?)</ul>',re.DOTALL).findall(html)
	matches2 = re.compile('(?s)href="(.+?)"(?:.+?)<span class="(?:.+?)">(.+?)</span>(?:.+?)<h3 class="title".+?>(.+?)</h3>',re.DOTALL).findall(str(main2))
	# xbmc.log('matches2 ##############################################################'+str(matches2),2)
	for url,rs,title in matches2:
		source = '<episodes_url>'+url+'</episodes_url><episodes_sub>'+rs+'</episodes_sub><episodes_num>'+title+'</episodes_num>'
		Sources.append(source)
	# xbmc.log('Sources ##############################################################'+str(Sources),2)
	return Sources
###### DISPLAY KDRAMA EPISODES TILL HERE ###########


###### GET KOREAN PLAY LINKS HERE ###########
def scrape_play_links(url):
	
	#xbmc.log('scrape_movie_links URLNOW ######################################################## '+str(url),2)
	#pd = xbmcgui.DialogProgress()
	#pd.create('Please Wait ...Dont Cancel')
	Sources = []
	#title_description = []

	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.text
	new_pop_url = re.compile(">We moved to <a style=.+?title=.+?href='(.+?)'>",re.DOTALL).findall(str(html))[0]
	xbmc.log('new_pop_url ##############################'+str(new_pop_url),2)

	#xbmc.log('details_me######################################################### '+str(new_url),2)
	#xbmc.log('details_me######################################################### '+str(details_me),2)
	
	get_categ_link_block = re.compile('<div class="category">.+?<span>Category:.+?<a href="(.+?)"',re.DOTALL).findall(html)[0]
	#new_url = 'https://www1.dramacool.movie'+ get_categ_link_block
	new_url = new_pop_url+ get_categ_link_block
	#xbmc.log('get_categ_link_block ######################################################### '+str(new_url),2)

	playlink_pass = '<playlink_pass>'+new_url+'</playlink_pass>'
	Sources.append(playlink_pass)

	main_block = re.compile('<div class="anime_muti_link"><ul>(.+?)</ul></div>',re.DOTALL).findall(html)
	matches = re.compile('<li class=".+?data-video="(.+?)">.+?<span>',re.DOTALL).findall(str(main_block))


	for url in matches:
		#xbmc.log('URLmatches######################################################### '+str(url),2)
		if 'https:' not in url:
			url = 'https:' + url
		if 'asianhdplay' in url:
			url = url.replace('asianhdplay', 'asianplay')

		source = '<url>'+url+'</url>'				
		#try:
		#	name = url.split('//')[1].replace('www.','')
		#	name = name.split('/')[0].split('.')[0].title()
		#except:pass
		#xbmc.log('URLNOW######################################################### '+str(url),2)
		#xbmc.log('NAMEURLNOW######################################################### '+str(name),2)
		Sources.append(source)	
	#sources.extend(title_description)
	return Sources
	#xbmc.log('return sources ######################################################### '+str(sources),2)
###### GET KOREAN PLAY LINKS TILL HERE ###########




####### GET BLOCK DETAILS FOR MOVIES EPISODE DRAMA ########
def scrape_movie_details(url):
	#pre_url = url
	#xbmc.log('scrape_movie_details URL ######################################################### '+str(url),2)
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}
	Readit = requests.get(url,headers=headers)
	html = Readit.text
	sources = []

	movie_drama_tab = r'<div class="block-tab">.+?<h1>(.+?)</h1>'
	regex_movie_drama_tab = re.compile(movie_drama_tab,re.DOTALL).findall(html)[0]
	#xbmc.log('regex_movie_drama_tab ######################################################### '+str(regex_movie_drama_tab),2)

	main_block = re.compile('<ul class=\"switch-block list-episode-item\"(.+?)</ul>',re.DOTALL).findall(html)
	#xbmc.log('main_block######################################################### '+str(main_block),2)
	url_main_block = re.compile('href="(.+?)" class="img".+?<img src=.+?data-original="(.+?)".+?<span class=.+?>(.+?)</span>.+?<h3 class="title".+?>(.+?)</h3>.+?<span class="ep.+?>(.+?)</span>',re.DOTALL).findall(str(main_block))
	#xbmc.log('url_main_block ######################################################### '+str(url_main_block),2)	
	for url,icon,sub,name,epnum in url_main_block:
	# 	Readit = requests.get(url,headers=headers)
	# 	html = Readit.text
		#descp_link = 'https://www1.dramacool.movie'+url
		#new_summ = scrape_movie_description(descp_link)
		

		summary = "CLICK FOR DETAILS"
		#if "Movie" in regex_movie_drama_tab:
		#	new_url = "movielink/" + url
		#elif "Drama" in regex_movie_drama_tab:
		#	new_url = 'nextrecentlypagekdrama/'+url
		#elif "Kshow" in regex_movie_drama_tab:
		#	new_url = 'nextrecentlypagekdrama/'+url
		#new_url = "movielink/" + url
		#title = title + ' ([COLOR yellow] STATUS: [/COLOR]' + '[COLOR red]'+status +'[/COLOR])'
		#xbmc.log('NEW_ URL ######################################################### '+str(url),2)
		#xbmc.log('NEW_ URL ######################################################### '+str(new_url),2)
		source = '<url>'+url+'</url><name>'+name+'</name><icon>'+icon+'</icon><summary>'+summary+'</summary><status>'+sub+'</status><epnum>'+epnum+'</epnum>'
		#xbmc.log('source ######################################################### '+str(source),2)
			
	# 	# 	# 	send_log(sources,'SOURCES')	

	
	# 	# #try:
	# 	# #	npblock = re.compile(np_block,re.DOTALL).findall(html)[0]
	# 	# #	url = '<nextpage>nextpage/'+npblock+'</nextpage>'
	# 	# #send_log(url,'NEXTPAGE URL')
	# 	# #	sources.append(url)
	# 	# #except:pass
		sources.append(source)
	# #	c += 1
	# #	num += 1
	# #pd.close()

	np = re.findall('(?s)<li class=\'next\'><a href=\'(.+?)\'',html)
	#xbmc.log('URLNOW######################################################### '+str(np),2)

	for url in np:
		#xbmc.log('URL regex TAB ######################################################### '+str(np),2)
		if "Movie" in regex_movie_drama_tab:
			nextpage_url = 'nextpagekmovie/'+url
		elif "Drama" in regex_movie_drama_tab:
			nextpage_url = 'nextrecentlypagekdrama/'+url
		elif "Kshow" in regex_movie_drama_tab:
			nextpage_url = 'nextrecentlykshow/'+url

		#xbmc.log('nextpage_url ######################################################### '+str(nextpage_url),2)
		holder_url = '<nextpage>'+nextpage_url+'</nextpage>'
		sources.append(holder_url)	
	return sources
####### GET BLOCK DETAILS FOR MOVIES EPISODE DRAMA TILL HERE ###########









