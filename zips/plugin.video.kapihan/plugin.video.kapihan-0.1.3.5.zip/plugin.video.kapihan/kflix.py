import xbmc ,xbmcgui ,xbmcplugin ,xbmcaddon #line:2
import re ,os ,urllib ,sys ,inspect ,requests #line:3
import resolveurl #line:7
import urllib .parse #line:10
headers ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}#line:13
addon_handle =int (sys .argv [1 ])#line:14
player =xbmc .Player ()#line:15
dialog =xbmcgui .Dialog ()#line:16
addon =xbmcaddon .Addon ('plugin.video.kapihan')#line:18
icon =addon .getAddonInfo ('icon')#line:19
addon_name =addon .getAddonInfo ('name')#line:20
Fanart =addon .getAddonInfo ('fanart')#line:22
addon_path =addon .getAddonInfo ('path')#line:24
Icons2 =addon_path +"/resources/icons/"#line:25
mainurl ='https://www1.dramacool.movie/most-popular-drama'#line:28
preurl ='https://www1.dramacool.movie/'#line:30
search =''#line:32
preurl2 ='https://www1.dramacool.movie/recently-added'#line:34
preurl3 ='https://www1.dramacool.movie'#line:35
xbmcplugin .setContent (int (sys .argv [1 ]),'tvshows')#line:37
from lib .pyairtable .api .table import Table #line:43
from lib .kepweng import popular as popular #line:44
from lib .kepweng import helpers as helpers #line:45
from lib .kepweng import pinoyflix as pinoyflix #line:46
from lib .kepweng import pinoyhdflix as pinoyhdflix #line:47
from lib .kepweng import pinoymoviepedia as pinoymoviepedia #line:48
from threading import Thread #line:50
def add_dir (dir_type ='',mode ='',url ='',title ='',iconimage ='',fanart ='',description =''):#line:58
	OO0O0O000OOOOOO0O =sys .argv [0 ]+"?mode="+str (mode )+"&iconimage="+urllib .parse .quote_plus (iconimage )+"&description="+urllib .parse .quote_plus (description )#line:59
	O0O000OOOOOOO00O0 =2 ;OOO0000000OOOOO00 =inspect .getfullargspec (add_dir );OO0000OO0O0OO00OO =len (OOO0000000OOOOO00 [0 ])#line:60
	while OO0000OO0O0OO00OO -2 >0 :#line:61
		OO0O0O000OOOOOO0O +="&"+OOO0000000OOOOO00 [0 ][O0O000OOOOOOO00O0 ]+"="+urllib .parse .quote_plus (locals ()[OOO0000000OOOOO00 [0 ][O0O000OOOOOOO00O0 ]])#line:62
		O0O000OOOOOOO00O0 +=1 ;OO0000OO0O0OO00OO -=1 #line:63
	O00OOO000O0OOO0O0 =xbmcgui .ListItem (title )#line:65
	O00OOO000O0OOO0O0 .setArt ({'poster':iconimage ,'thumb':iconimage })#line:68
	O00OOO000O0OOO0O0 .setInfo (type ="Video",infoLabels ={"Title":title ,"Plot":description })#line:69
	O00OOO000O0OOO0O0 .setProperty ("Fanart_Image",fanart )#line:71
	if dir_type !='':O00OOO0OOOOO0OO00 =True #line:72
	else :O00OOO0OOOOO0OO00 =False ;O00OOO000O0OOO0O0 .setProperty ("IsPlayable","true")#line:73
	OOOOOOO000O0O0OOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0O0O000OOOOOO0O ,listitem =O00OOO000O0OOO0O0 ,isFolder =O00OOO0OOOOO0OO00 )#line:74
	return OOOOOOO000O0O0OOO #line:75
def Get_Params ():#line:81
	OOOOOOO00OOOOOO00 =sys .argv [2 ]#line:82
	if len (OOOOOOO00OOOOOO00 )<=2 :return #line:83
	OO000O0000O000OO0 =re .split ('[?]',OOOOOOO00OOOOOO00 ,1 )#line:84
	OOO00O0OO0O00O0O0 ={}#line:85
	O0O00O00000000O0O =urllib .parse .parse_qs (OO000O0000O000OO0 [1 ])#line:86
	for OOOO0O00O0OO0O0OO in O0O00O00000000O0O :#line:87
		OO00OO0O0O0OO0OOO =''.join (O0O00O00000000O0O [OOOO0O00O0OO0O0OO ])#line:88
		OOO00O0OO0O00O0O0 .update ({OOOO0O00O0OO0O0OO :OO00OO0O0O0OO0OOO })#line:89
	return OOO00O0OO0O00O0O0 #line:90
def login ():#line:92
	OO00O00O00OO000OO ='patXWUzMfnS0V0w2v.da9b13b0c70937395e767e850cbb24a3f060645185e5ca98f2127829d4dec549'#line:94
	OO00OO0OOO0OO0OO0 =Table (OO00O00O00OO000OO ,'app4obSw6zHHqkJmS','My Own Links')#line:95
	OOOO0O0OO0000O000 =OO00OO0OOO0OO0OO0 .all ()#line:96
	OOO000OOO0000OO00 =r"'name': 'A1', 'urlsource': '(.+?)'"#line:98
	O00O00OO0O0O0O000 =r"'name': 'A2', 'urlsource': '(.+?)'"#line:99
	O00O0O0000OO0OO00 =re .compile (OOO000OOO0000OO00 ,re .DOTALL ).findall (str (OOOO0O0OO0000O000 ))[0 ]#line:101
	O00OOO00O0O00O000 =re .compile (O00O00OO0O0O0O000 ,re .DOTALL ).findall (str (OOOO0O0OO0000O000 ))[0 ]#line:103
	OO0000O0OO0000OOO =addon .getSetting ('Email User')#line:105
	OO00OO000000OO0OO =addon .getSetting ('Password')#line:106
	if OO0000O0OO0000OOO ==O00O0O0000OO0OO00 and OO00OO000000OO0OO ==O00OOO00O0O00O000 :#line:110
		MainMenu ()#line:112
	else :#line:114
		dialog .ok ('SORRY WRONG PASSWORD , PLEASE TRY AGAIN,THIS IS NOT FOR SALE','CONTACT THE ADMIN,CLICK OK TO CONTINUE CHANGE THE USERNAME PASSWORD IN THE SETTINGS')#line:115
		O00O0000O000O0O00 =None #line:116
		xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:118
		xbmc .executebuiltin ('Activatewindow(home)')#line:119
		addon .openSettings ('plugin.video.kflix')#line:120
headers ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}#line:122
read_pb =requests .get ('https://pastebin.com/raw/nuMVTUtA',verify =False ,headers =headers )#line:123
html_pb =read_pb .text #line:124
pb_regex =r'<ph_weekend>\("(.+?)","(.+?)","(.+?)"\)</ph_weekend>'#line:126
regex_pb_details =re .compile (pb_regex ,re .DOTALL ).findall (html_pb )#line:127
pb_regex2 =r'<ph_babad>\("(.+?)","(.+?)","(.+?)"\)</ph_babad>'#line:129
regex_pb_details2 =re .compile (pb_regex2 ,re .DOTALL ).findall (html_pb )#line:130
pb_regex3 =r'<k_babad>(.+?)</k_babad>'#line:132
KDRAMA_LINK =re .compile (pb_regex3 ,re .DOTALL ).findall (html_pb )[0 ]#line:133
pb_babad =r'<p_babad>(.+?)</p_babad>'#line:135
PINOYFLIXHD_LINK =re .compile (pb_babad ,re .DOTALL ).findall (html_pb )[0 ]#line:136
xbmc .log ('KDRAMA_LINK ##############################'+str (PINOYFLIXHD_LINK ),2 )#line:137
def MainMenu ():#line:139
	add_dir ('','','','[B][COLOR yellow]-= TAGALOG  MENU =-[/COLOR][/B]','',Fanart )#line:145
	add_dir ('f','scrape_latest_pages','pflix/','[B][COLOR white]LATEST TAGALOG DRAMA [COLOR orange](PINOYFLIX)[/COLOR][/B]','',Fanart )#line:147
	add_dir ('f','scrape_latest_pages','phdflix/','[B][COLOR white]LATEST TAGALOG DRAMA [COLOR orange](PINOY HD)[/COLOR][/B]','',Fanart )#line:148
	add_dir ('f','search_tagalog','','[B][COLOR white] SEARCH TAGALOG MOVIES HERE [COLOR orange](=^_^=)[/COLOR][/B]','',Fanart )#line:149
	add_dir ('f','scrape_latest_pages','ppedia/','[B][COLOR white]TAGALOG MOVIES[/COLOR][/B]','',Fanart )#line:150
	add_dir ('','','','[B][COLOR yellow]-= KDRAMA  MENU =-[/COLOR][/B]','',Fanart )#line:155
	add_dir ('f','searchme','','[B][COLOR lightcoral] SEARCH HERE ( )[/COLOR][/B]','',Fanart )#line:157
	add_dir ('f','scrape_kdrama_most_popular','popularkdrama/','[B][COLOR lightcoral]POPULAR KDRAMAS[/COLOR][/B]','',Fanart )#line:158
	add_dir ('f','scrape_klatest_pages','recentlyaddedmovie/','[B][COLOR lightcoral]RECENTLY ADDED MOVIES[/COLOR][/B]','',Fanart )#line:159
	add_dir ('f','scrape_klatest_pages','recentlydramaaddep/','[B][COLOR lightcoral]RECENTLY ADDED DRAMA EPISODES[/COLOR][/B]','',Fanart )#line:160
	add_dir ('f','scrape_klatest_pages','recentlyaddedkshow/','[B][COLOR lightcoral]RECENTLY ADDED KSHOWS[/COLOR][/B]','',Fanart )#line:161
	add_dir ('','','','[B][COLOR yellow]-= NEW TELESERYES BELOW =-[/COLOR][/B]','',Fanart )#line:165
	for OOOOO000O000OO00O ,O00OO0000000O0OO0 ,O0OOOOOOOOOO000OO in regex_pb_details2 :#line:169
		add_dir ('f','scrape_latest_pages',O00OO0000000O0OO0 ,'[B][COLOR pink]'+OOOOO000O000OO00O +'[/COLOR][/B]',O0OOOOOOOOOO000OO ,Fanart )#line:170
def scrape_pinoyflix_pages (OOOOO00OOO0000OO0 ):#line:196
	OOO0OOO0O0O0OO000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}#line:197
	O0O0O00000OOOO00O =requests .get (OOOOO00OOO0000OO0 ,headers =OOO0OOO0O0O0OO000 )#line:198
	O00OOOOO0OOOO0O0O =(O0O0O00000OOOO00O .text .encode ('ascii','ignore').decode ('ascii'))#line:200
	O0OO0000000000000 =re .compile ('<h2>Seasons and episodes</h2>(.+?)<h2>You May Also Like</h2>',re .DOTALL ).findall (O00OOOOO0OOOO0O0O )#line:201
	xbmc .log ('VOLTES V ##################################################################'+str (O0OO0000000000000 ),2 )#line:203
def scrape_latest_pages (O00O00O00O0000OO0 ):#line:210
	if "pflix/"in O00O00O00O0000OO0 :#line:213
		O00OO0O000O0OOOOO ='https://pinoysflix.su/'#line:216
		OO0O00OO0OOO0OO00 =pinoyflix .scrape_main (O00OO0O000O0OOOOO )#line:217
	if "nextpagepflix/"in O00O00O00O0000OO0 :#line:218
		O00OO0O000O0OOOOO =O00O00O00O0000OO0 .replace ('nextpagepflix/','')#line:221
		OO0O00OO0OOO0OO00 =pinoyflix .scrape_main (O00OO0O000O0OOOOO )#line:222
	if "[HDFLIX]"in O00O00O00O0000OO0 :#line:224
		O00O00O00O0000OO0 =O00O00O00O0000OO0 .replace ('[HDFLIX]','')#line:225
		OO0O00OO0OOO0OO00 =pinoyhdflix .scrape_main (O00O00O00O0000OO0 )#line:227
	if "[urduha]"in O00O00O00O0000OO0 :#line:228
		O00O00O00O0000OO0 =O00O00O00O0000OO0 .replace ('[urduha]','')#line:229
		OO0O00OO0OOO0OO00 =pinoyflix .scrape_main (O00O00O00O0000OO0 )#line:231
	if "[BQ]"in O00O00O00O0000OO0 :#line:232
		O00O00O00O0000OO0 =O00O00O00O0000OO0 .replace ('[BQ]','')#line:233
		OO0O00OO0OOO0OO00 =pinoyflix .scrape_main (O00O00O00O0000OO0 )#line:235
	if "[DL]"in O00O00O00O0000OO0 :#line:236
		O00O00O00O0000OO0 =O00O00O00O0000OO0 .replace ('[DL]','')#line:237
		OO0O00OO0OOO0OO00 =pinoyflix .scrape_main (O00O00O00O0000OO0 )#line:239
	if "[TIH]"in O00O00O00O0000OO0 :#line:240
		O00O00O00O0000OO0 =O00O00O00O0000OO0 .replace ('[TIH]','')#line:241
		OO0O00OO0OOO0OO00 =pinoyflix .scrape_main (O00O00O00O0000OO0 )#line:243
	if "[MCI]"in O00O00O00O0000OO0 :#line:244
		O00O00O00O0000OO0 =O00O00O00O0000OO0 .replace ('[MCI]','')#line:245
		OO0O00OO0OOO0OO00 =pinoyflix .scrape_main (O00O00O00O0000OO0 )#line:247
	if "[AKP]"in O00O00O00O0000OO0 :#line:248
		O00O00O00O0000OO0 =O00O00O00O0000OO0 .replace ('[AKP]','')#line:249
		OO0O00OO0OOO0OO00 =pinoyflix .scrape_main (O00O00O00O0000OO0 )#line:251
	if "[UA]"in O00O00O00O0000OO0 :#line:252
		O00O00O00O0000OO0 =O00O00O00O0000OO0 .replace ('[UA]','')#line:253
		OO0O00OO0OOO0OO00 =pinoyflix .scrape_main (O00O00O00O0000OO0 )#line:255
	if "[CHA]"in O00O00O00O0000OO0 :#line:256
		O00O00O00O0000OO0 =O00O00O00O0000OO0 .replace ('[CHA]','')#line:257
		OO0O00OO0OOO0OO00 =pinoyflix .scrape_main (O00O00O00O0000OO0 )#line:259
	if "[UH]"in O00O00O00O0000OO0 :#line:260
		O00O00O00O0000OO0 =O00O00O00O0000OO0 .replace ('[UH]','')#line:261
		OO0O00OO0OOO0OO00 =pinoyflix .scrape_main (O00O00O00O0000OO0 )#line:263
	if "[PBB]"in O00O00O00O0000OO0 :#line:264
		O00O00O00O0000OO0 =O00O00O00O0000OO0 .replace ('[PBB]','')#line:265
		OO0O00OO0OOO0OO00 =pinoyflix .scrape_main (O00O00O00O0000OO0 )#line:267
	if "phdflix/"in O00O00O00O0000OO0 :#line:268
		O00OO0O000O0OOOOO =PINOYFLIXHD_LINK #line:269
		OO0O00OO0OOO0OO00 =pinoyhdflix .scrape_main (O00OO0O000O0OOOOO )#line:270
	if "nextpagephdflix/"in O00O00O00O0000OO0 :#line:271
		O00O00O00O0000OO0 =O00O00O00O0000OO0 .replace ('nextpagephdflix/','')#line:272
		O00OO0O000O0OOOOO =O00O00O00O0000OO0 #line:273
		OO0O00OO0OOO0OO00 =pinoyhdflix .scrape_main (O00OO0O000O0OOOOO )#line:274
	if "ppedia/"in O00O00O00O0000OO0 :#line:275
		O00O00O00O0000OO0 ='https://pinoymoviepedia.ru/movies/'#line:276
		OO0O00OO0OOO0OO00 =pinoymoviepedia .scrape_main (O00O00O00O0000OO0 )#line:277
	if "nextpagedia/"in O00O00O00O0000OO0 :#line:278
		O00OO0O000O0OOOOO =O00O00O00O0000OO0 .replace ('nextpagedia/','')#line:281
		OO0O00OO0OOO0OO00 =pinoymoviepedia .scrape_main (O00OO0O000O0OOOOO )#line:284
	if "restored/"in O00O00O00O0000OO0 :#line:285
		O00OO0O000O0OOOOO ='https://pinoymoviepedia.ru/genre/digitally-restored/'#line:288
		OO0O00OO0OOO0OO00 =pinoymoviepedia .scrape_main (O00OO0O000O0OOOOO )#line:289
	else :#line:290
		pass #line:291
	try :#line:295
		OO0O0000OOOOOOOO0 =r'<name>(.+?)</name><icon>(.+?)</icon><url>(.+?)<url>'#line:299
		O0O0000000O0OO000 =re .compile (OO0O0000OOOOOOOO0 ,re .DOTALL ).findall (str (OO0O00OO0OOO0OO00 ))#line:300
		for OO0OOO0OOO00000OO ,O0O0OOO0OOO0OO000 ,O00O00O00O0000OO0 in O0O0000000O0OO000 :#line:301
			xbmc .log ('PHDNAME##################################################################'+str (OO0OOO0OOO00000OO ),2 )#line:302
			xbmc .log ('PHDURL##################################################################'+str (O00O00O00O0000OO0 ),2 )#line:303
			OO0OOO0OOO00000OO =OO0OOO0OOO00000OO .replace ('&#8217;','\'').replace ('&#8211;','-').replace ('&#39;','\'').replace ('&amp;#038;','&').replace ('\\\\xe2\\\\x80\\\\x99','\'')#line:304
			add_dir ('f','get_links',O00O00O00O0000OO0 ,'[B][COLOR white]'+OO0OOO0OOO00000OO +'[/COLOR][/B]',O0O0OOO0OOO0OO000 ,O0O0OOO0OOO0OO000 ,OO0OOO0OOO00000OO )#line:305
		OOOOOOOOOO00O00OO =r'<nextpage>(.+?)</nextpage>'#line:307
		OOO0O00O00O00O0O0 =re .compile (OOOOOOOOOO00O00OO ,re .DOTALL ).findall (str (OO0O00OO0OOO0OO00 ))#line:308
		for O00O00O00O0000OO0 in OOO0O00O00O00O0O0 :#line:309
			add_dir ('f','scrape_latest_pages',O00O00O00O0000OO0 ,'[B][COLOR red]NEXT PAGE[/COLOR][/B]')#line:310
		xbmc .executebuiltin ('Container.SetViewMode(512)')#line:312
	except :#line:313
		pass #line:314
def get_links (OO0OOOO0O0OO0O0OO ):#line:319
	if 'pinoyflixtv'in OO0OOOO0O0OO0O0OO :#line:322
		O0O0OO0O00O000000 =pinoyflix .scrape_links (OO0OOOO0O0OO0O0OO )#line:323
	if 'pinoyflixhd'in OO0OOOO0O0OO0O0OO :#line:324
		O0O0OO0O00O000000 =pinoyhdflix .scrape_links (OO0OOOO0O0OO0O0OO )#line:325
	if 'pinoymoviepedia.ru'in OO0OOOO0O0OO0O0OO :#line:327
		O0O0OO0O00O000000 =pinoymoviepedia .scrape_links (OO0OOOO0O0OO0O0OO )#line:328
	O00OOOO0OO0O00O00 =r'<url>(.+?)</url>'#line:330
	O0OOOO0000O0OOOO0 =re .compile (O00OOOO0OO0O00O00 ,re .DOTALL ).findall (str (O0O0OO0O00O000000 ))#line:331
	OO0OOOOO0OO000O00 =0 #line:334
	for OO0OOOO0O0OO0O0OO in O0OOOO0000O0OOOO0 :#line:336
		if 'http'not in OO0OOOO0O0OO0O0OO :#line:337
			OO0OOOO0O0OO0O0OO ='http:'+OO0OOOO0O0OO0O0OO #line:338
		try :#line:341
			if 'COMING SOON'in O0OOOO0000O0OOOO0 :#line:342
				OO0OOOOO0OO000O00 =OO0OOOOO0OO000O00 +1 #line:343
				add_dir ('','','','[B][COLOR yellow]COMING SOON CHECK BACK LATER[/COLOR][/B]','','','')#line:344
			else :#line:346
				if resolveurl .HostedMediaFile (OO0OOOO0O0OO0O0OO ).valid_url ():#line:347
					OO0OOOOO0OO000O00 =OO0OOOOO0OO000O00 +1 #line:348
					try :#line:349
						O0O0OOO0O00000O00 =OO0OOOO0O0OO0O0OO .split ('//')[1 ].replace ('www.','')#line:350
						O0O0OOO0O00000O00 =O0O0OOO0O00000O00 .split ('/')[0 ].split ('.')[0 ].title ()#line:351
					except :pass #line:352
					add_dir ('','dramacoolresolve',OO0OOOO0O0OO0O0OO ,'[B][COLOR yellow]'+O0O0OOO0O00000O00 +'[/COLOR][/B]',thumb ,'','')#line:353
		except :#line:360
			pass #line:361
	if OO0OOOOO0OO000O00 >0 :#line:365
		pass #line:366
	else :#line:367
		add_dir ('','','','[B][COLOR red]SORRY NO PLAYABLE LINK FOUND, PLS TRY OTHER SOURCES[/COLOR][/B]','','','')#line:368
def Display_Tagalog_Page (O0O0OOO0OOO00O000 ):#line:370
	O0OO0000OOOO0OO00 =pinoymoviepedia .scrape_search_page (O0O0OOO0OOO00O000 )#line:372
	OOOOOO00OO00OOOOO =r'<name>(.+?)</name><icon>(.+?)</icon><url>(.+?)<url><sum>(.+?)</summ>'#line:375
	OOOOOO00OO000O000 =re .compile (OOOOOO00OO00OOOOO ,re .DOTALL ).findall (str (O0OO0000OOOO0OO00 ))#line:376
	for OO00O00OOO0OOO0OO ,OO00OOO00O000OOO0 ,O0O0OOO0OOO00O000 ,OO0OOO00OOO0000O0 in OOOOOO00OO000O000 :#line:377
		OO00O00OOO0OOO0OO =OO00O00OOO0OOO0OO .replace ('&#8217;','\'').replace ('&#8211;','-').replace ('&#39;','\'').replace ('&amp;#038;','&').replace ('\\\\xe2\\\\x80\\\\x99','\'')#line:379
		add_dir ('f','get_links',O0O0OOO0OOO00O000 ,'[B][COLOR white]'+OO00O00OOO0OOO0OO +'[/COLOR][/B]',OO00OOO00O000OOO0 ,OO00OOO00O000OOO0 ,OO0OOO00OOO0000O0 )#line:380
	O0O0O0000OOOOO0OO =r'<nextpage>(.+?)</nextpage>'#line:382
	OOOOOO00O0O000OOO =re .compile (O0O0O0000OOOOO0OO ,re .DOTALL ).findall (str (O0OO0000OOOO0OO00 ))#line:383
	for O0O0OOO0OOO00O000 in OOOOOO00O0O000OOO :#line:385
		if "nextsearchpage/"in O0O0OOO0OOO00O000 :#line:386
			O0O0OOO0OOO00O000 =O0O0OOO0OOO00O000 .replace ('nextsearchpage/','')#line:387
		add_dir ('f','Display_Tagalog_Page',O0O0OOO0OOO00O000 ,'[B][COLOR red]NEXT PAGE[/COLOR][/B]')#line:391
def scrape_kdrama_most_popular (O0O00000O000O0O0O ):#line:400
	if "popularkdrama/"in O0O00000O000O0O0O :#line:403
		OO000O0O00OO0OOOO ='https://www1.dramacool.movie/most-popular-drama'#line:405
		O0OOO0OO00O0OO0OO =popular .scrape_most_popular (OO000O0O00OO0OOOO )#line:406
	elif "nextpageppkd/"in O0O00000O000O0O0O :#line:408
		OO000O0O00OO0OOOO =O0O00000O000O0O0O .replace ('nextpageppkd/','https://www1.dramacool.movie/most-popular-drama')#line:411
		O0OOO0OO00O0OO0OO =popular .scrape_most_popular (OO000O0O00OO0OOOO )#line:412
	else :#line:413
		pass #line:414
	try :#line:419
		O0O00000O0O0OOO00 =r'<url>(.+?)</url><name>(.+?)</name><icon>(.+?)</icon><summary>(.+?)</summary><status>(.+?)</status>'#line:423
		OOOOO0O00OO0O0O00 =re .compile (O0O00000O0O0OOO00 ,re .DOTALL ).findall (str (O0OOO0OO00O0OO0OO ))#line:424
		for O0O00000O000O0O0O ,O00O00OO0O000OOOO ,O0OOOO0O000OO00OO ,O000O000O0OOO0OO0 ,OO0OO00O00OOO000O in OOOOO0O00OO0O0O00 :#line:425
			O00O00OO0O000OOOO =O00O00OO0O000OOOO .replace ('&#8217;','\'').replace ('&#8211;','-').replace ('&#39;','\'').replace ('&amp;#038;','&').replace ('\\\\xe2\\\\x80\\\\x99','\'')#line:427
			if "nostat/"in OO0OO00O00OOO000O :#line:428
				OO00O0OO00O0O000O =O00O00OO0O000OOOO #line:429
			else :#line:430
				OO00O0OO00O0O000O =O00O00OO0O000OOOO +' ([COLOR yellow] STATUS: [/COLOR]'+'[COLOR red]'+OO0OO00O00OOO000O +'[/COLOR])'#line:431
			add_dir ('f','get_k_episodes',O0O00000O000O0O0O ,'[B][COLOR white]'+OO00O0OO00O0O000O +'[/COLOR][/B]',O0OOOO0O000OO00OO ,O0OOOO0O000OO00OO ,O000O000O0OOO0OO0 )#line:432
		OO00OO000O000O000 =r'<nextpage>(.+?)</nextpage>'#line:434
		OO0OO00O0OOOOO000 =re .compile (OO00OO000O000O000 ,re .DOTALL ).findall (str (O0OOO0OO00O0OO0OO ))#line:435
		for O0O00000O000O0O0O in OO0OO00O0OOOOO000 :#line:436
			add_dir ('f','scrape_kdrama_most_popular',O0O00000O000O0O0O ,'[B][COLOR red]NEXT PAGE[/COLOR][/B]')#line:437
		xbmc .executebuiltin ('Container.SetViewMode(512)')#line:439
	except :#line:440
		pass #line:441
def get_recently_episodes (OOO00O0O0OOO00OO0 ):#line:450
	OOO0OOOOOOO0000OO ='https://www1.dramacool.cr'+OOO00O0O0OOO00OO0 #line:454
	O000OO00000O00O0O =popular .scrape_play_links (OOO0OOOOOOO0000OO )#line:455
	OO00OOOO00OO00O0O =r'<playlink_pass>(.+?)</playlink_pass>'#line:457
	O0O00O0O000OOO000 =re .compile (OO00OOOO00OO00O0O ,re .DOTALL ).findall (str (O000OO00000O00O0O ))[0 ]#line:458
	O0O0OOOO000O0O0O0 =popular .scrape_kdrama_details (O0O00O0O000OOO000 )#line:461
	O0OO0O000OO0O0OO0 =r'<title>(.+?)</title><icon>(.+?)</icon><status>(.+?)</status><description>(.+?)</description>'#line:463
	OO0O0O0O0O000OOO0 =re .compile (O0OO0O000OO0O0OO0 ,re .DOTALL ).findall (str (O0O0OOOO000O0O0O0 ))#line:464
	for O00O0OOO000OOO0OO ,OO00OOOOO0OO000OO ,OO00000O0O00OOOO0 ,O00O0OO0O0OO0O0O0 in OO0O0O0O0O000OOO0 :#line:469
		O00OO0O0O0O00OOOO =OO00OOOOO0OO000OO #line:470
		O0OOO0O0000OOOOO0 =OO00000O0O00OOOO0 #line:471
		O00OOO0O00000OO0O =O00O0OO0O0OO0O0O0 #line:472
		add_dir ('','','','[B][COLOR yellow]'+O0OOO0O0000OOOOO0 +'[/COLOR]'+' '+'[COLOR white]'+O00O0OOO000OOO0OO +'[/COLOR][/B]',O00OO0O0O0O00OOOO ,O00OO0O0O0O00OOOO ,O00OOO0O00000OO0O )#line:473
	add_dir ('f','displaycast',O0O00O0O000OOO000 ,'[B][COLOR yellow]= DISPLAY CAST SHOWS =[/COLOR][/B]',O00OO0O0O0O00OOOO ,O00OO0O0O0O00OOOO ,O00OOO0O00000OO0O )#line:475
	add_dir ('','','','[B][COLOR white]= CHOOSE EPISODES BELOW =[/COLOR][/B]',O00OO0O0O0O00OOOO ,O00OO0O0O0O00OOOO ,O00OOO0O00000OO0O )#line:477
	OOOO0OO0OO0O00000 =popular .display_kdrama_episodes (OOO0OOOOOOO0000OO )#line:479
	O0OOOOO0O00OO0O00 =r'<episodes_url>(.+?)</episodes_url><episodes_sub>(.+?)</episodes_sub><episodes_num>(.+?)</episodes_num>'#line:480
	O0O00O0OO00OOO00O =re .compile (O0OOOOO0O00OO0O00 ,re .DOTALL ).findall (str (OOOO0OO0OO0O00000 ))#line:481
	for OOO00O0O0OOO00OO0 ,OO0000O00O0O0O00O ,OO0000000O0000OO0 in O0O00O0OO00OOO00O :#line:482
		OOO0OOOOOOO0000OO ='https://www1.dramacool.movie'+OOO00O0O0OOO00OO0 #line:483
		OO000OO0OOOOOO00O ='[B][COLOR yellow]'+OO0000O00O0O0O00O +'[/COLOR]'+' '+'[COLOR white]'+OO0000000O0000OO0 +'[/COLOR][/B]'#line:486
		add_dir ('f','get_klinks',OOO0OOOOOOO0000OO ,OO000OO0OOOOOO00O ,O00OO0O0O0O00OOOO ,O00OO0O0O0O00OOOO ,O00OOO0O00000OO0O )#line:487
	xbmc .executebuiltin ('Container.SetViewMode(512)')#line:489
def get_k_episodes (O00OO0OOO0O0OOOO0 ):#line:502
	OO00O00O0OOOOOO0O ='https://www1.dramacool.movie'+O00OO0OOO0O0OOOO0 #line:505
	OO000O0O00O000O00 =popular .display_kdrama_episodes (OO00O00O0OOOOOO0O )#line:507
	OOOO0OO0O0O0O0O0O =popular .scrape_kdrama_details (OO00O00O0OOOOOO0O )#line:509
	O000O00O00O000OOO =r'<status>(.+?)</status>'#line:512
	O0OOO00000O00OOOO =re .compile (O000O00O00O000OOO ,re .DOTALL ).findall (str (OOOO0OO0O0O0O0O0O ))#line:513
	if "Upcoming"in O0OOO00000O00OOOO :#line:515
		add_dir ('','','','[B][COLOR yellow]COMING SOON[/COLOR][/B]')#line:516
	else :#line:517
		try :#line:518
			OO00O0O0O0OO0O0O0 =r'<title>(.+?)</title><icon>(.+?)</icon><status>(.+?)</status><description>(.+?)</description>'#line:519
			OO000O000OO000000 =re .compile (OO00O0O0O0OO0O0O0 ,re .DOTALL ).findall (str (OOOO0OO0O0O0O0O0O ))#line:520
			for O0OOO000O00OOOOO0 ,OOO0OOO00O0OO000O ,O00O000O00O0O00OO ,OO0OOOO0O00O0OOOO in OO000O000OO000000 :#line:521
				O0000O0OO0OOO0O0O =OOO0OOO00O0OO000O #line:522
				O0OO0O00OOO000O00 =O00O000O00O0O00OO #line:523
				O0O0OOOOO00O0O0O0 =OO0OOOO0O00O0OOOO #line:524
				add_dir ('','','','[B][COLOR yellow]'+O0OO0O00OOO000O00 +'[/COLOR]'+' '+'[COLOR white]'+O0OOO000O00OOOOO0 +'[/COLOR][/B]',O0000O0OO0OOO0O0O ,O0000O0OO0OOO0O0O ,O0O0OOOOO00O0O0O0 )#line:525
			add_dir ('f','displaycast',OO00O00O0OOOOOO0O ,'[B][COLOR yellow]= DISPLAY CAST SHOWS =[/COLOR][/B]',O0000O0OO0OOO0O0O ,O0000O0OO0OOO0O0O ,O0O0OOOOO00O0O0O0 )#line:527
			add_dir ('','','','[B][COLOR white]= CHOOSE EPISODES BELOW =[/COLOR][/B]',O0000O0OO0OOO0O0O ,O0000O0OO0OOO0O0O ,O0O0OOOOO00O0O0O0 )#line:529
			OOO0O0O0OOOO00O0O =r'<episodes_url>(.+?)</episodes_url><episodes_sub>(.+?)</episodes_sub><episodes_num>(.+?)</episodes_num>'#line:532
			O0OO00000OOOOOOO0 =re .compile (OOO0O0O0OOOO00O0O ,re .DOTALL ).findall (str (OO000O0O00O000O00 ))#line:533
			for O00OO0OOO0O0OOOO0 ,O000O000O0O0O00OO ,O0O0000OOO00OO0O0 in O0OO00000OOOOOOO0 :#line:535
				OO00O00O0OOOOOO0O ='https://www1.dramacool.movie'+O00OO0OOO0O0OOOO0 #line:536
				OOOOO00O0OOOOO0OO ='[B][COLOR yellow]'+O000O000O0O0O00OO +'[/COLOR]'+' '+'[COLOR white]'+O0O0000OOO00OO0O0 +'[/COLOR][/B]'#line:539
				add_dir ('f','get_klinks',OO00O00O0OOOOOO0O ,OOOOO00O0OOOOO0OO ,O0000O0OO0OOO0O0O ,O0000O0OO0OOO0O0O ,O0O0OOOOO00O0O0O0 )#line:540
			xbmc .executebuiltin ('Container.SetViewMode(512)')#line:541
		except :#line:542
			pass #line:543
def get_klinks (OO00OOO0O0O0OOOO0 ):#line:551
	O00O0OOO000O0OO0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}#line:553
	OO00OO00O0O000O0O =requests .get (OO00OOO0O0O0OOOO0 ,headers =O00O0OOO000O0OO0O )#line:554
	OO0OOO0OOOOOO00OO =OO00OO00O0O000O0O .text #line:555
	OO000O0O0O0O0O0O0 =re .compile (">We moved to <a style=.+?title=.+?href='(.+?)'>",re .DOTALL ).findall (str (OO0OOO0OOOOOO00OO ))[0 ]#line:557
	OO0O000OO0O0O00O0 =r'<option  selected  value=.+?>(.+?)</option>'#line:560
	O00O0OO00O000O000 =re .compile (OO0O000OO0O0O00O0 ,re .DOTALL ).findall (OO0OOO0OOOOOO00OO )[0 ]#line:561
	O0000OOO0OO0O0O00 =popular .scrape_play_links (OO00OOO0O0O0OOOO0 )#line:566
	O0OOO00OO0O0O00OO =r'<playlink_pass>(.+?)</playlink_pass>'#line:568
	OOOOOOOOO00O0OO0O =re .compile (O0OOO00OO0O0O00OO ,re .DOTALL ).findall (str (O0000OOO0OO0O0O00 ))[0 ]#line:569
	OO0000O0OOOOO0000 =popular .scrape_kdrama_details (OOOOOOOOO00O0OO0O )#line:571
	OO000OO00O0OO000O =r'<title>(.+?)</title><icon>(.+?)</icon><status>(.+?)</status><description>(.+?)</description>'#line:574
	OOO00000O00O0000O =re .compile (OO000OO00O0OO000O ,re .DOTALL ).findall (str (OO0000O0OOOOO0000 ))#line:575
	for O000O0000O0O0O00O ,OO00O0O0OOO00O000 ,O000O0OO0OOO00O00 ,O0OO0O00OOOOOOO00 in OOO00000O00O0000O :#line:576
		OOO00O0O0O0000O0O =OO00O0O0OOO00O000 #line:577
		OOOOO00O0OO0OOO00 =O000O0OO0OOO00O00 #line:578
		O00OO00O0O00O00O0 =O0OO0O00OOOOOOO00 #line:579
		add_dir ('','','','[B][COLOR yellow]'+OOOOO00O0OO0OOO00 +'[/COLOR]'+' '+'[COLOR white]'+O000O0000O0O0O00O +'[/COLOR][/B]',OOO00O0O0O0000O0O ,OOO00O0O0O0000O0O ,O00OO00O0O00O00O0 )#line:580
	add_dir ('','','','[B][COLOR white]PLAYING = [COLOR yellow] '+O00O0OO00O000O000 +' [/COLOR][/B]',OOO00O0O0O0000O0O ,OOO00O0O0O0000O0O ,O00OO00O0O00O00O0 )#line:583
	add_dir ('','','','[B][COLOR white]= CHOOSE PLAY LINKS BELOW =[/COLOR][/B]',OOO00O0O0O0000O0O ,OOO00O0O0O0000O0O ,O00OO00O0O00O00O0 )#line:584
	OO000OO0OOOO0000O =r'<url>(.+?)</url>'#line:594
	O00OOOO00O0OOOO00 =re .compile (OO000OO0OOOO0000O ,re .DOTALL ).findall (str (O0000OOO0OO0O0O00 ))#line:595
	O00OOO0OOO0OOO00O =0 #line:608
	for OOOO0O0000O0000OO in O00OOOO00O0OOOO00 :#line:614
		if 'http'not in OOOO0O0000O0000OO :#line:615
			OOOO0O0000O0000OO ='http:'+OOOO0O0000O0000OO #line:617
		try :#line:620
			if 'COMING SOON'in O00OOOO00O0OOOO00 :#line:621
				O00OOO0OOO0OOO00O =O00OOO0OOO0OOO00O +1 #line:622
				add_dir ('','','','[B][COLOR yellow]COMING SOON CHECK BACK LATER[/COLOR][/B]','','','')#line:623
			else :#line:625
				if resolveurl .HostedMediaFile (OOOO0O0000O0000OO ).valid_url ():#line:626
					O00OOO0OOO0OOO00O =O00OOO0OOO0OOO00O +1 #line:627
					try :#line:628
						OOO00O00OO00OO00O =OOOO0O0000O0000OO .split ('//')[1 ].replace ('www.','')#line:629
						OOO00O00OO00OO00O =OOO00O00OO00OO00O .split ('/')[0 ].split ('.')[0 ].title ()#line:630
					except :pass #line:631
					add_dir ('','dramacoolresolve',OOOO0O0000O0000OO ,'[B][COLOR yellow]'+OOO00O00OO00OO00O +'[/COLOR][/B]',OOO00O0O0O0000O0O ,OOO00O0O0O0000O0O ,O00OO00O0O00O00O0 )#line:632
		except :#line:639
			pass #line:640
	if O00OOO0OOO0OOO00O >0 :#line:644
		pass #line:645
	else :#line:646
		add_dir ('','','','[B][COLOR red]SORRY NO PLAYABLE LINK FOUND, PLS TRY OTHER SOURCES[/COLOR][/B]','','','')#line:647
	add_dir ('','','','[B][COLOR red]CHOOSE EPISODES BELOW[/COLOR][/B]','','','')#line:648
	OO0OO0OO0O000OOO0 =popular .display_kdrama_episodes (OO00OOO0O0O0OOOO0 )#line:650
	OOO0O0O0OO000O000 =r'<episodes_url>(.+?)</episodes_url><episodes_sub>(.+?)</episodes_sub><episodes_num>(.+?)</episodes_num>'#line:652
	OOO0O0O0O000000O0 =re .compile (OOO0O0O0OO000O000 ,re .DOTALL ).findall (str (OO0OO0OO0O000OOO0 ))#line:653
	for OO00OOO0O0O0OOOO0 ,O00OO00O0O0OOOO0O ,OO0O000OO0O0O00O0 in OOO0O0O0O000000O0 :#line:655
		OOOO0OO00O00OO0OO ='https://www1.dramacool.movie'+OO00OOO0O0O0OOOO0 #line:656
		OOOO0OO0O000O000O ='[B][COLOR yellow]'+O00OO00O0O0OOOO0O +'[/COLOR]'+' '+'[COLOR white]'+OO0O000OO0O0O00O0 +'[/COLOR][/B]'#line:659
		add_dir ('f','get_klinks',OOOO0OO00O00OO0OO ,OOOO0OO0O000O000O ,OOO00O0O0O0000O0O ,OOO00O0O0O0000O0O ,O00OO00O0O00O00O0 )#line:660
def scrape_klatest_pages (OOOOO00000O0O0O0O ):#line:670
	if "recentlyaddedmovie/"in OOOOO00000O0O0O0O :#line:673
		OOO0OO00O0O0OO0OO ='https://www1.dramacool.cr/recently-added-movie'#line:676
		O0O0000OO00O000O0 =popular .scrape_movie_details (OOO0OO00O0O0OO0OO )#line:677
	if "nextpagekmovie/"in OOOOO00000O0O0O0O :#line:679
		OOOOO00000O0O0O0O =OOOOO00000O0O0O0O .replace ('nextpagekmovie/','')#line:680
		OOO0OO00O0O0OO0OO ='https://www1.dramacool.cr/recently-added-movie'+OOOOO00000O0O0O0O #line:681
		O0O0000OO00O000O0 =popular .scrape_movie_details (OOO0OO00O0O0OO0OO )#line:682
	if "recentlydramaaddep/"in OOOOO00000O0O0O0O :#line:683
		OOO0OO00O0O0OO0OO ='https://www1.dramacool.cr/recently-added'#line:686
		O0O0000OO00O000O0 =popular .scrape_movie_details (OOO0OO00O0O0OO0OO )#line:688
	if "nextrecentlypagekdrama/"in OOOOO00000O0O0O0O :#line:689
		OOOOO00000O0O0O0O =OOOOO00000O0O0O0O .replace ('nextrecentlypagekdrama/','')#line:690
		OOO0OO00O0O0OO0OO ='https://www1.dramacool.cr/recently-added'+OOOOO00000O0O0O0O #line:692
		O0O0000OO00O000O0 =popular .scrape_movie_details (OOO0OO00O0O0OO0OO )#line:693
	if "recentlyaddedkshow/"in OOOOO00000O0O0O0O :#line:694
		OOO0OO00O0O0OO0OO ='https://www1.dramacool.cr/recently-added-kshow'#line:697
		O0O0000OO00O000O0 =popular .scrape_movie_details (OOO0OO00O0O0OO0OO )#line:698
	if "nextrecentlykshow/"in OOOOO00000O0O0O0O :#line:699
		OOOOO00000O0O0O0O =OOOOO00000O0O0O0O .replace ('nextrecentlykshow/','')#line:700
		OOO0OO00O0O0OO0OO ='https://www1.dramacool.cr/recently-added-kshow'+OOOOO00000O0O0O0O #line:702
		O0O0000OO00O000O0 =popular .scrape_movie_details (OOO0OO00O0O0OO0OO )#line:704
	else :#line:705
		pass #line:706
	try :#line:709
		O0O00O0OOO0000000 =r'<url>(.+?)</url><name>(.+?)</name><icon>(.+?)</icon><summary>(.+?)</summary><status>(.+?)</status><epnum>(.+?)</epnum>'#line:714
		OO0O0OO00000OO0OO =re .compile (O0O00O0OOO0000000 ,re .DOTALL ).findall (str (O0O0000OO00O000O0 ))#line:715
		for OOOOO00000O0O0O0O ,O0OOO00O0OOO0O0OO ,OOO0O0O00O000O000 ,O0OO0O0OOO0OO0O00 ,O000OO00OOOOOOOO0 ,O0OO0O00O000O0O00 in OO0O0OO00000OO0OO :#line:717
			O0OOO00O0OOO0O0OO =O0OOO00O0OOO0O0OO .replace ('&#8217;','\'').replace ('&#8211;','-').replace ('&#39;','\'').replace ('&amp;#038;','&').replace ('\\\\xe2\\\\x80\\\\x99','\'')#line:719
			if "RAW"in O000OO00OOOOOOOO0 :#line:721
				O000OO00OOOOOOOO0 ='[B][COLOR red]'+O000OO00OOOOOOOO0 +'[/COLOR]'#line:722
			else :#line:723
				O000OO00OOOOOOOO0 ='[B][COLOR yellow]'+O000OO00OOOOOOOO0 +'[/COLOR]'#line:724
			if "nostat/"in O000OO00OOOOOOOO0 :#line:725
				OOOOO0000O0OO00OO =O0OOO00O0OOO0O0OO #line:726
			else :#line:727
				OOOOO0000O0OO00OO =O000OO00OOOOOOOO0 +' '+'[COLOR blue]'+O0OO0O00O000O0O00 +'[/COLOR]'+' '+O0OOO00O0OOO0O0OO #line:729
			if "RAW"in O000OO00OOOOOOOO0 :#line:731
				continue #line:732
			else :#line:733
				add_dir ('f','get_recently_episodes',OOOOO00000O0O0O0O ,'[B][COLOR white]'+OOOOO0000O0OO00OO +'[/COLOR][/B]',OOO0O0O00O000O000 ,OOO0O0O00O000O000 ,O0OO0O0OOO0OO0O00 )#line:734
		O0O00OO0O00000OOO =r'<nextpage>(.+?)</nextpage>'#line:736
		OO0OOO000O000O000 =re .compile (O0O00OO0O00000OOO ,re .DOTALL ).findall (str (O0O0000OO00O000O0 ))#line:737
		for OOOOO00000O0O0O0O in OO0OOO000O000O000 :#line:738
			add_dir ('f','scrape_klatest_pages',OOOOO00000O0O0O0O ,'[B][COLOR red]NEXT PAGE[/COLOR][/B]')#line:739
		xbmc .executebuiltin ('Container.SetViewMode(512)')#line:741
	except :#line:742
		pass #line:743
def replace_unicode (O00O00O00O0O000O0 ):#line:799
	O00O00O00O0O000O0 =O00O00O00O0O000O0 .replace ('&#7424;','A').replace ('&#665;','B').replace ('&#7428;','C').replace ('&#7429;','D').replace ('&#7431;','E').replace ('&#1171;','F').replace ('&#610;','G').replace ('&#668;','H').replace ('&#618;','I').replace ('&#7434;','J').replace ('&#7435;','K').replace ('&#671;','L').replace ('&#7437;','M').replace ('&#628;','N').replace ('&#7439;','O').replace ('&#7448;','P').replace ('&#42927;','Q').replace ('&#640;','R').replace ('&#42801;','S').replace ('&#7451;','T').replace ('&#7452;','U').replace ('&#7456;','V').replace ('&#7457;','W').replace ('&#120;','X').replace ('&#655;','Y').replace ('&#7458;','Z').replace ('&#8217;','\'')#line:801
	return O00O00O00O0O000O0 #line:802
def Play (OOO0OO0OO0O00O0OO ):#line:935
	try :#line:936
		OO00O0OO00O0O00OO =str (OOO0OO0OO0O00O0OO )+'|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0'#line:938
		OOO0OO0OO0O00O0OO ='https://rr4---sn-uxax3vh50nugp5-8pxy.googlevideo.com/videoplayback?expire=1677869068&ei=jM8BZL7EI4aCvPIPn9Wd0AQ&ip=2604:a00:3:2098:216:3eff:fe26:1a29&id=cec69285a31eb2b2&itag=18&source=blogger&susc=bl&eaua=AGNlHydycE4&mime=video/mp4&vprv=1&dur=1641.999&lmt=1677776601304503&txp=1311224&sparams=expire,ei,ip,id,itag,source,susc,eaua,mime,vprv,dur,lmt&sig=AOq0QJ8wRgIhAM84op5V7v67aaBLLnwbdxIuNZJvM6KLCiFDOmyZysWfAiEAsXKZO3eOuWXE9tKaUnEue2OI2S9DHAMBg9Bp5HoBp_U=&redirect_counter=1&rm=sn-ab5el676&req_id=e54a3268abeba3ee&cms_redirect=yes&ipbypass=yes&mh=1E&mip=2001:871:265:857e:6595:affe:b66e:b269&mm=31&mn=sn-uxax3vh50nugp5-8pxy&ms=au&mt=1677839834&mv=m&mvi=4&pl=48&lsparams=ipbypass,mh,mip,mm,mn,ms,mv,mvi,pl&lsig=AG3C_xAwRQIhANTn18P1EWeKTvhNkLP2_ndJoqG6WqJY3BbiVathOOO1AiAKMrlaul6XUXDTk1ad1H_Qd3HbgM0zTg0_VOkZXKaydQ%3D%3D|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0&Referer=https://play.vkhost.xyz/'#line:939
		O0O000O00OOOOO0O0 =xbmcgui .ListItem (title )#line:941
		O0O000O00OOOOO0O0 .setArt ({'poster':thumb ,'thumb':thumb })#line:943
		O0O000O00OOOOO0O0 .setInfo (type ='Video',infoLabels ={'Title':title })#line:944
		O0O000O00OOOOO0O0 .setPath (OOO0OO0OO0O00O0OO )#line:945
		xbmcplugin .setResolvedUrl (int (sys .argv [1 ]),True ,O0O000O00OOOOO0O0 )#line:946
	except :#line:948
		OOO0O0O0OOO0OOOO0 =resolveurl .resolve (OOO0OO0OO0O00O0OO )#line:949
		O0O000O00OOOOO0O0 =xbmcgui .ListItem (title )#line:950
		O0O000O00OOOOO0O0 .setArt ({'poster':thumb ,'thumb':thumb })#line:952
		O0O000O00OOOOO0O0 .setInfo (type ='Video',infoLabels ={'Title':title })#line:953
		O0O000O00OOOOO0O0 .setPath (OOO0O0O0OOO0OOOO0 )#line:954
		xbmc .executebuiltin ("Dialog.Close(busydialog)")#line:959
		try :#line:965
			xbmcplugin .setResolvedUrl (int (sys .argv [1 ]),True ,O0O000O00OOOOO0O0 )#line:967
		except :#line:968
			pass #line:969
			xbmc .executebuiltin ("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)")#line:970
	for OOO000OO00OOOOO0O in range (0 ,120 ):#line:973
		if player .isPlayingVideo ():#line:974
			xbmcgui .Dialog ().notification (addon_name +' is provided by:','Team Kepweng',Icons2 +'icon2.png',10000 ,False )#line:975
			break #line:976
		xbmc .sleep (1000 )#line:977
	while player .isPlaying ():#line:978
		xbmc .sleep (2000 )#line:979
	xbmc .sleep (4000 )#line:980
def Search_Tagalog ():#line:984
	if 'seryes/'in OO00O00O00O0OO0O0 :#line:985
		OO00000O0OO0O0OO0 =xbmc .Keyboard ('','Search')#line:986
		OO00000O0OO0O0OO0 .doModal ()#line:987
		if (OO00000O0OO0O0OO0 .isConfirmed ()):#line:988
			OOO0O00OO0OO0O0OO =OO00000O0OO0O0OO0 .getText ().replace (' ','+')#line:989
			OO00O00O00O0OO0O0 ='https://pinoymoviepedia.ru/?s='+OOO0O00OO0OO0O0OO #line:990
		Display_Tagalog_Page (OO00O00O00O0OO0O0 )#line:993
	else :#line:995
		OO00000O0OO0O0OO0 =xbmc .Keyboard ('','Search')#line:996
		OO00000O0OO0O0OO0 .doModal ()#line:997
		if (OO00000O0OO0O0OO0 .isConfirmed ()):#line:998
			OOO0O00OO0OO0O0OO =OO00000O0OO0O0OO0 .getText ().replace (' ','+')#line:999
			OO00O00O00O0OO0O0 ='https://pinoymoviepedia.ru/?s='+OOO0O00OO0OO0O0OO #line:1000
		Display_Tagalog_Page (OO00O00O00O0OO0O0 )#line:1001
def Searchme ():#line:1003
	OO0O0OOOO0OOO0OO0 =xbmc .Keyboard ('','Search')#line:1004
	OO0O0OOOO0OOO0OO0 .doModal ()#line:1005
	if (OO0O0OOOO0OOO0OO0 .isConfirmed ()):#line:1006
		OOO00O0000000O00O =OO0O0OOOO0OOO0OO0 .getText ().replace (' ','+')#line:1007
		OOO0OOO0OO00OOO00 ='https://www1.dramacool.movie/search?type=movies&keyword='+OOO00O0000000O00O #line:1008
	Displaypage (OOO0OOO0OO00OOO00 )#line:1011
def Displaypage (O0O0O000O00O0OOO0 ):#line:1015
	O000OOO0O000O0OOO =popular .scrape_search_most_popular (O0O0O000O00O0OOO0 )#line:1017
	OO0O0000OOO000OOO =r'<url>(.+?)</url><name>(.+?)</name><icon>(.+?)</icon><summary>(.+?)</summary><status>(.+?)</status>'#line:1019
	OO00OOO00O00000OO =re .compile (OO0O0000OOO000OOO ,re .DOTALL ).findall (str (O000OOO0O000O0OOO ))#line:1020
	for O0O0O000O00O0OOO0 ,OOOOOOO00OOOOOOOO ,O00OO000O00OO000O ,O0000000OO0OOO0O0 ,OO00OO0O00O0O00O0 in OO00OOO00O00000OO :#line:1021
		OOOOOOO00OOOOOOOO =OOOOOOO00OOOOOOOO .replace ('&#8217;','\'').replace ('&#8211;','-').replace ('&#39;','\'').replace ('&amp;#038;','&').replace ('\\\\xe2\\\\x80\\\\x99','\'')#line:1023
		if "nostat/"in OO00OO0O00O0O00O0 :#line:1024
			O000OOOO000O0OOO0 =OOOOOOO00OOOOOOOO #line:1025
		else :#line:1026
			O000OOOO000O0OOO0 =OOOOOOO00OOOOOOOO +' ([COLOR yellow] STATUS: [/COLOR]'+'[COLOR red]'+OO00OO0O00O0O00O0 +'[/COLOR])'#line:1027
		add_dir ('f','get_k_episodes',O0O0O000O00O0OOO0 ,'[B][COLOR white]'+O000OOOO000O0OOO0 +'[/COLOR][/B]',O00OO000O00OO000O ,O00OO000O00OO000O ,O0000000OO0OOO0O0 )#line:1028
	O00000OOOOOOOO0OO =r'<nextpage>(.+?)</nextpage>'#line:1030
	O0O000000OO0000OO =re .compile (O00000OOOOOOOO0OO ,re .DOTALL ).findall (str (O000OOO0O000O0OOO ))#line:1031
	for O0O0O000O00O0OOO0 in O0O000000OO0000OO :#line:1033
		if "nextsearchpage/"in O0O0O000O00O0OOO0 :#line:1034
			O0O0O000O00O0OOO0 =O0O0O000O00O0OOO0 .replace ('nextsearchpage/','https://www1.dramacool.movie/search')#line:1035
		add_dir ('f','displaypage',O0O0O000O00O0OOO0 ,'[B][COLOR red]NEXT PAGE[/COLOR][/B]')#line:1039
def Displaycast (O000000000O0O000O ):#line:1046
	O0O0O0O000O00O000 =requests .get (O000000000O0O000O ,headers =headers )#line:1047
	OOOOOO0OOOO000000 =O0O0O0O000O00O000 .content #line:1048
	OOOOOO0OOOO000000 =OOOOOO0OOOO000000 .decode ('utf-8')#line:1049
	OOOOOO000OO00OOOO =re .compile ('div class="slider-star">(.+?)<div class="tags">',re .DOTALL ).findall (OOOOOO0OOOO000000 )#line:1050
	O0O00OOOOO000O0O0 =re .compile ('<a href="(.+?)".+?<img src="(.+?)".+?">(.+?)</h3>',re .DOTALL ).findall (str (OOOOOO000OO00OOOO ))#line:1051
	add_dir ('','','','[B][COLOR violet]SELECT FOR THEIR SHOWS[/COLOR][/B]','','','')#line:1053
	for O000000000O0O000O ,OOO00OOO0OOOOOOO0 ,OOO000OOOOO00OO00 in O0O00OOOOO000O0O0 :#line:1054
		O000000000O0O000O =preurl3 +O000000000O0O000O #line:1055
		add_dir ('f','displaycastshows',O000000000O0O000O ,'[B][COLOR white]'+OOO000OOOOO00OO00 +'[/COLOR][/B]',OOO00OOO0OOOOOOO0 ,OOO00OOO0OOOOOOO0 ,OOO000OOOOO00OO00 )#line:1057
def Displaycastshows (OOO00O0O00OO0OO0O ):#line:1059
	OOOO0OO0OO00OO0O0 =requests .get (OOO00O0O00OO0OO0O ,headers =headers )#line:1061
	OO00OOOOO0O0OO0O0 =OOOO0OO0OO00OO0O0 .content #line:1062
	OO00OOOOO0O0OO0O0 =OO00OOOOO0O0OO0O0 .decode ('utf-8')#line:1063
	OO00O0O00OO0OOOO0 =re .compile ('<div class="block-tab">(.+?)<div class="content-right">',re .DOTALL ).findall (OO00OOOOO0O0OO0O0 )#line:1065
	O0000OOO0OOOO0OOO =re .compile ('<a href="(.+?)".+?<img src.+?data-original="(.+?)".+?">(.+?)</h3>',re .DOTALL ).findall (str (OO00O0O00OO0OOOO0 ))#line:1066
	add_dir ('','','','[B][COLOR yellow]Select Shows Below[/COLOR][/B]','','','')#line:1069
	for OOO00O0O00OO0OO0O ,O00OOO000000O0000 ,O0O0OO0OOO00O00OO in O0000OOO0OOOO0OOO :#line:1070
		add_dir ('f','get_k_episodes',OOO00O0O00OO0OO0O ,'[B][COLOR white]'+O0O0OO0OOO00O00OO +'[/COLOR][/B]',O00OOO000000O0000 ,O00OOO000000O0000 ,O0O0OO0OOO00O00OO )#line:1073
def Displaylinks (OO0O000O0O0OO0OOO ):#line:1080
	OOOOO0OO00000OOO0 =requests .get (OO0O000O0O0OO0OOO ,headers =headers )#line:1081
	OO00O0OOO00O0OO00 =OOOOO0OO00000OOO0 .content #line:1082
	OO00O0OOO00O0OO00 =OO00O0OOO00O0OO00 .decode ('utf-8')#line:1083
	O000OOOO0OO000000 =re .compile ('<div class="anime_muti_link"><ul>(.+?)</ul></div>',re .DOTALL ).findall (OO00O0OOO00O0OO00 )#line:1085
	O00OOO000000O00O0 =re .compile ('<li class=".+?data-video="(.+?)">.+?<span>',re .DOTALL ).findall (str (O000OOOO0OO000000 ))#line:1086
	for OO0O000O0O0OO0OOO in O00OOO000000O00O0 :#line:1089
		if 'https:'not in OO0O000O0O0OO0OOO :#line:1091
			OO0O000O0O0OO0OOO ='https:'+OO0O000O0O0OO0OOO #line:1092
		if 'streaming.php?id'in OO0O000O0O0OO0OOO :#line:1095
			try :#line:1099
				OO00OO00OOOOO0OO0 =r'https:\/\/(.+?)\/streaming.php\?id=(.+?)\&title'#line:1101
				O00OOO000000O00O0 =re .compile (OO00OO00OOOOO0OO0 ,re .DOTALL ).findall (OO0O000O0O0OO0OOO )#line:1102
				for O00OOOO0000000O00 ,O0O00OO000OO0000O in O00OOO000000O00O0 :#line:1103
					O00O0OOOOOO0O000O =O0O00OO000OO0000O #line:1104
					O0OO000O00OOOO0OO =O00OOOO0000000O00 #line:1105
				OO00O000O0O00O0O0 ='https://'+O0OO000O00OOOO0OO +'/video.php?id='+O00O0OOOOOO0O000O #line:1126
				OOO000OOO0O00000O =requests .get (OO00O000O0O00O0O0 ,headers =headers )#line:1128
				OO00O0O0OOO0O0O0O =OOO000OOO0O00000O .content #line:1129
				OO0000OO0O0O00OOO =OO00O0O0OOO0O0O0O .decode ('utf-8')#line:1130
				OO00OOOOOOO00O000 =re .compile ('<div class="dowload">.+?href="(.+?)"',re .DOTALL ).findall (OO0000OO0O0O00OOO )#line:1134
				for O00OOO000000O00O0 in OO00OOOOOOO00O000 :#line:1135
					if 'download.php'in O00OOO000000O00O0 :#line:1137
						continue #line:1138
					if 'https://sbplay.org/d/'in O00OOO000000O00O0 :#line:1139
						O00OOO000000O00O0 =O00OOO000000O00O0 .replace ('https://sbplay.org/d/','https://sbplay.org/embed-')#line:1140
					if 'bodelen'in O00OOO000000O00O0 :#line:1141
						continue #line:1142
					else :#line:1144
						try :#line:1147
							OOOO0O0OOO0O0O0O0 =O00OOO000000O00O0 .split ('//')[1 ].replace ('www.','')#line:1148
							OOOO0O0OOO0O0O0O0 =OOOO0O0OOO0O0O0O0 .split ('/')[0 ].split ('.')[0 ].title ()#line:1149
						except :pass #line:1150
						if 'Storage'in OOOO0O0OOO0O0O0O0 :#line:1151
							OOOO0O0OOO0O0O0O0 ='Direct Play Link'#line:1152
					add_dir ('','dramacoolresolve',O00OOO000000O00O0 ,'[B][COLOR white]'+OOOO0O0OOO0O0O0O0 +'[/COLOR][/B]',thumb ,'','')#line:1153
			except :#line:1169
				pass #line:1170
		else :#line:1172
			try :#line:1173
				OOOO0O0OOO0O0O0O0 =OO0O000O0O0OO0OOO .split ('//')[1 ].replace ('www.','')#line:1174
				OOOO0O0OOO0O0O0O0 =OOOO0O0OOO0O0O0O0 .split ('/')[0 ].split ('.')[0 ].title ()#line:1175
			except :pass #line:1176
			O00OOOO0000000O00 =resolveurl .HostedMediaFile (OO0O000O0O0OO0OOO )#line:1177
			O000OO00O0O0000O0 =O00OOOO0000000O00 .valid_url ()#line:1178
			if O000OO00O0O0000O0 ==True :#line:1179
				add_dir ('','dramacoolresolve',OO0O000O0O0OO0OOO ,'[B][COLOR white]'+OOOO0O0OOO0O0O0O0 +'[/COLOR][/B]',thumb ,'','')#line:1180
			elif O000OO00O0O0000O0 ==False :#line:1181
				pass #line:1183
def Dramacoolresolve (OOO0O0O0000O000OO ):#line:1481
	if 'google'in OOO0O0O0000O000OO :#line:1482
		OOOO0O0O0O000O0O0 =OOO0O0O0000O000OO #line:1483
	elif '.m3u8'in OOO0O0O0000O000OO :#line:1484
		OOOO0O0O0O000O0O0 =OOO0O0O0000O000OO #line:1485
	else :#line:1486
		OOOO0O0O0O000O0O0 =resolveurl .resolve (OOO0O0O0000O000OO )#line:1488
	O000OO0OOO0000O0O =xbmcgui .ListItem (title )#line:1490
	O000OO0OOO0000O0O .setArt ({'poster':thumb ,'thumb':thumb })#line:1492
	O000OO0OOO0000O0O .setInfo (type ='Video',infoLabels ={'Title':title })#line:1493
	O000OO0OOO0000O0O .setPath (OOOO0O0O0O000O0O0 )#line:1494
	xbmc .executebuiltin ("Dialog.Close(busydialog)")#line:1499
	try :#line:1505
		xbmcplugin .setResolvedUrl (int (sys .argv [1 ]),True ,O000OO0OOO0000O0O )#line:1507
	except :#line:1508
		pass #line:1509
		xbmc .executebuiltin ("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)")#line:1510
	for OO000OOO0O0OOOO0O in range (0 ,120 ):#line:1513
		if player .isPlayingVideo ():#line:1514
			xbmcgui .Dialog ().notification (addon_name +' is provided by:','Team Kepweng',Icons2 +'icon2.png',10000 ,False )#line:1515
			break #line:1516
		xbmc .sleep (1000 )#line:1517
	while player .isPlaying ():#line:1518
		xbmc .sleep (2000 )#line:1519
	xbmc .sleep (4000 )#line:1520
params =Get_Params ()#line:1530
mode =None #line:1531
try :mode =params ['mode']#line:1533
except :pass #line:1534
try :url =params ['url']#line:1535
except :pass #line:1536
try :title =params ['title']#line:1537
except :pass #line:1538
try :thumb =params ['iconimage']#line:1539
except :pass #line:1540
try :bg =params ['fanart']#line:1541
except :pass #line:1542
try :desc =params ['description']#line:1543
except :pass #line:1544
if mode ==None or len (sys .argv [2 ])<2 :login ()#line:1546
if mode =='searchme':#line:1551
	Searchme ()#line:1552
if mode =='search_tagalog':#line:1553
	Search_Tagalog ()#line:1554
if mode =='scrape_pinoyflix_pages':#line:1555
	scrape_pinoyflix_pages (url )#line:1556
if mode =='scrape_latest_pages':#line:1557
	scrape_latest_pages (url )#line:1558
if mode =='get_links':#line:1559
	get_links (url )#line:1560
if mode =='displaypage':#line:1561
	Displaypage (url )#line:1562
if mode =='Display_Tagalog_Page':#line:1563
	Display_Tagalog_Page (url )#line:1564
if mode =='scrape_klatest_pages':#line:1565
	scrape_klatest_pages (url )#line:1566
if mode =='scrape_kdrama_most_popular':#line:1568
	scrape_kdrama_most_popular (url )#line:1569
if mode =='get_k_episodes':#line:1570
	get_k_episodes (url )#line:1571
if mode =='get_klinks':#line:1573
	get_klinks (url )#line:1574
if mode =='get_recently_episodes':#line:1576
	get_recently_episodes (url )#line:1577
if mode =='dramacoolresolve':#line:1579
	Dramacoolresolve (url )#line:1580
if mode =='displaymenu':#line:1581
	Menu ()#line:1582
if mode =='displaycast':#line:1584
	Displaycast (url )#line:1585
if mode =='displaycastshows':#line:1587
	Displaycastshows (url )#line:1588
xbmcplugin .endOfDirectory (addon_handle )