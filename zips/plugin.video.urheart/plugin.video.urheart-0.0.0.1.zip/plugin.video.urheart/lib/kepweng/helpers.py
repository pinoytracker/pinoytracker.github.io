import requests,re
from . import jsunpack
#import aadecode
import base64

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}

def get_packed_data(html):
    packed_data = ''
    for match in re.finditer('(eval\s*\(function.*?)</script>', html, re.DOTALL | re.I):
        try:
            js_data = jsunpack.unpack(match.group(1))
            js_data = js_data.replace('\\', '')
            packed_data += js_data
        except:
            pass
        
    return packed_data

def parse_mixdrop_sources_list(html):
    
    regexme = r'(?:vsr|wurl|surl)[^=]*=\s*"([^"]+)'
    match = re.compile(regexme,re.DOTALL).findall(str(html))[0]
    #if match:
        
        #return "https:" + r.group(1) + helpers.append_headers(headers)
    #    return "https:" + r.group(1)
    

    return match

def replace_unicode(text):
    text = text.replace('&#7424;','A').replace('&#665;','B').replace('&#7428;','C').replace('&#7429;','D').replace('&#7431;','E').replace('&#1171;','F').replace('&#610;','G').replace('&#668;','H').replace('&#618;','I').replace('&#7434;','J').replace('&#7435;','K').replace('&#671;','L').replace('&#7437;','M').replace('&#628;','N')\
    .replace('&#7439;','O').replace('&#7448;','P').replace('&#42927;','Q').replace('&#640;','R').replace('&#42801;','S').replace('&#7451;','T').replace('&#7452;','U').replace('&#7456;','V').replace('&#7457;','W').replace('&#120;','X').replace('&#655;','Y').replace('&#7458;','Z').replace('&#7458;','Z').replace('\\\\t','')\
    .replace('\\\\\\\\n','').replace('&rsquo;','\'').replace('&nbsp;',' ').replace('&lsquo;','\'').replace('&lsquo;','\'').replace('&#39;','\'').replace('&ldquo;','\'').replace('&rdquo;','\'')\
    .replace('&shy;&shy;','')

    return text