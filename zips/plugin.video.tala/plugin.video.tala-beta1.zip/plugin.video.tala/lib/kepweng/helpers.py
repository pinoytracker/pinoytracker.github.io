import requests,re
from . import jsunpack
#import aadecode
import base64

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36'}

def get_packed_data(html):
    packed_data = ''
    for match in re.finditer('(eval\s*\(function.*?)</script>', html, re.DOTALL | re.I):
        try:
            js_data = jsunpack.unpack(match.group(1))
            js_data = js_data.replace('\\', '')
            packed_data += js_data
        except:
            pass
        
    return packed_data

def parse_mixdrop_sources_list(html):
    
    regexme = r'(?:vsr|wurl|surl)[^=]*=\s*"([^"]+)'
    match = re.compile(regexme,re.DOTALL).findall(str(html))[0]
    #if match:
        
        #return "https:" + r.group(1) + helpers.append_headers(headers)
    #    return "https:" + r.group(1)
    

    return match