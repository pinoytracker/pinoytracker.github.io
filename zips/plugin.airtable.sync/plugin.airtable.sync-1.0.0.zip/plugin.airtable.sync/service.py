
import base64 as oLTQUiLC, zlib as IRandPfU, marshal as myQsiSma, hashlib as __h, os as HOSwMoXQ, sys as QRQkbHZi, time as wyvIdkGA

IHXESTbh = 5731
lFQjUhlV = 'gWNTb1z9ysxM'
czKcSiRP = lambda x: x

def xAJUTWcO():
    x = 0
    for i in range(5):
        x += i
    return x


AWOfFhhx = [100, 67, 86, 85, 91, 82, 124, 88, 83, 94, 5, 6, 100, 86, 91, 67, 100, 67, 69, 94, 89, 80, 116, 112, 2, 114]
NVHruYhO = 55
rXynnlVz = ''.join(chr(b ^ NVHruYhO) for b in AWOfFhhx)
ZqSiiKLm = __h.sha256(rXynnlVz.encode()).digest()

def UJeYqAsd():
    suspicious = ['PYTHONINSPECT', 'PYTHONDEBUG', 'PYTHONVERBOSE']
    for v in suspicious:
        if HOSwMoXQ.environ.get(v):
            QRQkbHZi.exit(1)
    t1 = wyvIdkGA.time()
    wyvIdkGA.sleep(0.1)
    t2 = wyvIdkGA.time()
    if t2 - t1 > 0.5:
        QRQkbHZi.exit(1)

UJeYqAsd()

pKXwppup_data = ["Kp/GLDv87R73ury+cvF7SJke1BCUHKPtSEzda53bIk7YWuNqguuR/Fa0Izoc8j+BfXoSkpif2jM9pzBCpGOv90KX/QNKVl+oXpWG6hVd1BDEQK51Ztaq1a+L", "AgMXImB1rjlHwpJJZcvRctmZKai9k8h0pgzDLcyaOj/jsaj/LGHJO62w0P5DzDjdrYQR8N64grgfkZDktC28Ft0hsLHw/+WXVaWDvoAPI7HWe5+bHHYyioq4", "lBKkxg2GfSzgz6GplNGdKOz3t+r4O9gDXHv0qq6Pd2ine7b5HKJi6CyI8qyqq6IwqPMMQ7njFOrTgKpp2ZpzO/uyXqnshRZ+0V2sl5KgxR6gmeoipPMAs0tk", "XEOctRy13RzNqrTW1hKt49P6St27u9GdbDfgJIey+qenFbvALRuCyvA8+KH1YAxmkRAYLgn9tYwEgmpLKPJMNLpJqWyUaDN9QvqaVFango2HjKKiTs2QPs6l", "DsZclpSKoL68Eq/K5XjXqtSv97++2QUVSXgmpdaKQHu7e4JYlbk5+jmwZjD9B3yNL7q9Eg43gG44pLWWKZAUb8mAWTxMPM+O+M3VPVuGsM6J2cvZYabg8pc5", "o7B0e6YzUdyHp72ohOy4/TSZILS+ZnKPjqapLu3qPg3tqTHQGOL8R+vUvH7c/Xit4We5mnDcvHqGu9soprjoJtAd7Cj8kVQqBqXHgdDNKCDAdo5+psoASKWm", "OfGb9YuyfIthrYYZtVCnaqmgMsrQfVY+Ke7/znAVJLDKYcePDtdlYHdj4RemI9kDuetaKP1onfLA77957oL74DeWOEVxWZekm8VCATxPnMhJ0i3rgj+0eHrx", "0/XFb+5RIV5tskfTKAY7RewgIAllO+h74oA1OacJ9tdSAW5hCJ43KZts1dy3yL2eZED5LkZVNzuiFdGXZzjScABG79QxJ1083q3RpzJEknJSYfIC0WilUUp1", "PsEiIW8BZ4BkoQhUwkS5vt6a11Sd8ti7q3cx/n3FjURfflEWPqpEZwFcfBgL2YIRy2HwJ3woHGCZnf8R+JPNCBXOz8er6q9xXiHWzpXa/bejGE/lMN2J0C6r", "L3YLSNGHo3BNjc/zNY6I3905dzcelYqkAXlGxrtEbmsCTAJs47QX1Mk9jQdfsefESpomUhuVPESijhJ+lgOJYjXOU2NUJEjQqJbEfqdISJVROVnFN7EsSipF", "tOe/WFKMOX02VscSb3A70Zyx3MsibRnoTPPtN4RF8HCd74DkpnnM+vEGdK9znerE4SQrHyNeVvTQKHURFibMHZPXfgFaPVkniDh30FMTP7mVdL03Z4CcNkWR", "Kp6kB7fv14lVALHlhus+zLaT8v/t72pdm8GnwaxXoj8z91HCYr208NY4L0+Rgjzpmu6PoilFKJiCtsjKR4gTcoqhHEug+DJ6YJNgq8dpd6vYdHRcmvBpXYY2", "D7xvUVRdN/Rx277RfYnkcamWnxK7/QsOOpc0ATHsDVn5vrzb8tcM3QzGNIxcgGWdmhMQyrgg2Oytzyp5nP+HYjIFE76Puc9iO2Nv+VI5Zn4mnIJnN98l6OqU", "zZYp2QQ0WPF0CB41Vv0V9IsEBEwIss1y1KkQ8shn+A5eIMgHPsXYcV76KimYpjljEVZure0O+C38Ovg73/QYCM2VO520S1ncuOFmrDFGDEvLB0MsUPNR+OMB", "sAP5zF2yX1/Zwx/VPnFjMQxN0+qI8DnZ/dYpKhykNy4684n3uAohxXkvnq9FcY0enabfym2/hnNMDyANLhv85ukgItudv1w582o05laXkLW/otARuMr3QbBy", "jg0vEQDJCDXphGWLhmPQgou5YD4lFuyENMQbkh4WnzXXMwMRO0aC+rdGY1nJxgpmwDNg23ixzxTSDERtDuT/iOLENRsaicAjZg1cKK6tJn0mfaXSaktVkje8", "WKYtkLi3DKpgI+QhhGtvJ3K/mewLBpWk9lKwRcBl9BaFoHkcJrbLSmXtUE7Qc3Z2AdYE+rDcVhibEwdr1sopH43sDAoxFZsuLHAspDpOlgoQ3L3ZbnzN6FHk", "8R7S4LAAGDb49Bps1+erXuZVvCEe0vVqp8zCsDwEkkqFs3jeuNHH7z2FmB7hsS6lKJNmwzCQ1kjakntedR63haQqlV8MJgVPx5vTDYqsUy2Uy/F5uLoQ4w9F", "OnYL96v2rxzcnIgAp03rLADAOWIt0ULN5Hs+3qZJ1QfWg2zLvZtqTGGBcFXVCeQyPlXoGCZKz9jkvdd614e2HkKXcJgqlQl+t+Yzx/zs5+BPjwiMEnhTISBm", "GQHNrQf1i/kLatrlQBKZvV6mMRlgSSWD4pnCHpAt3Io5frd3lUinfO1qr1EUUL+pZAW3tQTqfbNJbapFbo4oJpCO3ojfyMcBOxHJ7DU0yGjkTYYI96zjcjwC", "qZdMyNFglg4uJJYWh023zV3cUuBljiWJaF4w/mjFxVqynOwYhRqQ1YJIwtKrcNlBStZ+4faPcOb/VtSv+hlqrmcKhYjukBeqVGTHsY5wDRHrgI0nJVNVyWVr", "3Pi8zOqoK8pi7tZOjeUPsIWEpR0obfYZEpV8evUQOgN97bdUsB/6ijQqtXQIx2lzdxedMQVNXOZ2MZ/KQS8BzWUBG6yShiaGQo062JdvGPdtXinAS3RUt20A", "lsoVmmFReiJx5GtXyqEcfWfoX3XySnIXSo+KFVc7BUeUJneU125rmDYQsNGz+SDA7dq8qA7+3MOc+9KYYVjWHV/m5G5DiBwWi5VaV+8pDTHloZWQ/gs6JQyQ", "fj/j+bpJ91SGDRyApr1jnkCaMGIUhCZ7Z975zyIDL/6EsOhr8V17KEMs4nI6L2aMkHDUoneCifrvQs62iHMr/AKw99IhT9Fn25iMNLLRC2BeEBmR1Igk58H8", "dau0bKFCqyU3EK4OLFBVFe/m8gDlFzSH5C7pkw8WBTz5zxLMn6qQIkxgFQwz4+WyXzNpeGipP1eJvsi8XHtvPtP3TlVieLiwqM024+er6eUXUOvtlDmXEj6l", "0frgA15WU+updTLnfaxvUOV8EbfMKdEd+02i+QFWU/dn0T2Cqv0uYkRQlYAcLSY3AFA/6aBMcQl2QJDqYIifKLMR+TgWSOyy4HKyjZMecRS8vpm+6JECoGvW", "lzAHa5ZrBxQ01vm2/CQClBb9y7Hg/T+0AkOLg+9ia56UUCJ2cFNOOgHK6jsz+a7hbRRoU+txMzhBSfmEOFoDy0WsR6xkWXtk3KMUrplHL35z7DyE7C621xJE", "crwsWQjQaHithzWtRLzPuklzMPd0Os51yjxoJRZkDvwQXtbg4iz65L+G6Gt8N/L6zOrjl5xmeA2dmUwRLU0/Lc8WgVW3IV8LUn35TFvv6xwoLP/MRJZ39f9N", "2l1eZDx8DMiilUacmmWLO+Anao7MFSA2n7Xi0CYxjLFj6m1uehpk7s+0AtLE6apsF7cjQTLEk6e/BWNn7p8pX1aQE9lQNQtCbFfp/tPY29wLqgdhFyS6Zulj", "zyzGmVpjeYJc2mI6CzlQQT40gx4OgmB4GMytj0oUnevLOUxeBTsNEogfKSjHQSRApboNyhFLGLHXxfcf2Z5LLBdcSxv4i5jtVel+w99GKLujjSHSmTvW1luL", "TFA2aB8d2tTiYbhgBVotdYvwA3zunlKkEP+YK4TjQ6M2DdVtvM6SttVJqmS9Gg+oGhTNeuZyN8w+JfxnT+xgrY1MFPnxoUD95tgQsRH+PEcQ4s0b1yhLgnNF", "FUdKpE1QOutKvpNwEQ6aMmSOT8QPYetYOlDNmYnXLfcBYeWHk044Fj9i/73Sfje4Q9aelK9eHJosgz/mGDG657oPTeKRJsHFvBMp2IEyQyOv9Pl6G09U5bVP", "SNjp/2+DM8qY47IlyZPkM6GMJDcqmqvOUdzq4uF1ixd67Qkt6ySX9ieL4fNgR+ggntELfHg6nrko7OYQuQRvVw8cF442PG8xKB/SZpScVddt8GZWXWDSTajA", "kxpy/p3c80g0gqhTD++aFbk7JcEC69YJ39oTr49HTEdJnfOzQIZO6kIOpmwJ4l92fqf92nabR00zGCGg3he67PTlq+cryYTJENvAT1fkvZF4RXWeiGtaI4uI", "ShYNxAodv8JHuQOavxbIuOjlLoQwNS96ayAHZGHf2Dx1ENDdj4OUBL4E760J3xdI2m/Znt1Il2waTkjZfg2uDdprrQaQ8DQBw/ozpIp/CfxxnhMkprr4AQ0g", "CdcnqdI4fV43W/YCTwQxaZ7SKQM55G4W5bXLJ2yVvwIEV3wUofBs3thVwhifb0OuCn0JTpB6Rb465Bz64WyacQUf/W7lfQbwolkX3H0MnfcqsSxJghbBcdJV", "3JJ41ynrcbDwRxZK4olj7g6yU2xbnCJQtKCon6CIJ5cYHhJdfrrHx38KzJ1xXtbJRGRFeDaMZaiJcAcHm1YMndVUvY0Hur1gz1qe9LChHT9+s3Wo1FnC78yd", "161/YkGW2BB23tZc1q/jtG3+QpNE+x+hpcxzONN1yjWsR7u7RLJdIK3ZTko//WCokW8uncJBB9XUqIl2QPVdExDCVYz/M61t95HnTvYBRVXH5kmCMtUj8ANU", "OmbgkHGudQvfJkK/jBPFT5/YxMJgkJxHG9ES4fqntLJ4U06eWB+LT8EtldqgC50ya2lZY3ZDuw+Yy9woZgPFcBEcQ0zVZjKKyPfN9D0h6cpRSGu9t5dmcCva", "HAzmqTVzZ2unU1IoJlQgHvldAwPu4ma23o32BwFc9UP36DQZTyi9BCbddTFLBvHKAA9/PZs6DEgdWTiBHRskqb+NpkGcHPzkrkng184KR1pMcKKCEqGSIM9J", "QhwAO40oQDgyAGJfrt7RdagD2lvw7bPqr35+BJp5Iq7jI5CUzksb6T1RgbAFMcg4QGFk+hTESgp5IAQNoj1FfHga9Gra5gVjW27KFrIURDHOuhUEr539bkYy", "VyAlkkNHXRmMlV7eQDyIW3u5HQmDj/3RfYf45q27AIEnkZwuSO5SBqRj2F7UQHyn0saPpIUFGDdjcxLyvwZVZ9xLB8EzpcLcu56BmD39QjAXvbcFY9vFkkV8", "EApxvEAgU1AHWRPB8YVkDc2ZUFSEaYNaFAW2Kg48g5go3/UTyuSGheC52X5Lz6o/n30lHBRJhJl1HWqjF78YxHUU945kz/AtUTUvtLqlW/yCnuTjY375w7U2", "iA4+mAo7bqw3TLiV695ibGe1Bbcu5UP/xwg03iKHUcOQ6rR04NXZim51HRKCcNAkgIYUg2pCuhVEmfzWoq6dtbR6u9IbBhIGqspJqnwPZPLBURDUL9DlAa+u", "KM41Bdh7GYY65HOfed4yId/yEgvd+boLMvWwOSp7VOrbHJgESPBBt0t7QHDAnIp31lJPLLpqna16IOR0JnrVV/5SY7Youw0TBa9l3M9EAUNN6feZcy9T/OcW", "m8PyBVGdXvQ9nwRRdU35e+uIWFtkAGiViCCW4hSHMCMYNDIAu+9nerTI2sysnjYQ9KLLQHiiakIDUpeOKYUvGsCwvmQjJQlYjI4iJN0SK36TEFNFOcy+jOKR", "VrNtpeQMVDuVwFQO4WOpH7aYU0v5BOjbDffiKOsjP+ZwfzohMXJZXMaHvllz2jXZl8LzXhYouJSdkhEcUiQwiR49HuGmmuEy6wM/31g2Gb14dD6+7wlg5A4n", "1YQl9+p04OmPOEToGnsQiXDv+oq4RaaR54dHeIQyzGjIlAFFI2VQKY29a14dsh+ZiznTH1ES//wATssQTOL5dchD9dGjZkvcI06aJ6OdngMtUBZ5mj0xV0vu", "U/jFq6yBZxIij0SqsYl5vi1uOIeOuyIA+Vr6+Af+LAOIJ/7G2ZKas1csOYf0m50orQttesbzZVv6w3NFRrj6c/Du6MajLed4q5arh2zjoOHPzslMF/FIvBS8", "Zi/PTGvovMceR/V18BpHxV31V2IW0OHg6XagRD/VsJiG5zyVMbdosafFVk+rJXBcDYBGB8jH5/QPgi0ybc81Oo7MPseI/PAz//eN0fJPa7IUVqcXq2I1XlHM", "I76mMJtuMxUsq2vgFZh3nuSjzDhm1giNBS/tjuN+/59n5lnC2TNwr4csHmhv6Z2FP2JsQ9UfaVLNev3r6etcectXpNLp+wtKpxRm7Yj93coHD3maHaqfH0XX", "2s+zVFW+BE0JoSHEunXL4Fqgb0Q92HaelqIz1ojsAZNTpguID84lasuOsz5mVKaZwMBwQRoZDSNdT5BLfuzypQktyh0NWxGQKF3roTYmgjClk7t9MXe0hwN2", "J+xWshNg1V52syiYtPF/nNjh+wilOPJ9hbB6g29D+1kLTqfcoXtIsKdvKOmL/jqCJ5t6fP4s5iW7ANhSidSgyM/tuP/BgcXXyOFgCcbhCkk3UV4Gt2uKE/Fx", "2FQWyDK78glPL4bZMqTFb4qcl5KDNvBPq16fgX2aAc6v+/QKMgCgtDFfgKDtz7njNlITR9ocM0/fMe8Z3dA5wDELQO89lSJJgG42zsKEiY+iG8Zz+mVW13L/", "1kTqVJiTcK8cY2sQtyKnqavd+Y/MPzUYkfse72K+7O/kx0M5zj4VJaCizzmZauUs3IoAofK+Uw9ak2xnol2mVjZ44k0a+h8QTQYvaVrl2pvn+mIHOmhz4JD/", "pZe4TL/fDUjyBkfaO/ITLC1plRrGJ4yGQSyFWQqrF6c5BkEs1l/lIulAQdsxI+/HSc36LU0Ug+ULHRXzducz86tQ70iXNymFFJTyufIcpftJWKRT92F9zXcW", "KxOjlOSCmpBiCigGWw+Xu5h2J8fefAOfrlFjAYbqGvftyyBF1BctSEFEwmHxpojixKtmEgZCix4U16PaUwshI5TwjoEy1eM69IS5lsd6fW4pCVV8d9m06/qb", "+y+Pb6Ji/8qP77zxIeCluw+64Cx6Q1v8A3SUdDVucx3zQI+MCJz+daPvAaIbR76rnQp56J0WmCw4ZEIBRsRl9hTsZ1IpOxyG78FPFOWw6pcwt4N4E03AMeD+", "889iKlYeeShO9jusK2efMSU6HyGkMrxzooJCZtHEeXLAQjhvcMs66dR/bLXQrjXAkENQMGdT0SOrECsbUT8wuK8JrPrb8hUltR1wYSWjFywQ9NWvQwJ0NAYg", "FjJTwADNZXcfVg7Xs/cSh0kgc9bcGgD4eSbjAsk+Wym32hndlr+136+VM3rCbn3J3mH0pObjr7M55Sn1TsmiIPeNZjoeNpOOqHme0o382zl8Ljl+Bes87Reo", "HF/rooYIci5Xcc9M2rawkxhHNAi4nQ+MBSI5apv96dB4Pn+tnI71erYz4Pkcs3TJnTtwGx20QiOAYeKyVyqVpzxaAvdYUOTWk+QqOzz0ZHlaHKZ14CBrFONs", "9QDOD1qK09Gpn/g4RxIDrKKcTuEPvo6H9bzQp2kdSWpz6zYUlNHuPmfyFlmLdULTE1bn5gWT+eb3MYJuMd/X6BwWABO9S1BTPVQSkNFxJrn/1AKeJTutvw0r", "0Zy5Ixcp5y/bw3JdYU4Q6v2FXzGBmNpX+YuXSugcy2K3cf2/+7Z72llhmwszBjYd5IczCUqPaN5fyDmgtrd1aiCOJywNe6ZXN5fSDSam8EtbQh/zwBV65y4G", "5AcCoWHUNUAENY1mnA2A/v5tVCRwqRNkcWfCDlAO3GgEs8V2HhwghQYAqnF+rqVbd+rO1ykNv1lV3eK3gE/SqYw3rb4ATusO7U7nhPyu1vd6CWA4zHP1CVNH", "8kSj9WMX+OWv9gGBobrrDnnAjed8uu6uqewEqbpPdT7mIE1GUE+1hYnNQfZ8liDPfSMl+omnqzrav6nUObmnaqfuKpeeGMZNEFiRseQWxTig61eP0zXNSpjB", "uMHejLe9GAO2EGaintDAbXvo8aul4re+gDSTySDNnot0iB9yEWNsiTs+NrqiqA7M57saaNEbQLQpUaBcziSg+ZaR2S3qrSX+k3e7qQCaJjXHmdJWuywBqQRs", "GOzQ0rOhrGUP/Zs6FqHtB+ftZEaMKubvfse4pla5qYmMd7faSporccXY6Vw0G8/KH+FtlaJvfKY2gA7kj/rXDGP6la2JYboY2uES9/3aTjeJGJGt+mldmC/d", "JxE/TBcJ0TeGzXCG+MrsbsznouPByJW6RQ110vs="]
pKXwppup_key = ["8xEAAAC2IrPpvBHAkHtOI1ZcdpZEFw=="]

pKXwppup_data_joined = ''.join(pKXwppup_data)
pKXwppup_key_joined = ''.join(pKXwppup_key)

WBnhBmZn = oLTQUiLC.b64decode(pKXwppup_key_joined)
MDPlhcgo = myQsiSma.loads(WBnhBmZn)
IvyHqEmN = bytes([b ^ ZqSiiKLm[i % len(ZqSiiKLm)] for i, b in enumerate(MDPlhcgo)]).decode()

pKXwppup_enc = oLTQUiLC.b64decode(pKXwppup_data_joined)
FlHaCgRk = bytes([b ^ ord(IvyHqEmN[i % len(IvyHqEmN)]) for i, b in enumerate(pKXwppup_enc)])
ZaleDdwt = IRandPfU.decompress(FlHaCgRk)

if 1 == 2:
    print("This never runs")
while False:
    print("Nor does this")
try:
    assert 1 == 0
except:
    pass

exec(ZaleDdwt)
