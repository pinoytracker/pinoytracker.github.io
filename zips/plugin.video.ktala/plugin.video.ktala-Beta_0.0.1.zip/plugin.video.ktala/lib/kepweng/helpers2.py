# -*- coding: UTF-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon,requests, xbmcvfs, resolveurl
import re, os, sys, requests

USERDATA_PATH = xbmcvfs.translatePath('special://home/addons/')

import requests

headers = {
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'en-US,en;q=0.9,fil;q=0.8,ko;q=0.7',
    'dnt': '1',
    'origin': 'https://asiaflix.net',
    'priority': 'u=1, i',
    'referer': 'https://asiaflix.net/',
    'sec-ch-ua': '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    'x-access-control': 'web',
}

api = 'https://api.asiaflix.net/v1/drama/detail'
def scrape_main(url):
    params = {
    'id': ''+url+'',
    }

    response = requests.get(api, params=params, headers=headers)
    data = response.content
    return data